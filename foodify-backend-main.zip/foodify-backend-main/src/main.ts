import { NestFactory, Reflector } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { NestExpressApplication } from '@nestjs/platform-express';
import { IoAdapter } from '@nestjs/platform-socket.io';
import * as helmet from 'helmet';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule, {
    rawBody: true, // needed for Stripe webhook signature verification
    logger: ['log', 'warn', 'error'],
  });

  // ── Security ──────────────────────────────────────
  app.use((helmet as any).default());

  // ── CORS ──────────────────────────────────────────
  const origins = (process.env.CORS_ORIGINS || 'http://localhost:3001').split(',');
  app.enableCors({
    origin: origins,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true,
  });

  // ── Validation ────────────────────────────────────
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: false,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
    }),
  );

  // ── WebSockets (Socket.io) ────────────────────────
  app.useWebSocketAdapter(new IoAdapter(app));

  // ── Global prefix — OMITTED so /api/v1/ is set per-controller ──

  const port = parseInt(process.env.PORT || '3000');
  await app.listen(port);
  console.log(`\n🍽  Foodify Backend running on http://localhost:${port}`);
  console.log(`🔌 WebSocket namespaces: /kitchen  /restaurant`);
  console.log(`🌍 Env: ${process.env.NODE_ENV || 'development'}\n`);
}

bootstrap();
