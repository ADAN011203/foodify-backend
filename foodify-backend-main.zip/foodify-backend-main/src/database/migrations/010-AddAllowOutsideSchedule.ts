import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddAllowOutsideSchedule1700000010000 implements MigrationInterface {
  name = 'AddAllowOutsideSchedule1700000010000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // Agregar columna allow_outside_schedule a la tabla menus
    await queryRunner.query(`
      ALTER TABLE menus
      ADD COLUMN allow_outside_schedule TINYINT(1) NOT NULL DEFAULT 1
      COMMENT '1 = acepta pedidos fuera del horario definido, 0 = solo en horario'
      AFTER schedule
    `);

    // DEFAULT 1 porque la mayoría de restaurantes acepta pedidos en cualquier horario.
    // El restaurante puede cambiarlo a 0 desde su configuración de menú.
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE menus DROP COLUMN allow_outside_schedule
    `);
  }
}
