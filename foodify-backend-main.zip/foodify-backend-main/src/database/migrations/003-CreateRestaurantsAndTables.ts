import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateRestaurantsAndTables1700000003000 implements MigrationInterface {
  name = 'CreateRestaurantsAndTables1700000003000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE restaurants (
        id               INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        owner_id         INT UNSIGNED    NOT NULL,
        name             VARCHAR(120)    NOT NULL,
        slug             VARCHAR(120)    NOT NULL,
        logo_url         VARCHAR(255)    NULL,
        address          VARCHAR(255)    NULL,
        timezone         VARCHAR(50)     NOT NULL DEFAULT 'America/Monterrey',
        currency         CHAR(3)         NOT NULL DEFAULT 'MXN',
        is_active        TINYINT(1)      NOT NULL DEFAULT 1,
        dashboard_config JSON            NULL,
        created_at       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY UQ_restaurant_slug (slug),
        CONSTRAINT FK_restaurant_owner FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE RESTRICT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await queryRunner.query(`
      CREATE TABLE \`tables\` (
        id            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        restaurant_id INT UNSIGNED    NOT NULL,
        number        SMALLINT        NOT NULL,
        capacity      TINYINT         NOT NULL DEFAULT 4,
        qr_code_url   VARCHAR(255)    NULL,
        status        ENUM('available','occupied','reserved','cleaning') NOT NULL DEFAULT 'available',
        PRIMARY KEY (id),
        CONSTRAINT FK_table_restaurant FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE RESTRICT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // Add FK from users to restaurants
    await queryRunner.query(`
      ALTER TABLE users
        ADD CONSTRAINT FK_user_restaurant
        FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE RESTRICT
    `);

    // Add FK from saas_subscriptions to restaurants
    await queryRunner.query(`
      ALTER TABLE saas_subscriptions
        ADD CONSTRAINT FK_sub_restaurant FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE RESTRICT,
        ADD CONSTRAINT FK_sub_plan FOREIGN KEY (plan_id) REFERENCES saas_plans(id) ON DELETE RESTRICT
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('ALTER TABLE saas_subscriptions DROP FOREIGN KEY FK_sub_restaurant');
    await queryRunner.query('ALTER TABLE users DROP FOREIGN KEY FK_user_restaurant');
    await queryRunner.query('DROP TABLE IF EXISTS `tables`');
    await queryRunner.query('DROP TABLE IF EXISTS restaurants');
  }
}
