import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateInventoryTables1700000006000 implements MigrationInterface {
  name = 'CreateInventoryTables1700000006000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE inventory_items (
        id            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        restaurant_id INT UNSIGNED    NOT NULL,
        name          VARCHAR(120)    NOT NULL,
        unit          VARCHAR(20)     NOT NULL,
        min_stock     DECIMAL(10,3)   NOT NULL DEFAULT 0,
        current_stock DECIMAL(10,3)   NOT NULL DEFAULT 0,
        category      VARCHAR(60)     NULL,
        image_url     VARCHAR(255)    NULL,
        created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        CONSTRAINT FK_inv_item_restaurant FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE RESTRICT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await queryRunner.query(`
      CREATE TABLE inventory_lots (
        id          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        item_id     INT UNSIGNED    NOT NULL,
        lot_number  VARCHAR(50)     NULL,
        quantity    DECIMAL(10,3)   NOT NULL,
        remaining   DECIMAL(10,3)   NOT NULL,
        unit_cost   DECIMAL(10,4)   NOT NULL,
        supplier    VARCHAR(120)    NULL,
        entry_date  DATE            NOT NULL,
        expiry_date DATE            NULL,
        status      ENUM('available','low','critical','expired','depleted') NOT NULL DEFAULT 'available',
        created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY IDX_lot_item_entry  (item_id, entry_date),
        KEY IDX_lot_expiry      (expiry_date, status),
        CONSTRAINT FK_lot_item FOREIGN KEY (item_id) REFERENCES inventory_items(id) ON DELETE RESTRICT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await queryRunner.query(`
      CREATE TABLE inventory_movements (
        id         INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        lot_id     INT UNSIGNED    NOT NULL,
        order_id   INT UNSIGNED    NULL,
        type       ENUM('sale','waste','adjustment','entry') NOT NULL,
        quantity   DECIMAL(10,3)   NOT NULL,
        notes      VARCHAR(255)    NULL,
        created_by INT UNSIGNED    NULL,
        created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY IDX_mov_lot_date (lot_id, created_at),
        CONSTRAINT FK_mov_lot FOREIGN KEY (lot_id) REFERENCES inventory_lots(id) ON DELETE RESTRICT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await queryRunner.query(`
      CREATE TABLE inventory_alerts (
        id          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        item_id     INT UNSIGNED    NOT NULL,
        type        ENUM('low_stock','expiring_soon','expired','out_of_stock') NOT NULL,
        message     VARCHAR(255)    NOT NULL,
        is_resolved TINYINT(1)      NOT NULL DEFAULT 0,
        created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY IDX_alert_item (item_id),
        CONSTRAINT FK_alert_item FOREIGN KEY (item_id) REFERENCES inventory_items(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // Add FK from recipe_ingredients to inventory_items
    await queryRunner.query(`
      ALTER TABLE recipe_ingredients
        ADD CONSTRAINT FK_ri_item FOREIGN KEY (item_id) REFERENCES inventory_items(id) ON DELETE SET NULL
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('ALTER TABLE recipe_ingredients DROP FOREIGN KEY FK_ri_item');
    await queryRunner.query('DROP TABLE IF EXISTS inventory_alerts');
    await queryRunner.query('DROP TABLE IF EXISTS inventory_movements');
    await queryRunner.query('DROP TABLE IF EXISTS inventory_lots');
    await queryRunner.query('DROP TABLE IF EXISTS inventory_items');
  }
}
