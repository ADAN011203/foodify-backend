import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateDishesAndRecipes1700000005000 implements MigrationInterface {
  name = 'CreateDishesAndRecipes1700000005000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE dishes (
        id            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        restaurant_id INT UNSIGNED    NOT NULL,
        category_id   INT UNSIGNED    NULL,
        name          VARCHAR(120)    NOT NULL,
        description   TEXT            NULL,
        price         DECIMAL(10,2)   NOT NULL,
        cost_est      DECIMAL(10,2)   NOT NULL DEFAULT 0,
        margin_pct    DECIMAL(5,2)    GENERATED ALWAYS AS (
                        CASE WHEN price > 0 THEN ((price - cost_est) / price) * 100 ELSE 0 END
                      ) STORED,
        prep_time_min TINYINT         NOT NULL DEFAULT 15,
        is_available  TINYINT(1)      NOT NULL DEFAULT 1,
        images        JSON            NULL,
        allergens     JSON            NULL,
        sort_order    SMALLINT        NOT NULL DEFAULT 0,
        deleted_at    DATETIME        NULL,
        created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY IDX_dish_restaurant_available (restaurant_id, is_available),
        CONSTRAINT FK_dish_restaurant FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE RESTRICT,
        CONSTRAINT FK_dish_category  FOREIGN KEY (category_id)   REFERENCES menu_categories(id) ON DELETE SET NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await queryRunner.query(`
      CREATE TABLE recipes (
        id           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
        dish_id      INT UNSIGNED  NOT NULL,
        prep_time_min TINYINT      NOT NULL DEFAULT 15,
        servings     TINYINT       NOT NULL DEFAULT 1,
        steps        JSON          NULL,
        notes        TEXT          NULL,
        created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY UQ_recipe_dish (dish_id),
        CONSTRAINT FK_recipe_dish FOREIGN KEY (dish_id) REFERENCES dishes(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await queryRunner.query(`
      CREATE TABLE recipe_ingredients (
        id          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        recipe_id   INT UNSIGNED    NOT NULL,
        item_id     INT UNSIGNED    NULL,
        name        VARCHAR(100)    NOT NULL,
        quantity    DECIMAL(10,4)   NOT NULL,
        unit        VARCHAR(20)     NOT NULL,
        is_optional TINYINT(1)      NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        KEY IDX_ri_recipe (recipe_id),
        CONSTRAINT FK_ri_recipe FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('DROP TABLE IF EXISTS recipe_ingredients');
    await queryRunner.query('DROP TABLE IF EXISTS recipes');
    await queryRunner.query('DROP TABLE IF EXISTS dishes');
  }
}
