import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateFIFOTriggers1700000009000 implements MigrationInterface {
  name = 'CreateFIFOTriggers1700000009000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // TRIGGER 1: After order delivered → FIFO stock deduction
    await queryRunner.query(`
      DROP TRIGGER IF EXISTS after_order_delivered
    `);

    await queryRunner.query(`
      CREATE TRIGGER after_order_delivered
      AFTER UPDATE ON orders
      FOR EACH ROW
      BEGIN
        DECLARE done       INT DEFAULT FALSE;
        DECLARE v_dish_id  INT;
        DECLARE v_qty      DECIMAL(10,3);
        DECLARE v_item_id  INT;
        DECLARE v_ing_qty  DECIMAL(10,4);
        DECLARE v_lot_id   INT;
        DECLARE v_lot_rem  DECIMAL(10,3);
        DECLARE v_deduct   DECIMAL(10,3);
        DECLARE v_need     DECIMAL(10,3);
        DECLARE v_stock    DECIMAL(10,3);
        DECLARE v_min      DECIMAL(10,3);
        DECLARE v_item_name VARCHAR(120);

        -- Only when status transitions to 'delivered'
        IF NEW.status = 'delivered' AND OLD.status != 'delivered' THEN

          -- Cursor over order items
          BEGIN
            DECLARE cur_items CURSOR FOR
              SELECT oi.dish_id, oi.quantity
              FROM order_items oi
              WHERE oi.order_id = NEW.id;
            DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

            OPEN cur_items;
            items_loop: LOOP
              FETCH cur_items INTO v_dish_id, v_qty;
              IF done THEN LEAVE items_loop; END IF;

              -- For each ingredient in the dish recipe
              BEGIN
                DECLARE done2     INT DEFAULT FALSE;
                DECLARE cur_ing CURSOR FOR
                  SELECT ri.item_id, (ri.quantity * v_qty) AS total_qty
                  FROM recipe_ingredients ri
                  INNER JOIN recipes r ON r.id = ri.recipe_id
                  WHERE r.dish_id = v_dish_id AND ri.item_id IS NOT NULL;
                DECLARE CONTINUE HANDLER FOR NOT FOUND SET done2 = TRUE;

                OPEN cur_ing;
                ing_loop: LOOP
                  FETCH cur_ing INTO v_item_id, v_need;
                  IF done2 THEN LEAVE ing_loop; END IF;

                  -- FIFO: consume lots ordered by entry_date ASC
                  BEGIN
                    DECLARE done3 INT DEFAULT FALSE;
                    DECLARE cur_lots CURSOR FOR
                      SELECT id, remaining
                      FROM inventory_lots
                      WHERE item_id = v_item_id
                        AND remaining > 0
                        AND status NOT IN ('depleted','expired')
                      ORDER BY entry_date ASC;
                    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done3 = TRUE;

                    OPEN cur_lots;
                    lots_loop: LOOP
                      IF v_need <= 0 THEN LEAVE lots_loop; END IF;
                      FETCH cur_lots INTO v_lot_id, v_lot_rem;
                      IF done3 THEN LEAVE lots_loop; END IF;

                      SET v_deduct = LEAST(v_lot_rem, v_need);
                      SET v_need   = v_need - v_deduct;

                      UPDATE inventory_lots
                        SET remaining = remaining - v_deduct,
                            status = CASE
                              WHEN (remaining - v_deduct) <= 0 THEN 'depleted'
                              ELSE status
                            END
                        WHERE id = v_lot_id;

                      INSERT INTO inventory_movements(lot_id, order_id, type, quantity, notes, created_at)
                      VALUES (v_lot_id, NEW.id, 'sale', v_deduct,
                              CONCAT('Auto FIFO pedido #', NEW.id), NOW());
                    END LOOP lots_loop;
                    CLOSE cur_lots;
                  END;

                  -- Recalculate current_stock for item
                  SELECT COALESCE(SUM(remaining),0) INTO v_stock
                  FROM inventory_lots
                  WHERE item_id = v_item_id AND status NOT IN ('depleted','expired');

                  UPDATE inventory_items SET current_stock = v_stock WHERE id = v_item_id;

                  -- If stock = 0, disable all dishes that use this ingredient
                  IF v_stock = 0 THEN
                    UPDATE dishes d
                    INNER JOIN recipes r   ON r.dish_id = d.id
                    INNER JOIN recipe_ingredients ri ON ri.recipe_id = r.id
                    SET d.is_available = 0
                    WHERE ri.item_id = v_item_id AND d.deleted_at IS NULL;
                  END IF;

                  -- Alert if below min_stock
                  SELECT min_stock, name INTO v_min, v_item_name
                  FROM inventory_items WHERE id = v_item_id;

                  IF v_stock = 0 THEN
                    INSERT IGNORE INTO inventory_alerts(item_id, type, message, created_at)
                    SELECT v_item_id, 'out_of_stock',
                           CONCAT(v_item_name, ' sin stock'), NOW()
                    WHERE NOT EXISTS (
                      SELECT 1 FROM inventory_alerts
                      WHERE item_id = v_item_id AND type = 'out_of_stock' AND is_resolved = 0
                    );
                  ELSEIF v_stock < v_min AND v_min > 0 THEN
                    INSERT IGNORE INTO inventory_alerts(item_id, type, message, created_at)
                    SELECT v_item_id, 'low_stock',
                           CONCAT(v_item_name, ' por debajo del mínimo'), NOW()
                    WHERE NOT EXISTS (
                      SELECT 1 FROM inventory_alerts
                      WHERE item_id = v_item_id AND type = 'low_stock' AND is_resolved = 0
                    );
                  END IF;

                END LOOP ing_loop;
                CLOSE cur_ing;
              END;
            END LOOP items_loop;
            CLOSE cur_items;
          END;
        END IF;
      END
    `);

    // TRIGGER 2: When ALL items of an order are 'ready' → set kitchen_status = 'ready'
    await queryRunner.query(`DROP TRIGGER IF EXISTS after_order_item_status_update`);

    await queryRunner.query(`
      CREATE TRIGGER after_order_item_status_update
      AFTER UPDATE ON order_items
      FOR EACH ROW
      BEGIN
        DECLARE v_total   INT;
        DECLARE v_ready   INT;

        IF NEW.status IN ('ready','served') AND OLD.status NOT IN ('ready','served') THEN
          SELECT COUNT(*) INTO v_total FROM order_items WHERE order_id = NEW.order_id;
          SELECT COUNT(*) INTO v_ready FROM order_items
          WHERE order_id = NEW.order_id AND status IN ('ready','served');

          IF v_total > 0 AND v_total = v_ready THEN
            UPDATE orders
            SET kitchen_status = 'ready',
                status = CASE WHEN status = 'preparing' THEN 'ready' ELSE status END
            WHERE id = NEW.order_id AND kitchen_status != 'ready';
          END IF;
        END IF;
      END
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('DROP TRIGGER IF EXISTS after_order_item_status_update');
    await queryRunner.query('DROP TRIGGER IF EXISTS after_order_delivered');
  }
}
