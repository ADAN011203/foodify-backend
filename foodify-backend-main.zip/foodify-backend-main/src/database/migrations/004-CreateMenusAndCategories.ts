import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateMenusAndCategories1700000004000 implements MigrationInterface {
  name = 'CreateMenusAndCategories1700000004000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE menus (
        id            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
        restaurant_id INT UNSIGNED  NOT NULL,
        name          VARCHAR(100)  NOT NULL,
        description   TEXT          NULL,
        is_active     TINYINT(1)    NOT NULL DEFAULT 1,
        schedule      JSON          NULL,
        sort_order    SMALLINT      NOT NULL DEFAULT 0,
        created_at    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY IDX_menu_restaurant_active (restaurant_id, is_active),
        CONSTRAINT FK_menu_restaurant FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE RESTRICT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await queryRunner.query(`
      CREATE TABLE menu_categories (
        id         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
        menu_id    INT UNSIGNED  NOT NULL,
        name       VARCHAR(100)  NOT NULL,
        description TEXT         NULL,
        icon       VARCHAR(50)   NULL,
        schedule   JSON          NULL,
        sort_order SMALLINT      NOT NULL DEFAULT 0,
        is_active  TINYINT(1)    NOT NULL DEFAULT 1,
        PRIMARY KEY (id),
        KEY IDX_cat_menu (menu_id),
        CONSTRAINT FK_cat_menu FOREIGN KEY (menu_id) REFERENCES menus(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('DROP TABLE IF EXISTS menu_categories');
    await queryRunner.query('DROP TABLE IF EXISTS menus');
  }
}
