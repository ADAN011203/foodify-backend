import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateOrdersAndItems1700000007000 implements MigrationInterface {
  name = 'CreateOrdersAndItems1700000007000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE orders (
        id             INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        restaurant_id  INT UNSIGNED    NOT NULL,
        table_id       INT UNSIGNED    NULL,
        waiter_id      INT UNSIGNED    NOT NULL,
        order_number   CHAR(4)         NOT NULL,
        type           ENUM('dine_in','takeout','delivery') NOT NULL DEFAULT 'dine_in',
        status         ENUM('pending','confirmed','preparing','ready','delivered','cancelled') NOT NULL DEFAULT 'pending',
        kitchen_status ENUM('pending','preparing','ready','delivered') NOT NULL DEFAULT 'pending',
        subtotal       DECIMAL(10,2)   NOT NULL DEFAULT 0,
        tax_amount     DECIMAL(10,2)   NOT NULL DEFAULT 0,
        tip_amount     DECIMAL(10,2)   NOT NULL DEFAULT 0,
        total          DECIMAL(10,2)   NOT NULL DEFAULT 0,
        notes          TEXT            NULL,
        delivered_at   DATETIME        NULL,
        cancelled_at   DATETIME        NULL,
        cancel_reason  VARCHAR(255)    NULL,
        created_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY IDX_order_restaurant_status   (restaurant_id, status),
        KEY IDX_order_kitchen_status      (kitchen_status, restaurant_id),
        KEY IDX_order_created_at          (created_at),
        CONSTRAINT FK_order_restaurant FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE RESTRICT,
        CONSTRAINT FK_order_table      FOREIGN KEY (table_id)      REFERENCES \`tables\`(id)    ON DELETE SET NULL,
        CONSTRAINT FK_order_waiter     FOREIGN KEY (waiter_id)     REFERENCES users(id)        ON DELETE RESTRICT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await queryRunner.query(`
      CREATE TABLE order_items (
        id            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        order_id      INT UNSIGNED    NOT NULL,
        dish_id       INT UNSIGNED    NOT NULL,
        quantity      TINYINT         NOT NULL DEFAULT 1,
        unit_price    DECIMAL(10,2)   NOT NULL,
        subtotal      DECIMAL(10,2)   GENERATED ALWAYS AS (quantity * unit_price) STORED,
        special_notes TEXT            NULL,
        status        ENUM('pending','preparing','ready','served') NOT NULL DEFAULT 'pending',
        started_at    DATETIME        NULL,
        ready_at      DATETIME        NULL,
        created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY IDX_oi_order  (order_id),
        KEY IDX_oi_status (status),
        CONSTRAINT FK_oi_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
        CONSTRAINT FK_oi_dish  FOREIGN KEY (dish_id)  REFERENCES dishes(id) ON DELETE RESTRICT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // Add FK for inventory_movements → orders
    await queryRunner.query(`
      ALTER TABLE inventory_movements
        ADD CONSTRAINT FK_mov_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL,
        ADD CONSTRAINT FK_mov_user  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('ALTER TABLE inventory_movements DROP FOREIGN KEY FK_mov_order');
    await queryRunner.query('ALTER TABLE inventory_movements DROP FOREIGN KEY FK_mov_user');
    await queryRunner.query('DROP TABLE IF EXISTS order_items');
    await queryRunner.query('DROP TABLE IF EXISTS orders');
  }
}
