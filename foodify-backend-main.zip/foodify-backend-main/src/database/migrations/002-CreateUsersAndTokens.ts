import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateUsersAndTokens1700000002000 implements MigrationInterface {
  name = 'CreateUsersAndTokens1700000002000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE users (
        id             INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        restaurant_id  INT UNSIGNED    NULL,
        role           ENUM('saas_admin','restaurant_admin','manager','waiter','chef','cashier') NOT NULL,
        full_name      VARCHAR(120)    NOT NULL,
        email          VARCHAR(190)    NOT NULL,
        phone          VARCHAR(20)     NULL,
        password_hash  VARCHAR(255)    NOT NULL,
        fcm_token      VARCHAR(255)    NULL,
        is_active      TINYINT(1)      NOT NULL DEFAULT 1,
        last_login_at  DATETIME        NULL,
        created_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY UQ_user_email (email)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await queryRunner.query(`
      CREATE TABLE refresh_tokens (
        id          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        user_id     INT UNSIGNED    NOT NULL,
        token_hash  VARCHAR(255)    NOT NULL,
        expires_at  DATETIME        NOT NULL,
        revoked     TINYINT(1)      NOT NULL DEFAULT 0,
        created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY IDX_rt_user (user_id),
        CONSTRAINT FK_rt_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('DROP TABLE IF EXISTS refresh_tokens');
    await queryRunner.query('DROP TABLE IF EXISTS users');
  }
}
