import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateKitchenSessions1700000008000 implements MigrationInterface {
  name = 'CreateKitchenSessions1700000008000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE kitchen_sessions (
        id            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
        chef_id       INT UNSIGNED  NOT NULL,
        restaurant_id INT UNSIGNED  NOT NULL,
        started_at    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
        ended_at      DATETIME      NULL,
        PRIMARY KEY (id),
        KEY IDX_ks_chef_restaurant (chef_id, restaurant_id),
        CONSTRAINT FK_ks_chef       FOREIGN KEY (chef_id)       REFERENCES users(id)       ON DELETE RESTRICT,
        CONSTRAINT FK_ks_restaurant FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE RESTRICT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('DROP TABLE IF EXISTS kitchen_sessions');
  }
}
