import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateSaasPlansAndSubscriptions1700000001000 implements MigrationInterface {
  name = 'CreateSaasPlansAndSubscriptions1700000001000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE saas_plans (
        id           INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        name         VARCHAR(80)     NOT NULL,
        price_mxn    DECIMAL(10,2)   NOT NULL,
        max_branches TINYINT         NOT NULL DEFAULT 1,
        max_menus    TINYINT         NOT NULL DEFAULT 2,
        features     JSON            NOT NULL,
        is_active    TINYINT(1)      NOT NULL DEFAULT 1,
        created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await queryRunner.query(`
      CREATE TABLE saas_subscriptions (
        id                  INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        restaurant_id       INT UNSIGNED    NOT NULL,
        plan_id             INT UNSIGNED    NOT NULL,
        status              ENUM('active','past_due','suspended','trial','cancelled') NOT NULL DEFAULT 'trial',
        amount_mxn          DECIMAL(10,2)   NOT NULL,
        billing_cycle_day   TINYINT         NOT NULL DEFAULT 1,
        trial_ends_at       DATETIME        NULL,
        next_billing_at     DATETIME        NOT NULL,
        current_period_end  DATETIME        NOT NULL,
        cancelled_at        DATETIME        NULL,
        created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY IDX_sub_status_billing (status, next_billing_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await queryRunner.query(`
      CREATE TABLE payment_transactions (
        id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        subscription_id INT UNSIGNED    NOT NULL,
        amount          DECIMAL(10,2)   NOT NULL,
        currency        CHAR(3)         NOT NULL DEFAULT 'MXN',
        status          ENUM('success','failed','refunded','dispute','pending') NOT NULL,
        payment_method  VARCHAR(50)     NULL,
        gateway_ref     VARCHAR(100)    NULL,
        paid_at         DATETIME        NULL,
        created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY UQ_gateway_ref (gateway_ref),
        KEY IDX_tx_subscription (subscription_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('DROP TABLE IF EXISTS payment_transactions');
    await queryRunner.query('DROP TABLE IF EXISTS saas_subscriptions');
    await queryRunner.query('DROP TABLE IF EXISTS saas_plans');
  }
}
