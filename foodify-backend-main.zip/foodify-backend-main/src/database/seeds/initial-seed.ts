import { DataSource } from 'typeorm';
import * as bcrypt from 'bcrypt';
import * as dotenv from 'dotenv';

dotenv.config();

async function runSeeds() {
  const ds = new DataSource({
    type: 'mysql',
    host: process.env.DATABASE_HOST || 'localhost',
    port: parseInt(process.env.DATABASE_PORT || '3306'),
    username: process.env.DATABASE_USER || 'foodify',
    password: process.env.DATABASE_PASSWORD || 'foodify_pass',
    database: process.env.DATABASE_NAME || 'foodify_db',
  });

  await ds.initialize();
  console.log('🌱 Running seeds...');

  // ── 1. SaaS Plans ─────────────────────────────────
  const plans = [
    {
      name: 'Básico',
      price_mxn: 1500.00,
      max_branches: 1,
      max_menus: 2,
      features: JSON.stringify({
        pwa_menu: true,
        dish_management: true,
        qr_table: true,
        inventory: false,
        analytics: false,
        android_app: false,
        push_notifications: false,
      }),
      is_active: 1,
    },
    {
      name: 'Premium',
      price_mxn: 2500.00,
      max_branches: 3,
      max_menus: 5,
      features: JSON.stringify({
        pwa_menu: true,
        dish_management: true,
        qr_table: true,
        inventory: true,
        analytics: true,
        android_app: true,
        push_notifications: true,
        kitchen_module: true,
        staff_management: true,
      }),
      is_active: 1,
    },
    {
      name: 'Enterprise',
      price_mxn: 4500.00,
      max_branches: 10,
      max_menus: 20,
      features: JSON.stringify({
        pwa_menu: true,
        dish_management: true,
        qr_table: true,
        inventory: true,
        analytics: true,
        android_app: true,
        push_notifications: true,
        kitchen_module: true,
        staff_management: true,
        multi_branch: true,
        api_access: true,
        priority_support: true,
      }),
      is_active: 1,
    },
  ];

  for (const plan of plans) {
    const exists = await ds.query(
      'SELECT id FROM saas_plans WHERE name = ?', [plan.name]
    );
    if (exists.length === 0) {
      await ds.query(
        `INSERT INTO saas_plans (name, price_mxn, max_branches, max_menus, features, is_active)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [plan.name, plan.price_mxn, plan.max_branches, plan.max_menus, plan.features, plan.is_active]
      );
      console.log(`  ✅ Plan created: ${plan.name}`);
    } else {
      console.log(`  ⏭  Plan already exists: ${plan.name}`);
    }
  }

  // ── 2. SaaS Admin User (CODEX) ────────────────────
  const adminEmail = 'admin@codex.foodify.mx';
  const existingAdmin = await ds.query(
    'SELECT id FROM users WHERE email = ?', [adminEmail]
  );

  if (existingAdmin.length === 0) {
    const passwordHash = await bcrypt.hash('Codex2026!', 12);
    await ds.query(
      `INSERT INTO users (restaurant_id, role, full_name, email, password_hash, is_active)
       VALUES (NULL, 'saas_admin', 'CODEX Admin', ?, ?, 1)`,
      [adminEmail, passwordHash]
    );
    console.log(`  ✅ saas_admin created: ${adminEmail}`);
    console.log('  🔑 Default password: Codex2026! — CHANGE IT IMMEDIATELY IN PRODUCTION');
  } else {
    console.log(`  ⏭  saas_admin already exists: ${adminEmail}`);
  }

  // ── 3. Demo restaurant (optional) ─────────────────
  const demoSlug = 'demo-restaurant';
  const existingDemo = await ds.query(
    'SELECT id FROM restaurants WHERE slug = ?', [demoSlug]
  );

  if (existingDemo.length === 0) {
    const adminId = (await ds.query('SELECT id FROM users WHERE email = ?', [adminEmail]))[0]?.id;
    if (adminId) {
      // Create a restaurant_admin user
      const raHash = await bcrypt.hash('Demo2026!', 12);
      const raResult = await ds.query(
        `INSERT INTO users (restaurant_id, role, full_name, email, password_hash, is_active)
         VALUES (NULL, 'restaurant_admin', 'Admin Demo', 'admin@demo.foodify.mx', ?, 1)`,
        [raHash]
      );
      const raId = raResult.insertId;

      const restResult = await ds.query(
        `INSERT INTO restaurants (owner_id, name, slug, address, timezone, currency, is_active, dashboard_config)
         VALUES (?, 'Restaurante Demo', ?, 'Av. Principal #1, Guadalajara, Jalisco', 'America/Monterrey', 'MXN', 1, ?)`,
        [raId, demoSlug, JSON.stringify({
          show_sales: true, show_top_dishes: true, show_peak_hours: true,
          show_category_income: true, show_dishes_by_menu: true,
        })]
      );
      const restId = restResult.insertId;

      await ds.query('UPDATE users SET restaurant_id = ? WHERE id = ?', [restId, raId]);

      // Get plan id
      const plan = (await ds.query("SELECT id FROM saas_plans WHERE name = 'Básico'"))[0];
      const nextBilling = new Date(); nextBilling.setDate(nextBilling.getDate() + 30);
      await ds.query(
        `INSERT INTO saas_subscriptions
           (restaurant_id, plan_id, status, amount_mxn, billing_cycle_day, next_billing_at, current_period_end)
         VALUES (?, ?, 'trial', 1500.00, 1, ?, ?)`,
        [restId, plan.id, nextBilling, nextBilling]
      );

      console.log(`  ✅ Demo restaurant created (slug: ${demoSlug})`);
      console.log('  🔑 Demo admin: admin@demo.foodify.mx / Demo2026!');
    }
  } else {
    console.log('  ⏭  Demo restaurant already exists');
  }

  await ds.destroy();
  console.log('\n✅ Seeds completed successfully!\n');
}

runSeeds().catch((err) => {
  console.error('❌ Seed failed:', err);
  process.exit(1);
});
