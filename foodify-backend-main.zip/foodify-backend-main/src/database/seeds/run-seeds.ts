// Entrypoint esperado por el script "npm run seed"
import './initial-seed';

