import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Restaurant } from '../restaurants/entities/restaurant.entity';
import { SaasSubscription, SubscriptionStatus } from './entities/saas-subscription.entity';
import { SaasPlan } from './entities/saas-plan.entity';
import { PaymentTransaction, TransactionStatus } from '../payments/entities/payment-transaction.entity';
import { Order } from '../orders/entities/order.entity';
import { getPaginationParams, buildPaginationMeta } from '../../shared/utils/pagination';
import { getDateRange, Period } from '../../shared/utils/date-range';
import { differenceInDays } from 'date-fns';

@Injectable()
export class SaasService {
  constructor(
    @InjectRepository(Restaurant) private restaurantRepo: Repository<Restaurant>,
    @InjectRepository(SaasSubscription) private subRepo: Repository<SaasSubscription>,
    @InjectRepository(SaasPlan) private planRepo: Repository<SaasPlan>,
    @InjectRepository(PaymentTransaction) private txRepo: Repository<PaymentTransaction>,
    @InjectRepository(Order) private orderRepo: Repository<Order>,
  ) {}

  // ── GLOBAL KPIs ───────────────────────────────────
  async getGlobalKpis(period?: Period, start?: string, end?: string) {
    const range = period ? getDateRange(period, start, end) : null;

    const totalRestaurants = await this.restaurantRepo.count();

    const activeRestaurants = await this.subRepo
      .createQueryBuilder('s')
      .where("s.status = 'active'")
      .getCount();

    const mrr = await this.subRepo
      .createQueryBuilder('s')
      .select('SUM(s.amount_mxn)', 'total')
      .where("s.status = 'active'")
      .getRawOne();

    let newRegistrations = 0;
    let totalClients = 0;
    let periodRevenue = 0;

    if (range) {
      newRegistrations = await this.restaurantRepo
        .createQueryBuilder('r')
        .where('r.created_at BETWEEN :from AND :to', range)
        .getCount();

      const clientsResult = await this.orderRepo
        .createQueryBuilder('o')
        .select('COUNT(DISTINCT o.id)', 'total')
        .where('o.created_at BETWEEN :from AND :to AND o.status = :status', {
          ...range,
          status: 'delivered',
        })
        .getRawOne();
      totalClients = parseInt(clientsResult?.total || '0');

      const revenueResult = await this.txRepo
        .createQueryBuilder('t')
        .select('SUM(t.amount)', 'total')
        .where("t.status = 'success' AND t.paid_at BETWEEN :from AND :to", range)
        .getRawOne();
      periodRevenue = parseFloat(revenueResult?.total || '0');
    }

    return {
      totalRestaurants,
      activeRestaurants,
      mrr: parseFloat(mrr?.total || '0'),
      newRegistrations,
      totalClients,
      periodRevenue,
    };
  }

  // ── RESTAURANTS LIST ──────────────────────────────
  async listRestaurants(query: {
    page?: number; limit?: number; plan?: string;
    status?: string; search?: string;
  }) {
    const { skip, take, page, limit } = getPaginationParams(query);

    const qb = this.restaurantRepo
      .createQueryBuilder('r')
      .leftJoinAndSelect('r.owner', 'owner')
      .leftJoinAndSelect(
        'saas_subscriptions',
        'sub',
        'sub.restaurant_id = r.id',
      );

    if (query.search)
      qb.andWhere('r.name LIKE :search', { search: `%${query.search}%` });
    if (query.status)
      qb.andWhere('r.is_active = :active', { active: query.status === 'active' });

    qb.orderBy('r.created_at', 'DESC').skip(skip).take(take);
    const [restaurants, total] = await qb.getManyAndCount();

    const data = await Promise.all(
      restaurants.map(async (r) => {
        const sub = await this.subRepo.findOne({
          where: { restaurantId: r.id },
          relations: ['plan'],
          order: { createdAt: 'DESC' },
        });
        return {
          ...r,
          subscription: sub
            ? { ...sub, paymentStatus: this.computePaymentStatus(sub) }
            : null,
        };
      }),
    );

    return { data, meta: buildPaginationMeta(total, page, limit) };
  }

  async getRestaurantDetail(id: number) {
    const restaurant = await this.restaurantRepo.findOne({
      where: { id },
      relations: ['owner'],
    });
    if (!restaurant) throw new NotFoundException(`Restaurante #${id} no encontrado`);

    const subscription = await this.subRepo.findOne({
      where: { restaurantId: id },
      relations: ['plan'],
      order: { createdAt: 'DESC' },
    });

    const transactions = subscription
      ? await this.txRepo.find({
          where: { subscriptionId: subscription.id },
          order: { createdAt: 'DESC' },
          take: 10,
        })
      : [];

    return {
      restaurant,
      subscription: subscription
        ? { ...subscription, paymentStatus: this.computePaymentStatus(subscription) }
        : null,
      recentTransactions: transactions,
    };
  }

  async getRestaurantStats(id: number, period: Period, start?: string, end?: string, menuId?: number) {
    const range = getDateRange(period, start, end);

    const qb = this.orderRepo
      .createQueryBuilder('o')
      .innerJoin('o.items', 'oi')
      .innerJoin('oi.dish', 'd')
      .innerJoin('d.category', 'cat')
      .innerJoin('cat.menu', 'menu')
      .select([
        'menu.id AS menuId',
        'menu.name AS menuName',
        'cat.name AS categoryName',
        'd.name AS dishName',
        'SUM(oi.quantity) AS totalSold',
        'SUM(oi.quantity * oi.unit_price) AS revenue',
      ])
      .where('o.restaurant_id = :id AND o.delivered_at BETWEEN :from AND :to', { id, ...range })
      .groupBy('menu.id, cat.id, d.id')
      .orderBy('totalSold', 'DESC');

    if (menuId) qb.andWhere('menu.id = :menuId', { menuId });

    const rows = await qb.getRawMany();
    const totalSold = rows.reduce((s, r) => s + Number(r.totalSold), 0);
    return rows.map((r) => ({
      ...r,
      pctOfTotal: totalSold > 0 ? ((Number(r.totalSold) / totalSold) * 100).toFixed(2) : '0',
    }));
  }

  // ── SUBSCRIPTIONS ─────────────────────────────────
  async listSubscriptions(query: { page?: number; limit?: number }) {
    const { skip, take, page, limit } = getPaginationParams(query);
    const [subs, total] = await this.subRepo.findAndCount({
      relations: ['restaurant', 'plan'],
      order: { createdAt: 'DESC' },
      skip,
      take,
    });

    const data = subs.map((s) => ({
      ...s,
      paymentStatus: this.computePaymentStatus(s),
    }));

    return { data, meta: buildPaginationMeta(total, page, limit) };
  }

  async getSubscriptionDetail(id: number) {
    const sub = await this.subRepo.findOne({
      where: { id },
      relations: ['restaurant', 'plan'],
    });
    if (!sub) throw new NotFoundException(`Suscripción #${id} no encontrada`);

    const transactions = await this.txRepo.find({
      where: { subscriptionId: id },
      order: { createdAt: 'DESC' },
    });

    return {
      subscription: { ...sub, paymentStatus: this.computePaymentStatus(sub) },
      transactions,
    };
  }

  async updateSubscription(id: number, dto: { status?: SubscriptionStatus; planId?: number }) {
    const sub = await this.subRepo.findOne({ where: { id } });
    if (!sub) throw new NotFoundException(`Suscripción #${id} no encontrada`);
    if (dto.status) sub.status = dto.status;
    if (dto.planId) sub.planId = dto.planId;
    return this.subRepo.save(sub);
  }

  async getRestaurantMenus(restaurantId: number) {
    const result = await this.restaurantRepo.manager.query(`
      SELECT
        m.id, m.name, m.schedule, m.is_active,
        COUNT(DISTINCT mc.id) AS totalCategories,
        COUNT(DISTINCT d.id) AS totalDishes
      FROM menus m
      LEFT JOIN menu_categories mc ON mc.menu_id = m.id
      LEFT JOIN dishes d ON d.category_id = mc.id AND d.deleted_at IS NULL
      WHERE m.restaurant_id = ?
      GROUP BY m.id
      ORDER BY m.sort_order ASC
    `, [restaurantId]);
    return result;
  }

  // ── HELPERS ───────────────────────────────────────
  private computePaymentStatus(sub: SaasSubscription): string {
    const now = new Date();
    const daysUntilBilling = differenceInDays(sub.nextBillingAt, now);
    const daysPastDue = differenceInDays(now, sub.nextBillingAt);

    const disputeActive = false; // resolved from transactions in real use

    if (disputeActive) return 'dispute';
    if (sub.status === SubscriptionStatus.SUSPENDED || daysPastDue >= 15) return 'suspended';
    if (sub.status === SubscriptionStatus.PAST_DUE && daysPastDue < 15) return 'past_due';
    if (sub.status === SubscriptionStatus.ACTIVE && daysUntilBilling <= 7) return 'due_soon';
    if (sub.status === SubscriptionStatus.ACTIVE) return 'current';
    if (sub.status === SubscriptionStatus.TRIAL) return 'trial';
    if (sub.status === SubscriptionStatus.CANCELLED) return 'cancelled';
    return 'unknown';
  }

  // ── ALTA COMPLETA DE RESTAURANTE (transacción atómica) ────────
  async registerRestaurant(dto: {
    restaurantName: string; restaurantSlug: string; restaurantAddress?: string;
    restaurantTimezone?: string; adminFullName: string; adminEmail: string;
    adminPassword: string; adminPhone?: string; planId: number; trialDays?: number;
  }) {
    const bcrypt = await import('bcrypt');

    return this.restaurantRepo.manager.transaction(async (manager) => {
      // Check slug uniqueness
      const slugExists = await manager.query(
        'SELECT id FROM restaurants WHERE slug = ? LIMIT 1', [dto.restaurantSlug]
      );
      if (slugExists.length) throw new BadRequestException('El slug ya está en uso');

      // Check email uniqueness
      const emailExists = await manager.query(
        'SELECT id FROM users WHERE email = ? LIMIT 1', [dto.adminEmail]
      );
      if (emailExists.length) throw new BadRequestException('El email ya está registrado');

      // Validate plan
      const planRows = await manager.query(
        'SELECT id, name, price_mxn FROM saas_plans WHERE id = ? LIMIT 1', [dto.planId]
      );
      if (!planRows.length) throw new NotFoundException('Plan no encontrado');
      const plan = planRows[0];

      // Create admin user
      const passwordHash = await bcrypt.default.hash(dto.adminPassword, 12);
      const adminRes = await manager.query(
        `INSERT INTO users (restaurant_id, role, full_name, email, phone, password_hash, is_active)
         VALUES (NULL, 'restaurant_admin', ?, ?, ?, ?, 1)`,
        [dto.adminFullName, dto.adminEmail, dto.adminPhone || null, passwordHash]
      );
      const adminId = adminRes.insertId;

      // Create restaurant
      const dashConfig = JSON.stringify({ show_sales:true, show_top_dishes:true, show_peak_hours:true, show_category_income:true, show_dishes_by_menu:true });
      const restRes = await manager.query(
        `INSERT INTO restaurants (owner_id, name, slug, address, timezone, currency, is_active, dashboard_config)
         VALUES (?, ?, ?, ?, ?, 'MXN', 1, ?)`,
        [adminId, dto.restaurantName, dto.restaurantSlug, dto.restaurantAddress || null, dto.restaurantTimezone || 'America/Monterrey', dashConfig]
      );
      const restaurantId = restRes.insertId;

      // Link user to restaurant
      await manager.query('UPDATE users SET restaurant_id = ? WHERE id = ?', [restaurantId, adminId]);

      // Create trial subscription
      const trialDays = dto.trialDays ?? 30;
      const trialEnd = new Date(); trialEnd.setDate(trialEnd.getDate() + trialDays);
      const trialEndStr = trialEnd.toISOString().slice(0, 19).replace('T', ' ');
      await manager.query(
        `INSERT INTO saas_subscriptions (restaurant_id, plan_id, status, amount_mxn, billing_cycle_day, trial_ends_at, next_billing_at, current_period_end)
         VALUES (?, ?, 'trial', ?, 1, ?, ?, ?)`,
        [restaurantId, dto.planId, plan.price_mxn, trialEndStr, trialEndStr, trialEndStr]
      );

      return {
        restaurant: { id: restaurantId, name: dto.restaurantName, slug: dto.restaurantSlug },
        admin: { id: adminId, email: dto.adminEmail, role: 'restaurant_admin' },
        plan: { id: plan.id, name: plan.name },
        trialEndsAt: trialEnd,
        message: `Restaurante "${dto.restaurantName}" registrado en Plan ${plan.name} con ${trialDays} días de prueba.`,
      };
    });
  }

  // ── REGISTRAR PAGO MANUAL ─────────────────────────────────────
  async registerManualPayment(subscriptionId: number, dto: {
    amount: number; currency?: string; paymentMethod: string; reference?: string; notes?: string;
  }) {
    const sub = await this.subRepo.findOne({
      where: { id: subscriptionId }, relations: ['plan', 'restaurant'],
    });
    if (!sub) throw new NotFoundException(`Suscripción #${subscriptionId} no encontrada`);

    const tx = this.txRepo.create({
      subscriptionId,
      amount: dto.amount,
      currency: dto.currency || 'MXN',
      status: 'success' as any,
      paymentMethod: dto.paymentMethod,
      gatewayRef: dto.reference || `MANUAL-${Date.now()}`,
      paidAt: new Date(),
    });
    await this.txRepo.save(tx);

    const nextBilling = new Date();
    nextBilling.setMonth(nextBilling.getMonth() + 1);
    nextBilling.setDate(sub.billingCycleDay || 1);

    sub.status = 'active' as any;
    sub.nextBillingAt = nextBilling;
    sub.currentPeriodEnd = nextBilling;
    await this.subRepo.save(sub);

    return {
      message: `Pago de $${dto.amount} MXN registrado. Suscripción activa hasta ${nextBilling.toLocaleDateString('es-MX')}.`,
      transaction: tx,
      subscription: sub,
    };
  }

  // ── CAMBIAR ESTADO DE SUSCRIPCIÓN ────────────────────────────
  async updateSubscriptionStatus(subscriptionId: number, dto: { status: string; reason?: string }) {
    const sub = await this.subRepo.findOne({
      where: { id: subscriptionId }, relations: ['plan', 'restaurant'],
    });
    if (!sub) throw new NotFoundException(`Suscripción #${subscriptionId} no encontrada`);

    const prev = sub.status;
    sub.status = dto.status as any;

    if (dto.status === 'cancelled') {
      sub.cancelledAt = new Date();
      await this.restaurantRepo.update(sub.restaurantId, { isActive: false });
    }
    if (dto.status === 'active' && prev !== 'active') {
      await this.restaurantRepo.update(sub.restaurantId, { isActive: true });
    }
    if (dto.status === 'suspended') {
      await this.restaurantRepo.update(sub.restaurantId, { isActive: false });
    }

    await this.subRepo.save(sub);
    return { message: `Suscripción: ${prev} → ${dto.status}`, subscription: sub, reason: dto.reason };
  }

  // ── CAMBIAR PLAN ─────────────────────────────────────────────
  async changePlan(subscriptionId: number, newPlanId: number) {
    const sub = await this.subRepo.findOne({
      where: { id: subscriptionId }, relations: ['plan'],
    });
    if (!sub) throw new NotFoundException(`Suscripción #${subscriptionId} no encontrada`);

    const newPlan = await this.planRepo.findOne({ where: { id: newPlanId } });
    if (!newPlan) throw new NotFoundException(`Plan #${newPlanId} no encontrado`);

    const oldName = sub.plan?.name;
    sub.planId = newPlanId;
    sub.amountMxn = newPlan.priceMxn;
    await this.subRepo.save(sub);

    return {
      message: `Plan cambiado: ${oldName} → ${newPlan.name}. Activo de inmediato.`,
      newPlan: { id: newPlan.id, name: newPlan.name, price: newPlan.priceMxn },
    };
  }
}
