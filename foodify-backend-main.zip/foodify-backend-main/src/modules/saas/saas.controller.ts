import {
  Controller, Get, Patch, Post, Body,
  Param, ParseIntPipe, Query, UseGuards,
} from '@nestjs/common';
import { SaasService } from './saas.service';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';
import { RolesGuard } from '../../shared/guards/roles.guard';
import { Roles, UserRole } from '../../shared/decorators/roles.decorator';
import { Period } from '../../shared/utils/date-range';

@Controller('api/v1/admin')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(UserRole.SAAS_ADMIN)
export class SaasController {
  constructor(private readonly saasService: SaasService) {}

  @Get('dashboard/kpis')
  getKpis(@Query('period') period?: Period, @Query('start') start?: string, @Query('end') end?: string) {
    return this.saasService.getGlobalKpis(period, start, end);
  }

  @Post('restaurants/register')
  registerRestaurant(@Body() dto: any) { return this.saasService.registerRestaurant(dto); }

  @Get('restaurants')
  listRestaurants(@Query('page') page?: number, @Query('limit') limit?: number, @Query('plan') plan?: string, @Query('status') status?: string, @Query('search') search?: string) {
    return this.saasService.listRestaurants({ page, limit, plan, status, search });
  }

  @Get('restaurants/:id')
  getRestaurant(@Param('id', ParseIntPipe) id: number) { return this.saasService.getRestaurantDetail(id); }

  @Get('restaurants/:id/stats')
  getRestaurantStats(@Param('id', ParseIntPipe) id: number, @Query('period') period: Period = 'month', @Query('start') start?: string, @Query('end') end?: string, @Query('menuId') menuId?: number) {
    return this.saasService.getRestaurantStats(id, period, start, end, menuId);
  }

  @Get('restaurants/:id/menus')
  getRestaurantMenus(@Param('id', ParseIntPipe) id: number) { return this.saasService.getRestaurantMenus(id); }

  @Get('restaurants/:id/dishes/sold')
  getDishesSold(@Param('id', ParseIntPipe) id: number, @Query('period') period: Period = 'month', @Query('start') start?: string, @Query('end') end?: string, @Query('menuId') menuId?: number) {
    return this.saasService.getRestaurantStats(id, period, start, end, menuId);
  }

  @Get('subscriptions')
  listSubscriptions(@Query('page') page?: number, @Query('limit') limit?: number) { return this.saasService.listSubscriptions({ page, limit }); }

  @Get('subscriptions/:id')
  getSubscription(@Param('id', ParseIntPipe) id: number) { return this.saasService.getSubscriptionDetail(id); }

  @Patch('subscriptions/:id')
  updateSubscription(@Param('id', ParseIntPipe) id: number, @Body() body: any) { return this.saasService.updateSubscription(id, body); }

  @Patch('subscriptions/:id/status')
  updateSubStatus(@Param('id', ParseIntPipe) id: number, @Body() dto: { status: string; reason?: string }) { return this.saasService.updateSubscriptionStatus(id, dto); }

  @Patch('subscriptions/:id/plan')
  changeSubPlan(@Param('id', ParseIntPipe) id: number, @Body('planId', ParseIntPipe) planId: number) { return this.saasService.changePlan(id, planId); }

  @Post('subscriptions/:id/payment')
  registerPayment(@Param('id', ParseIntPipe) id: number, @Body() dto: any) { return this.saasService.registerManualPayment(id, dto); }

  @Post('subscriptions/:id/reminder')
  sendReminder(@Param('id', ParseIntPipe) id: number) { return { message: `Recordatorio enviado para suscripción #${id}` }; }
}
