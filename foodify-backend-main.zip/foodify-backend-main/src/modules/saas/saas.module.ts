import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SaasService } from './saas.service';
import { SaasController } from './saas.controller';
import { SaasPlan } from './entities/saas-plan.entity';
import { SaasSubscription } from './entities/saas-subscription.entity';
import { Restaurant } from '../restaurants/entities/restaurant.entity';
import { PaymentTransaction } from '../payments/entities/payment-transaction.entity';
import { Order } from '../orders/entities/order.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      SaasPlan, SaasSubscription, Restaurant, PaymentTransaction, Order,
    ]),
  ],
  controllers: [SaasController],
  providers: [SaasService],
  exports: [SaasService, TypeOrmModule],
})
export class SaasModule {}
