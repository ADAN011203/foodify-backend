import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Restaurant } from '../restaurants/entities/restaurant.entity';
import { Menu } from '../menus/entities/menu.entity';
import { Dish } from '../dishes/entities/dish.entity';
import { isMenuActiveNow, getAvailabilityNote, formatScheduleText } from '../../shared/utils/schedule';

export interface PublicDish {
  id: number;
  name: string;
  description: string;
  price: number;
  prepTimeMin: number;
  images: string[];
  allergens: string[];
  isAvailable: boolean;
  isOrderableNow: boolean;
  availabilityNote: string | null;
}

export interface PublicCategory {
  id: number;
  name: string;
  description: string;
  icon: string;
  sortOrder: number;
  dishes: PublicDish[];
}

export interface PublicMenu {
  id: number;
  name: string;
  description: string;
  isActiveNow: boolean;
  allowOutsideSchedule: boolean;
  scheduleText: string | null;
  schedule: any;
  sortOrder: number;
  totalDishes: number;
  categories: PublicCategory[];
}

export interface PublicMenuResponse {
  restaurant: {
    name: string;
    logoUrl: string | null;
    address: string | null;
    currency: string;
    timezone: string;
  };
  currentTime: string;
  tableNumber: number | null;
  activeMenuIds: number[];
  menus: PublicMenu[];
}

@Injectable()
export class PublicMenuService {
  constructor(
    @InjectRepository(Restaurant) private restaurantRepo: Repository<Restaurant>,
    @InjectRepository(Menu) private menuRepo: Repository<Menu>,
    @InjectRepository(Dish) private dishRepo: Repository<Dish>,
  ) {}

  async getPublicMenu(slug: string, tableNumber?: number): Promise<PublicMenuResponse> {
    // 1. Buscar restaurante por slug
    const restaurant = await this.restaurantRepo.findOne({
      where: { slug, isActive: true },
    });
    if (!restaurant) {
      throw new NotFoundException(`Menú no encontrado para "${slug}"`);
    }

    // 2. Obtener menús activos con sus categorías y platillos
    const menus = await this.menuRepo.find({
      where: { restaurantId: restaurant.id, isActive: true },
      relations: ['categories', 'categories.dishes'],
      order: { sortOrder: 'ASC', createdAt: 'ASC' },
    });

    const timezone = restaurant.timezone || 'America/Monterrey';

    // Hora actual en el timezone del restaurante para mostrar en la respuesta
    const currentTime = new Date().toLocaleTimeString('es-MX', {
      timeZone: timezone,
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    });

    // 3. Procesar cada menú
    const processedMenus: PublicMenu[] = menus.map((menu) => {
      const isActiveNow = isMenuActiveNow(menu.schedule, timezone);

      // Procesar categorías y platillos
      const categories: PublicCategory[] = (menu.categories || [])
        .filter((cat) => cat.isActive)
        .sort((a, b) => a.sortOrder - b.sortOrder)
        .map((cat) => {
          const dishes: PublicDish[] = (cat.dishes || [])
            .filter((dish) => !dish.deletedAt && dish.isAvailable)
            .sort((a, b) => a.sortOrder - b.sortOrder)
            .map((dish) => {
              // Un platillo se puede ordenar si:
              // - El menú está activo ahora, O
              // - El menú permite pedidos fuera de horario
              const isOrderableNow = isActiveNow || menu.allowOutsideSchedule;

              return {
                id: dish.id,
                name: dish.name,
                description: dish.description,
                price: Number(dish.price),
                prepTimeMin: dish.prepTimeMin,
                images: dish.images || [],
                allergens: dish.allergens || [],
                isAvailable: dish.isAvailable,
                isOrderableNow,
                // Nota de horario solo si no está en horario activo
                availabilityNote: getAvailabilityNote(menu.schedule, isActiveNow),
              };
            });

          return {
            id: cat.id,
            name: cat.name,
            description: cat.description,
            icon: cat.icon,
            sortOrder: cat.sortOrder,
            dishes,
          };
        })
        // Omitir categorías vacías (sin platillos disponibles)
        .filter((cat) => cat.dishes.length > 0);

      const totalDishes = categories.reduce((s, c) => s + c.dishes.length, 0);

      return {
        id: menu.id,
        name: menu.name,
        description: menu.description,
        isActiveNow,
        allowOutsideSchedule: menu.allowOutsideSchedule,
        scheduleText: formatScheduleText(menu.schedule),
        schedule: menu.schedule,
        sortOrder: menu.sortOrder,
        totalDishes,
        categories,
      };
    });

    // 4. IDs de menús activos ahora (para que el frontend sepa cuál tab seleccionar)
    const activeMenuIds = processedMenus
      .filter((m) => m.isActiveNow)
      .map((m) => m.id);

    return {
      restaurant: {
        name: restaurant.name,
        logoUrl: restaurant.logoUrl,
        address: restaurant.address,
        currency: restaurant.currency,
        timezone: restaurant.timezone,
      },
      currentTime,
      tableNumber: tableNumber || null,
      activeMenuIds,
      menus: processedMenus,
    };
  }
}
