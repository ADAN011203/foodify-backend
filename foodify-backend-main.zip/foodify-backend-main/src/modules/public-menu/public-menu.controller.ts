import { Controller, Get, Param, Query } from '@nestjs/common';
import { PublicMenuService } from './public-menu.service';
import { Public } from '../../shared/decorators/public.decorator';

/**
 * Endpoints públicos del menú del restaurante.
 * NO requieren autenticación JWT — son para los comensales
 * que escanean el QR de la mesa.
 */
@Controller('menu')
export class PublicMenuController {
  constructor(private readonly publicMenuService: PublicMenuService) {}

  /**
   * GET /menu/:slug
   * GET /menu/:slug?table=5
   *
   * Retorna el menú completo del restaurante con:
   * - Todos los menús activos (is_active = true)
   * - Platillos disponibles (is_available = true, deleted_at IS NULL)
   * - Clasificación por horario (isActiveNow, isOrderableNow)
   * - Nota de disponibilidad para platillos fuera de horario
   */
  @Public()
  @Get(':slug')
  getMenu(
    @Param('slug') slug: string,
    @Query('table') table?: number,
  ) {
    return this.publicMenuService.getPublicMenu(slug, table ? Number(table) : undefined);
  }
}
