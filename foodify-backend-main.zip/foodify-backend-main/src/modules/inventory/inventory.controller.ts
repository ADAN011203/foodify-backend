import {
  Controller, Get, Post, Put, Delete, Patch,
  Body, Param, ParseIntPipe, Query, UseGuards,
} from '@nestjs/common';
import { InventoryService } from './inventory.service';
import {
  CreateItemDto, UpdateItemDto, CreateLotDto,
  UpdateLotDto, AdjustmentDto,
} from './dto/inventory.dto';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';
import { RolesGuard } from '../../shared/guards/roles.guard';
import { Roles, UserRole } from '../../shared/decorators/roles.decorator';
import { CurrentUser } from '../../shared/decorators/current-user.decorator';
import { User } from '../users/entities/user.entity';

@Controller('api/v1/inventory')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(UserRole.RESTAURANT_ADMIN, UserRole.MANAGER)
export class InventoryController {
  constructor(private readonly inventoryService: InventoryService) {}

  // ── ITEMS ────────────────────────────────────────
  @Post('items')
  createItem(@CurrentUser() user: User, @Body() dto: CreateItemDto) {
    return this.inventoryService.createItem(user.restaurantId, dto);
  }

  @Get('items')
  findItems(
    @CurrentUser() user: User,
    @Query('page') page?: number,
    @Query('limit') limit?: number,
  ) {
    return this.inventoryService.findAllItems(user.restaurantId, { page, limit });
  }

  @Get('items/:id')
  findItem(@Param('id', ParseIntPipe) id: number) {
    return this.inventoryService.findOneItem(id);
  }

  @Put('items/:id')
  updateItem(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateItemDto) {
    return this.inventoryService.updateItem(id, dto);
  }

  // ── LOTS ─────────────────────────────────────────
  @Post('lots')
  createLot(@CurrentUser() user: User, @Body() dto: CreateLotDto) {
    return this.inventoryService.createLot(user.restaurantId, dto, user.id);
  }

  @Get('lots')
  findLots(
    @CurrentUser() user: User,
    @Query('page') page?: number,
    @Query('limit') limit?: number,
    @Query('itemId') itemId?: number,
    @Query('status') status?: string,
    @Query('expiringSoon') expiringSoon?: boolean,
  ) {
    return this.inventoryService.findAllLots(user.restaurantId, {
      page, limit, itemId, status, expiringSoon,
    });
  }

  @Put('lots/:id')
  updateLot(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateLotDto) {
    return this.inventoryService.updateLot(id, dto);
  }

  @Delete('lots/:id')
  removeLot(@Param('id', ParseIntPipe) id: number, @CurrentUser() user: User) {
    return this.inventoryService.removeLot(id, user.id);
  }

  // ── MOVEMENTS ────────────────────────────────────
  @Get('movements')
  findMovements(
    @CurrentUser() user: User,
    @Query('page') page?: number,
    @Query('limit') limit?: number,
    @Query('lotId') lotId?: number,
    @Query('type') type?: string,
    @Query('dateFrom') dateFrom?: string,
    @Query('dateTo') dateTo?: string,
  ) {
    return this.inventoryService.findMovements(user.restaurantId, {
      page, limit, lotId, type, dateFrom, dateTo,
    });
  }

  @Post('adjustments')
  createAdjustment(@CurrentUser() user: User, @Body() dto: AdjustmentDto) {
    return this.inventoryService.createAdjustment(user.restaurantId, dto, user.id);
  }

  // ── ALERTS ───────────────────────────────────────
  @Get('alerts')
  findAlerts(@CurrentUser() user: User) {
    return this.inventoryService.findAlerts(user.restaurantId);
  }

  @Patch('alerts/:id/resolve')
  resolveAlert(@Param('id', ParseIntPipe) id: number) {
    return this.inventoryService.resolveAlert(id);
  }
}
