import {
  IsString, IsOptional, IsNumber, IsEnum,
  IsDateString, Min, IsBoolean,
} from 'class-validator';
import { MovementType } from '../entities/inventory-movement.entity';

export class CreateItemDto {
  @IsString()
  name: string;

  @IsString()
  unit: string;

  @IsOptional()
  @IsNumber()
  @Min(0)
  minStock?: number;

  @IsOptional()
  @IsString()
  category?: string;
}

export class UpdateItemDto {
  @IsOptional()
  @IsString()
  name?: string;

  @IsOptional()
  @IsNumber()
  @Min(0)
  minStock?: number;

  @IsOptional()
  @IsString()
  category?: string;
}

export class CreateLotDto {
  @IsNumber()
  itemId: number;

  @IsOptional()
  @IsString()
  lotNumber?: string;

  @IsNumber()
  @Min(0)
  quantity: number;

  @IsNumber()
  @Min(0)
  unitCost: number;

  @IsOptional()
  @IsString()
  supplier?: string;

  @IsDateString()
  entryDate: string;

  @IsOptional()
  @IsDateString()
  expiryDate?: string;
}

export class UpdateLotDto {
  @IsOptional()
  @IsString()
  lotNumber?: string;

  @IsOptional()
  @IsString()
  supplier?: string;

  @IsOptional()
  @IsDateString()
  expiryDate?: string;
}

export class AdjustmentDto {
  @IsNumber()
  itemId: number;

  @IsNumber()
  lotId: number;

  @IsNumber()
  quantity: number;

  @IsEnum(MovementType)
  type: MovementType;

  @IsOptional()
  @IsString()
  notes?: string;
}
