import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  ManyToOne, JoinColumn, OneToMany,
} from 'typeorm';
import { Restaurant } from '../../restaurants/entities/restaurant.entity';
import { InventoryLot } from './inventory-lot.entity';
import { InventoryAlert } from './inventory-alert.entity';

@Entity('inventory_items')
export class InventoryItem {
  @PrimaryGeneratedColumn({ unsigned: true })
  id: number;

  @Column({ name: 'restaurant_id', unsigned: true })
  restaurantId: number;

  @Column({ length: 120 })
  name: string;

  @Column({ length: 20 })
  unit: string;

  @Column({ name: 'min_stock', type: 'decimal', precision: 10, scale: 3, default: 0 })
  minStock: number;

  @Column({ name: 'current_stock', type: 'decimal', precision: 10, scale: 3, default: 0 })
  currentStock: number;

  @Column({ length: 60, nullable: true })
  category: string;

  @Column({ name: 'image_url', length: 255, nullable: true })
  imageUrl: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => Restaurant, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'restaurant_id' })
  restaurant: Restaurant;

  @OneToMany(() => InventoryLot, (lot) => lot.item)
  lots: InventoryLot[];

  @OneToMany(() => InventoryAlert, (alert) => alert.item)
  alerts: InventoryAlert[];
}
