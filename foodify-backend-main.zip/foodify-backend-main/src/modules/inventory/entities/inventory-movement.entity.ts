import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  ManyToOne, JoinColumn,
} from 'typeorm';
import { InventoryLot } from './inventory-lot.entity';
import { User } from '../../users/entities/user.entity';

export enum MovementType {
  SALE = 'sale',
  WASTE = 'waste',
  ADJUSTMENT = 'adjustment',
  ENTRY = 'entry',
}

@Entity('inventory_movements')
export class InventoryMovement {
  @PrimaryGeneratedColumn({ unsigned: true })
  id: number;

  @Column({ name: 'lot_id', unsigned: true })
  lotId: number;

  @Column({ name: 'order_id', unsigned: true, nullable: true })
  orderId: number;

  @Column({ type: 'enum', enum: MovementType })
  type: MovementType;

  @Column({ type: 'decimal', precision: 10, scale: 3 })
  quantity: number;

  @Column({ length: 255, nullable: true })
  notes: string;

  @Column({ name: 'created_by', unsigned: true, nullable: true })
  createdBy: number;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => InventoryLot, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'lot_id' })
  lot: InventoryLot;

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'created_by' })
  creator: User;
}
