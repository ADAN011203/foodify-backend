import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  ManyToOne, JoinColumn,
} from 'typeorm';
import { InventoryItem } from './inventory-item.entity';

export enum LotStatus {
  AVAILABLE = 'available',
  LOW = 'low',
  CRITICAL = 'critical',
  EXPIRED = 'expired',
  DEPLETED = 'depleted',
}

@Entity('inventory_lots')
export class InventoryLot {
  @PrimaryGeneratedColumn({ unsigned: true })
  id: number;

  @Column({ name: 'item_id', unsigned: true })
  itemId: number;

  @Column({ name: 'lot_number', length: 50, nullable: true })
  lotNumber: string;

  @Column({ type: 'decimal', precision: 10, scale: 3 })
  quantity: number;

  @Column({ type: 'decimal', precision: 10, scale: 3 })
  remaining: number;

  @Column({ name: 'unit_cost', type: 'decimal', precision: 10, scale: 4 })
  unitCost: number;

  @Column({ length: 120, nullable: true })
  supplier: string;

  @Column({ name: 'entry_date', type: 'date' })
  entryDate: Date;

  @Column({ name: 'expiry_date', type: 'date', nullable: true })
  expiryDate: Date;

  @Column({ type: 'enum', enum: LotStatus, default: LotStatus.AVAILABLE })
  status: LotStatus;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => InventoryItem, (item) => item.lots, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'item_id' })
  item: InventoryItem;
}
