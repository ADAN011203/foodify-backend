import {
  Injectable, NotFoundException, BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { InventoryItem } from './entities/inventory-item.entity';
import { InventoryLot, LotStatus } from './entities/inventory-lot.entity';
import { InventoryMovement, MovementType } from './entities/inventory-movement.entity';
import { InventoryAlert, AlertType } from './entities/inventory-alert.entity';
import {
  CreateItemDto, UpdateItemDto, CreateLotDto,
  UpdateLotDto, AdjustmentDto,
} from './dto/inventory.dto';
import { getPaginationParams, buildPaginationMeta } from '../../shared/utils/pagination';

@Injectable()
export class InventoryService {
  constructor(
    @InjectRepository(InventoryItem) private itemRepo: Repository<InventoryItem>,
    @InjectRepository(InventoryLot) private lotRepo: Repository<InventoryLot>,
    @InjectRepository(InventoryMovement) private movRepo: Repository<InventoryMovement>,
    @InjectRepository(InventoryAlert) private alertRepo: Repository<InventoryAlert>,
    private dataSource: DataSource,
  ) {}

  // ── ITEMS ────────────────────────────────────────
  async createItem(restaurantId: number, dto: CreateItemDto): Promise<InventoryItem> {
    const item = this.itemRepo.create({ ...dto, restaurantId, minStock: dto.minStock ?? 0 });
    return this.itemRepo.save(item);
  }

  async findAllItems(restaurantId: number, query: { page?: number; limit?: number }) {
    const { skip, take, page, limit } = getPaginationParams(query);
    const [items, total] = await this.itemRepo.findAndCount({
      where: { restaurantId },
      relations: ['alerts'],
      order: { name: 'ASC' },
      skip,
      take,
    });
    return { data: items, meta: buildPaginationMeta(total, page, limit) };
  }

  async findOneItem(id: number): Promise<InventoryItem> {
    const item = await this.itemRepo.findOne({
      where: { id },
      relations: ['lots', 'alerts'],
    });
    if (!item) throw new NotFoundException(`Insumo #${id} no encontrado`);
    return item;
  }

  async updateItem(id: number, dto: UpdateItemDto): Promise<InventoryItem> {
    const item = await this.findOneItem(id);
    Object.assign(item, dto);
    return this.itemRepo.save(item);
  }

  // ── LOTS ─────────────────────────────────────────
  async createLot(restaurantId: number, dto: CreateLotDto, userId: number): Promise<InventoryLot> {
    const item = await this.findOneItem(dto.itemId);

    const lot = this.lotRepo.create({
      itemId: dto.itemId,
      lotNumber: dto.lotNumber,
      quantity: dto.quantity,
      remaining: dto.quantity,
      unitCost: dto.unitCost,
      supplier: dto.supplier,
      entryDate: new Date(dto.entryDate),
      expiryDate: dto.expiryDate ? new Date(dto.expiryDate) : null,
    });
    const saved = await this.lotRepo.save(lot);

    // Record entry movement
    await this.movRepo.save({
      lotId: saved.id,
      type: MovementType.ENTRY,
      quantity: dto.quantity,
      notes: `Entrada de lote ${dto.lotNumber || saved.id}`,
      createdBy: userId,
    });

    // Update item stock
    await this.recalcStock(dto.itemId);

    return saved;
  }

  async findAllLots(restaurantId: number, query: {
    page?: number; limit?: number; itemId?: number;
    status?: string; expiringSoon?: boolean;
  }) {
    const { skip, take, page, limit } = getPaginationParams(query);
    const qb = this.lotRepo
      .createQueryBuilder('l')
      .innerJoin('l.item', 'item')
      .addSelect(['item.name', 'item.unit'])
      .where('item.restaurant_id = :restaurantId', { restaurantId })
      .andWhere("l.status != 'depleted'");

    if (query.itemId) qb.andWhere('l.item_id = :itemId', { itemId: query.itemId });
    if (query.status) qb.andWhere('l.status = :status', { status: query.status });
    if (query.expiringSoon) {
      const soon = new Date();
      soon.setDate(soon.getDate() + 7);
      qb.andWhere('l.expiry_date IS NOT NULL AND l.expiry_date <= :soon', { soon });
    }

    qb.orderBy('l.entry_date', 'ASC').skip(skip).take(take);
    const [lots, total] = await qb.getManyAndCount();
    return { data: lots, meta: buildPaginationMeta(total, page, limit) };
  }

  async updateLot(id: number, dto: UpdateLotDto): Promise<InventoryLot> {
    const lot = await this.lotRepo.findOne({ where: { id } });
    if (!lot) throw new NotFoundException(`Lote #${id} no encontrado`);
    Object.assign(lot, dto);
    return this.lotRepo.save(lot);
  }

  async removeLot(id: number, userId: number): Promise<void> {
    const lot = await this.lotRepo.findOne({ where: { id } });
    if (!lot) throw new NotFoundException(`Lote #${id} no encontrado`);

    // Record waste movement
    if (lot.remaining > 0) {
      await this.movRepo.save({
        lotId: id,
        type: MovementType.WASTE,
        quantity: lot.remaining,
        notes: 'Baja manual del lote',
        createdBy: userId,
      });
    }

    lot.status = LotStatus.DEPLETED;
    lot.remaining = 0;
    await this.lotRepo.save(lot);
    await this.recalcStock(lot.itemId);
  }

  // ── MOVEMENTS ────────────────────────────────────
  async findMovements(restaurantId: number, query: {
    page?: number; limit?: number; lotId?: number;
    type?: string; dateFrom?: string; dateTo?: string;
  }) {
    const { skip, take, page, limit } = getPaginationParams(query);
    const qb = this.movRepo
      .createQueryBuilder('m')
      .innerJoin('m.lot', 'lot')
      .innerJoin('lot.item', 'item')
      .where('item.restaurant_id = :restaurantId', { restaurantId });

    if (query.lotId) qb.andWhere('m.lot_id = :lotId', { lotId: query.lotId });
    if (query.type) qb.andWhere('m.type = :type', { type: query.type });
    if (query.dateFrom) qb.andWhere('m.created_at >= :from', { from: new Date(query.dateFrom) });
    if (query.dateTo) qb.andWhere('m.created_at <= :to', { to: new Date(query.dateTo) });

    qb.orderBy('m.created_at', 'DESC').skip(skip).take(take);
    const [movements, total] = await qb.getManyAndCount();
    return { data: movements, meta: buildPaginationMeta(total, page, limit) };
  }

  async createAdjustment(restaurantId: number, dto: AdjustmentDto, userId: number) {
    const lot = await this.lotRepo.findOne({ where: { id: dto.lotId } });
    if (!lot) throw new NotFoundException(`Lote #${dto.lotId} no encontrado`);

    if (dto.type === MovementType.WASTE || dto.type === MovementType.SALE) {
      if (lot.remaining < dto.quantity)
        throw new BadRequestException('Stock insuficiente en el lote');
      lot.remaining -= dto.quantity;
    } else if (dto.type === MovementType.ADJUSTMENT) {
      lot.remaining = dto.quantity;
    }

    await this.lotRepo.save(lot);
    await this.movRepo.save({
      lotId: dto.lotId,
      type: dto.type,
      quantity: dto.quantity,
      notes: dto.notes,
      createdBy: userId,
    });
    await this.recalcStock(lot.itemId);
    return { message: 'Ajuste registrado correctamente' };
  }

  // ── ALERTS ───────────────────────────────────────
  async findAlerts(restaurantId: number): Promise<InventoryAlert[]> {
    return this.alertRepo
      .createQueryBuilder('a')
      .innerJoin('a.item', 'item')
      .where('item.restaurant_id = :restaurantId AND a.is_resolved = false', { restaurantId })
      .orderBy('a.created_at', 'DESC')
      .getMany();
  }

  async resolveAlert(id: number): Promise<InventoryAlert> {
    const alert = await this.alertRepo.findOne({ where: { id } });
    if (!alert) throw new NotFoundException(`Alerta #${id} no encontrada`);
    alert.isResolved = true;
    return this.alertRepo.save(alert);
  }

  // ── FIFO DEDUCTION (called by trigger/orders service) ────
  async deductFifo(
    itemId: number,
    quantityNeeded: number,
    orderId: number,
    userId?: number,
  ): Promise<void> {
    await this.dataSource.transaction(async (manager) => {
      // Get lots ordered by entry_date ASC (FIFO)
      const lots = await manager
        .createQueryBuilder(InventoryLot, 'lot')
        .where('lot.item_id = :itemId AND lot.remaining > 0 AND lot.status NOT IN (:...statuses)', {
          itemId,
          statuses: [LotStatus.DEPLETED, LotStatus.EXPIRED],
        })
        .orderBy('lot.entry_date', 'ASC')
        .getMany();

      let remaining = quantityNeeded;
      for (const lot of lots) {
        if (remaining <= 0) break;
        const deduct = Math.min(lot.remaining, remaining);
        lot.remaining -= deduct;
        remaining -= deduct;

        if (lot.remaining === 0) lot.status = LotStatus.DEPLETED;
        await manager.save(lot);

        await manager.save(InventoryMovement, {
          lotId: lot.id,
          orderId,
          type: MovementType.SALE,
          quantity: deduct,
          notes: `Venta pedido #${orderId}`,
          createdBy: userId,
        });
      }

      // Recalc stock and check alerts
      await this.recalcStockInTransaction(manager, itemId);
    });
  }

  // ── HELPERS ──────────────────────────────────────
  async recalcStock(itemId: number): Promise<void> {
    const result = await this.lotRepo
      .createQueryBuilder('l')
      .select('SUM(l.remaining)', 'total')
      .where("l.item_id = :itemId AND l.status NOT IN ('depleted','expired')", { itemId })
      .getRawOne();

    const total = parseFloat(result?.total || '0');
    await this.itemRepo.update(itemId, { currentStock: total });

    // Check alerts
    const item = await this.itemRepo.findOne({ where: { id: itemId } });
    if (item && total === 0) {
      await this.createAlertIfNotExists(itemId, AlertType.OUT_OF_STOCK, `${item.name} sin stock`);
    } else if (item && total < item.minStock && total > 0) {
      await this.createAlertIfNotExists(itemId, AlertType.LOW_STOCK, `${item.name} por debajo del mínimo`);
    }
  }

  private async recalcStockInTransaction(manager: any, itemId: number): Promise<void> {
    const result = await manager
      .createQueryBuilder(InventoryLot, 'l')
      .select('SUM(l.remaining)', 'total')
      .where("l.item_id = :itemId AND l.status NOT IN ('depleted','expired')", { itemId })
      .getRawOne();

    const total = parseFloat(result?.total || '0');
    await manager.update(InventoryItem, itemId, { currentStock: total });
  }

  private async createAlertIfNotExists(itemId: number, type: AlertType, message: string) {
    const exists = await this.alertRepo.findOne({
      where: { itemId, type, isResolved: false },
    });
    if (!exists) {
      await this.alertRepo.save({ itemId, type, message });
    }
  }
}
