import {
  Injectable, NotFoundException, ConflictException, ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Restaurant } from './entities/restaurant.entity';
import {
  CreateRestaurantDto, UpdateRestaurantDto, UpdateDashboardConfigDto,
} from './dto/restaurant.dto';
import { uploadToS3 } from '../../shared/utils/s3-upload';
import { UserRole } from '../../shared/decorators/roles.decorator';
import { User } from '../users/entities/user.entity';

@Injectable()
export class RestaurantsService {
  constructor(
    @InjectRepository(Restaurant) private restaurantRepo: Repository<Restaurant>,
  ) {}

  async create(dto: CreateRestaurantDto, ownerId: number): Promise<Restaurant> {
    const slugExists = await this.restaurantRepo.findOne({ where: { slug: dto.slug } });
    if (slugExists) throw new ConflictException('El slug ya está en uso');

    const restaurant = this.restaurantRepo.create({
      ...dto,
      ownerId,
      dashboardConfig: {
        show_sales: true,
        show_top_dishes: true,
        show_peak_hours: true,
        show_category_income: true,
        show_dishes_by_menu: true,
      },
    });
    return this.restaurantRepo.save(restaurant);
  }

  async findAll(user: User): Promise<Restaurant[]> {
    if (user.role === UserRole.SAAS_ADMIN) {
      return this.restaurantRepo.find({ relations: ['owner'] });
    }
    return this.restaurantRepo.find({
      where: { ownerId: user.id },
      relations: ['owner'],
    });
  }

  async findOne(id: number): Promise<Restaurant> {
    const r = await this.restaurantRepo.findOne({ where: { id }, relations: ['owner'] });
    if (!r) throw new NotFoundException(`Restaurante #${id} no encontrado`);
    return r;
  }

  async update(id: number, dto: UpdateRestaurantDto, user: User): Promise<Restaurant> {
    const r = await this.findOne(id);
    this.checkOwnership(r, user);
    Object.assign(r, dto);
    return this.restaurantRepo.save(r);
  }

  async uploadLogo(id: number, file: Express.Multer.File, user: User): Promise<Restaurant> {
    const r = await this.findOne(id);
    this.checkOwnership(r, user);
    const url = await uploadToS3(file, 'logos');
    r.logoUrl = url;
    return this.restaurantRepo.save(r);
  }

  async setStatus(id: number, isActive: boolean, user: User): Promise<Restaurant> {
    const r = await this.findOne(id);
    if (user.role !== UserRole.SAAS_ADMIN) this.checkOwnership(r, user);
    r.isActive = isActive;
    return this.restaurantRepo.save(r);
  }

  async updateDashboardConfig(id: number, dto: UpdateDashboardConfigDto, user: User): Promise<Restaurant> {
    const r = await this.findOne(id);
    this.checkOwnership(r, user);
    r.dashboardConfig = { ...r.dashboardConfig, ...dto };
    return this.restaurantRepo.save(r);
  }

  async getDashboardKpis(restaurantId: number) {
    // KPIs del restaurante — se expanden en módulo Reports
    const r = await this.findOne(restaurantId);
    return { restaurant: r.name, dashboardConfig: r.dashboardConfig };
  }

  private checkOwnership(restaurant: Restaurant, user: User) {
    if (
      user.role !== UserRole.SAAS_ADMIN &&
      restaurant.ownerId !== user.id &&
      restaurant.id !== user.restaurantId
    ) {
      throw new ForbiddenException('No tienes permisos sobre este restaurante');
    }
  }
}
