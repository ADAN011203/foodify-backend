import {
  Controller, Get, Post, Put, Patch, Body, Param,
  ParseIntPipe, UseGuards, UseInterceptors,
  UploadedFile,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { memoryStorage } from 'multer';
import { RestaurantsService } from './restaurants.service';
import { CreateRestaurantDto, UpdateRestaurantDto, UpdateDashboardConfigDto } from './dto/restaurant.dto';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';
import { RolesGuard } from '../../shared/guards/roles.guard';
import { Roles, UserRole } from '../../shared/decorators/roles.decorator';
import { CurrentUser } from '../../shared/decorators/current-user.decorator';
import { User } from '../users/entities/user.entity';

@Controller('api/v1/restaurants')
@UseGuards(JwtAuthGuard, RolesGuard)
export class RestaurantsController {
  constructor(private readonly restaurantsService: RestaurantsService) {}

  @Post()
  @Roles(UserRole.SAAS_ADMIN, UserRole.RESTAURANT_ADMIN)
  create(@Body() dto: CreateRestaurantDto, @CurrentUser() user: User) {
    return this.restaurantsService.create(dto, user.id);
  }

  @Get()
  findAll(@CurrentUser() user: User) {
    return this.restaurantsService.findAll(user);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.restaurantsService.findOne(id);
  }

  @Put(':id')
  @Roles(UserRole.RESTAURANT_ADMIN, UserRole.SAAS_ADMIN)
  update(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateRestaurantDto,
    @CurrentUser() user: User,
  ) {
    return this.restaurantsService.update(id, dto, user);
  }

  @Put(':id/logo')
  @Roles(UserRole.RESTAURANT_ADMIN, UserRole.SAAS_ADMIN)
  @UseInterceptors(FileInterceptor('file', { storage: memoryStorage() }))
  uploadLogo(
    @Param('id', ParseIntPipe) id: number,
    @UploadedFile() file: Express.Multer.File,
    @CurrentUser() user: User,
  ) {
    return this.restaurantsService.uploadLogo(id, file, user);
  }

  @Patch(':id/status')
  @Roles(UserRole.RESTAURANT_ADMIN, UserRole.SAAS_ADMIN)
  setStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body('isActive') isActive: boolean,
    @CurrentUser() user: User,
  ) {
    return this.restaurantsService.setStatus(id, isActive, user);
  }

  @Patch(':id/settings')
  @Roles(UserRole.RESTAURANT_ADMIN)
  updateSettings(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateDashboardConfigDto,
    @CurrentUser() user: User,
  ) {
    return this.restaurantsService.updateDashboardConfig(id, dto, user);
  }

  @Get(':id/dashboard')
  @Roles(UserRole.RESTAURANT_ADMIN, UserRole.MANAGER)
  getDashboard(
    @Param('id', ParseIntPipe) id: number,
    @CurrentUser() user: User,
  ) {
    return this.restaurantsService.getDashboardKpis(id);
  }
}
