import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  ManyToOne, JoinColumn, OneToMany,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';

@Entity('restaurants')
export class Restaurant {
  @PrimaryGeneratedColumn({ unsigned: true })
  id: number;

  @Column({ name: 'owner_id', unsigned: true })
  ownerId: number;

  @Column({ length: 120 })
  name: string;

  @Column({ length: 120, unique: true })
  slug: string;

  @Column({ name: 'logo_url', length: 255, nullable: true })
  logoUrl: string;

  @Column({ length: 255, nullable: true })
  address: string;

  @Column({ length: 50, default: 'America/Monterrey' })
  timezone: string;

  @Column({ length: 3, default: 'MXN' })
  currency: string;

  @Column({ name: 'is_active', default: true })
  isActive: boolean;

  @Column({ name: 'dashboard_config', type: 'json', nullable: true })
  dashboardConfig: {
    show_sales: boolean;
    show_top_dishes: boolean;
    show_peak_hours: boolean;
    show_category_income: boolean;
    show_dishes_by_menu: boolean;
  };

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => User, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'owner_id' })
  owner: User;
}
