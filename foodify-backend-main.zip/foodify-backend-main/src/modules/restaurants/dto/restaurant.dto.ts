import { IsString, IsOptional, IsBoolean, IsObject } from 'class-validator';

export class CreateRestaurantDto {
  @IsString()
  name: string;

  @IsString()
  slug: string;

  @IsOptional()
  @IsString()
  address?: string;

  @IsOptional()
  @IsString()
  timezone?: string;

  @IsOptional()
  @IsString()
  currency?: string;
}

export class UpdateRestaurantDto {
  @IsOptional()
  @IsString()
  name?: string;

  @IsOptional()
  @IsString()
  address?: string;

  @IsOptional()
  @IsString()
  timezone?: string;
}

export class UpdateDashboardConfigDto {
  @IsOptional()
  @IsBoolean()
  show_sales?: boolean;

  @IsOptional()
  @IsBoolean()
  show_top_dishes?: boolean;

  @IsOptional()
  @IsBoolean()
  show_peak_hours?: boolean;

  @IsOptional()
  @IsBoolean()
  show_category_income?: boolean;

  @IsOptional()
  @IsBoolean()
  show_dishes_by_menu?: boolean;
}
