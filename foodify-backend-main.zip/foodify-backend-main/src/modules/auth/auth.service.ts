import {
  Injectable, UnauthorizedException, BadRequestException,
  NotFoundException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { User } from '../users/entities/user.entity';
import { RefreshToken } from './entities/refresh-token.entity';
import { SaasSubscription, SubscriptionStatus } from '../saas/entities/saas-subscription.entity';
import { LoginDto, RefreshTokenDto, ForgotPasswordDto, VerifyOtpDto, ResetPasswordDto } from './dto/login.dto';

@Injectable()
export class AuthService {
  private otpStore = new Map<string, { otp: string; expiry: number }>();
  private resetTokenStore = new Map<string, { userId: number; expiry: number }>();

  constructor(
    @InjectRepository(User) private userRepo: Repository<User>,
    @InjectRepository(RefreshToken) private tokenRepo: Repository<RefreshToken>,
    @InjectRepository(SaasSubscription) private subRepo: Repository<SaasSubscription>,
    private jwtService: JwtService,
  ) {}

  async login(dto: LoginDto) {
    const user = await this.userRepo.findOne({ where: { email: dto.email } });
    if (!user) throw new UnauthorizedException('Credenciales incorrectas');
    if (!user.isActive) throw new UnauthorizedException('Cuenta inactiva');
    const valid = await bcrypt.compare(dto.password, user.passwordHash);
    if (!valid) throw new UnauthorizedException('Credenciales incorrectas');

    if (user.restaurantId && user.role !== 'saas_admin') {
      const sub = await this.subRepo.findOne({
        where: { restaurantId: user.restaurantId },
        relations: ['plan'],
        order: { createdAt: 'DESC' },
      });
      if (sub) {
        if (sub.status === SubscriptionStatus.SUSPENDED)
          throw new UnauthorizedException({ code: 'ACCOUNT_SUSPENDED', message: 'Cuenta suspendida. Contacta a soporte.' });
        if (sub.status === SubscriptionStatus.CANCELLED)
          throw new UnauthorizedException({ code: 'ACCOUNT_CANCELLED', message: 'Cuenta cancelada.' });
        if (['waiter', 'chef'].includes(user.role) && sub.plan?.features?.['android_app'] !== true)
          throw new UnauthorizedException({ code: 'FEATURE_NOT_IN_PLAN', message: `Plan "${sub.plan?.name}" no incluye la App Móvil. Actualiza a Premium.` });
      }
    }

    await this.userRepo.update(user.id, { lastLoginAt: new Date() });
    const tokens = await this.generateTokens(user);
    return { user: this.sanitizeUser(user), ...tokens };
  }

  async refresh(dto: RefreshTokenDto) {
    let payload: any;
    try { payload = this.jwtService.verify(dto.refreshToken, { secret: process.env.JWT_REFRESH_SECRET }); }
    catch { throw new UnauthorizedException('Refresh token inválido o expirado'); }
    const stored = await this.tokenRepo.findOne({ where: { userId: payload.sub, revoked: false } });
    if (!stored) throw new UnauthorizedException('Token revocado');
    const user = await this.userRepo.findOne({ where: { id: payload.sub, isActive: true } });
    if (!user) throw new UnauthorizedException('Usuario no encontrado');
    await this.tokenRepo.update(stored.id, { revoked: true });
    return this.generateTokens(user);
  }

  async logout(userId: number) {
    await this.tokenRepo.createQueryBuilder().update().set({ revoked: true }).where('user_id = :userId AND revoked = false', { userId }).execute();
    return { message: 'Sesión cerrada' };
  }

  async forgotPassword(dto: ForgotPasswordDto) {
    const user = await this.userRepo.findOne({ where: { email: dto.email } });
    if (!user) return { message: 'Si el email existe, recibirás un OTP' };
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    this.otpStore.set(dto.email, { otp, expiry: Date.now() + 15 * 60 * 1000 });
    console.log(`[DEV] OTP for ${dto.email}: ${otp}`);
    return { message: 'OTP enviado' };
  }

  async verifyOtp(dto: VerifyOtpDto) {
    const stored = this.otpStore.get(dto.email);
    if (!stored || stored.otp !== dto.otp || Date.now() > stored.expiry) throw new BadRequestException('OTP inválido o expirado');
    this.otpStore.delete(dto.email);
    const user = await this.userRepo.findOne({ where: { email: dto.email } });
    if (!user) throw new NotFoundException('Usuario no encontrado');
    const resetToken = this.jwtService.sign({ sub: user.id, purpose: 'reset' }, { secret: process.env.JWT_ACCESS_SECRET, expiresIn: '15m' });
    this.resetTokenStore.set(resetToken, { userId: user.id, expiry: Date.now() + 15 * 60 * 1000 });
    return { resetToken };
  }

  async resetPassword(dto: ResetPasswordDto) {
    const stored = this.resetTokenStore.get(dto.resetToken);
    if (!stored || Date.now() > stored.expiry) throw new BadRequestException('Token inválido o expirado');
    this.resetTokenStore.delete(dto.resetToken);
    await this.userRepo.update(stored.userId, { passwordHash: await bcrypt.hash(dto.newPassword, 12) });
    return { message: 'Contraseña actualizada' };
  }

  async getProfile(userId: number) {
    const user = await this.userRepo.findOne({ where: { id: userId }, relations: ['restaurant'] });
    if (!user) throw new NotFoundException('Usuario no encontrado');
    return this.sanitizeUser(user);
  }

  async updateFcmToken(userId: number, fcmToken: string) {
    await this.userRepo.update(userId, { fcmToken });
    return { message: 'FCM token actualizado' };
  }

  private async generateTokens(user: User) {
    let planName: string | null = null;
    let subscriptionStatus: string | null = null;
    if (user.restaurantId) {
      const sub = await this.subRepo.findOne({ where: { restaurantId: user.restaurantId }, relations: ['plan'], order: { createdAt: 'DESC' } });
      if (sub) { planName = sub.plan?.name ?? null; subscriptionStatus = sub.status ?? null; }
    }
    const payload = { sub: user.id, email: user.email, role: user.role, restaurantId: user.restaurantId, planName, subscriptionStatus };
    const accessToken  = this.jwtService.sign(payload, { secret: process.env.JWT_ACCESS_SECRET,  expiresIn: process.env.JWT_ACCESS_EXPIRES  || '15m' });
    const refreshToken = this.jwtService.sign(payload, { secret: process.env.JWT_REFRESH_SECRET, expiresIn: process.env.JWT_REFRESH_EXPIRES || '30d' });
    const expiresAt = new Date(); expiresAt.setDate(expiresAt.getDate() + 30);
    await this.tokenRepo.createQueryBuilder().update().set({ revoked: true }).where('user_id = :userId AND revoked = false', { userId: user.id }).execute();
    await this.tokenRepo.save({ userId: user.id, tokenHash: await bcrypt.hash(refreshToken, 10), expiresAt });
    return { accessToken, refreshToken };
  }

  private sanitizeUser(user: User) {
    const { passwordHash, fcmToken, ...safe } = user as any;
    return safe;
  }
}
