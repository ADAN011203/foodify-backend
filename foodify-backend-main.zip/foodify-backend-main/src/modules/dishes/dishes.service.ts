import {
  Injectable, NotFoundException, BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Dish } from './entities/dish.entity';
import { Recipe } from '../recipes/entities/recipe.entity';
import { RecipeIngredient } from '../recipes/entities/recipe-ingredient.entity';
import {
  CreateDishDto, UpdateDishDto, CreateRecipeDto,
  CreateIngredientDto, UpdateIngredientDto,
} from './dto/dish.dto';
import { uploadToS3 } from '../../shared/utils/s3-upload';
import { getPaginationParams, buildPaginationMeta } from '../../shared/utils/pagination';

@Injectable()
export class DishesService {
  constructor(
    @InjectRepository(Dish) private dishRepo: Repository<Dish>,
    @InjectRepository(Recipe) private recipeRepo: Repository<Recipe>,
    @InjectRepository(RecipeIngredient) private ingredientRepo: Repository<RecipeIngredient>,
  ) {}

  // ── DISHES CRUD ──────────────────────────────────
  async create(restaurantId: number, dto: CreateDishDto): Promise<Dish> {
    const dish = this.dishRepo.create({ ...dto, restaurantId });
    return this.dishRepo.save(dish);
  }

  async findAll(restaurantId: number, query: {
    page?: number; limit?: number; categoryId?: number;
    available?: boolean; search?: string; menuId?: number;
  }) {
    const { skip, take, page, limit } = getPaginationParams(query);
    const qb = this.dishRepo
      .createQueryBuilder('d')
      .leftJoinAndSelect('d.category', 'cat')
      .leftJoinAndSelect('cat.menu', 'menu')
      .where('d.restaurant_id = :restaurantId AND d.deleted_at IS NULL', { restaurantId });

    if (query.categoryId) qb.andWhere('d.category_id = :catId', { catId: query.categoryId });
    if (query.available !== undefined) qb.andWhere('d.is_available = :available', { available: query.available });
    if (query.search) qb.andWhere('d.name LIKE :search', { search: `%${query.search}%` });
    if (query.menuId) qb.andWhere('menu.id = :menuId', { menuId: query.menuId });

    qb.orderBy('d.sort_order', 'ASC').addOrderBy('d.name', 'ASC').skip(skip).take(take);
    const [dishes, total] = await qb.getManyAndCount();
    return { data: dishes, meta: buildPaginationMeta(total, page, limit) };
  }

  async findOne(id: number): Promise<Dish> {
    const dish = await this.dishRepo.findOne({
      where: { id, deletedAt: null },
      relations: ['category', 'recipe', 'recipe.ingredients', 'recipe.ingredients.inventoryItem'],
    });
    if (!dish) throw new NotFoundException(`Platillo #${id} no encontrado`);
    return dish;
  }

  async update(id: number, dto: UpdateDishDto): Promise<Dish> {
    const dish = await this.findOne(id);
    Object.assign(dish, dto);
    return this.dishRepo.save(dish);
  }

  async toggleAvailability(id: number): Promise<Dish> {
    const dish = await this.findOne(id);
    dish.isAvailable = !dish.isAvailable;
    return this.dishRepo.save(dish);
  }

  async softDelete(id: number): Promise<void> {
    const dish = await this.findOne(id);
    dish.deletedAt = new Date();
    await this.dishRepo.save(dish);
  }

  async uploadImages(id: number, files: Express.Multer.File[]): Promise<Dish> {
    const dish = await this.findOne(id);
    if (files.length > 3) throw new BadRequestException('Máximo 3 imágenes por platillo');
    const urls = await Promise.all(files.map((f) => uploadToS3(f, 'dishes')));
    dish.images = urls;
    return this.dishRepo.save(dish);
  }

  // ── RECIPES ──────────────────────────────────────
  async getRecipe(dishId: number): Promise<Recipe> {
    const recipe = await this.recipeRepo.findOne({
      where: { dishId },
      relations: ['ingredients', 'ingredients.inventoryItem'],
    });
    if (!recipe) throw new NotFoundException(`Receta del platillo #${dishId} no encontrada`);
    return recipe;
  }

  async saveRecipe(dishId: number, dto: CreateRecipeDto): Promise<Recipe> {
    await this.dishRepo.findOne({ where: { id: dishId, deletedAt: null } })
      .then((d) => { if (!d) throw new NotFoundException(`Platillo #${dishId} no encontrado`); });

    // Upsert recipe
    let recipe = await this.recipeRepo.findOne({ where: { dishId } });
    if (!recipe) {
      recipe = this.recipeRepo.create({ dishId });
    }
    Object.assign(recipe, {
      prepTimeMin: dto.prepTimeMin,
      servings: dto.servings,
      steps: dto.steps,
      notes: dto.notes,
    });
    const saved = await this.recipeRepo.save(recipe);

    if (dto.ingredients) {
      await this.ingredientRepo.delete({ recipeId: saved.id });
      const ingredients = dto.ingredients.map((i) =>
        this.ingredientRepo.create({ ...i, recipeId: saved.id }),
      );
      await this.ingredientRepo.save(ingredients);
    }

    return this.getRecipe(dishId);
  }

  async addIngredient(dishId: number, dto: CreateIngredientDto): Promise<RecipeIngredient> {
    const recipe = await this.recipeRepo.findOne({ where: { dishId } });
    if (!recipe) throw new NotFoundException(`Receta no encontrada para platillo #${dishId}`);
    const ingredient = this.ingredientRepo.create({ ...dto, recipeId: recipe.id });
    return this.ingredientRepo.save(ingredient);
  }

  async updateIngredient(ingredientId: number, dto: UpdateIngredientDto): Promise<RecipeIngredient> {
    const ingredient = await this.ingredientRepo.findOne({ where: { id: ingredientId } });
    if (!ingredient) throw new NotFoundException(`Ingrediente #${ingredientId} no encontrado`);
    Object.assign(ingredient, dto);
    return this.ingredientRepo.save(ingredient);
  }

  async removeIngredient(ingredientId: number): Promise<void> {
    const ingredient = await this.ingredientRepo.findOne({ where: { id: ingredientId } });
    if (!ingredient) throw new NotFoundException(`Ingrediente #${ingredientId} no encontrado`);
    await this.ingredientRepo.remove(ingredient);
  }
}
