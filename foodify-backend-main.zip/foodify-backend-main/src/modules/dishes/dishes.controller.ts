import {
  Controller, Get, Post, Put, Patch, Delete,
  Body, Param, ParseIntPipe, Query,
  UseGuards, UseInterceptors, UploadedFiles,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import { memoryStorage } from 'multer';
import { DishesService } from './dishes.service';
import {
  CreateDishDto, UpdateDishDto, CreateRecipeDto,
  CreateIngredientDto, UpdateIngredientDto,
} from './dto/dish.dto';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';
import { RolesGuard } from '../../shared/guards/roles.guard';
import { Roles, UserRole } from '../../shared/decorators/roles.decorator';
import { CurrentUser } from '../../shared/decorators/current-user.decorator';
import { User } from '../users/entities/user.entity';

@Controller('api/v1/dishes')
@UseGuards(JwtAuthGuard, RolesGuard)
export class DishesController {
  constructor(private readonly dishesService: DishesService) {}

  @Post()
  @Roles(UserRole.RESTAURANT_ADMIN)
  create(@CurrentUser() user: User, @Body() dto: CreateDishDto) {
    return this.dishesService.create(user.restaurantId, dto);
  }

  @Get()
  findAll(
    @CurrentUser() user: User,
    @Query('page') page?: number,
    @Query('limit') limit?: number,
    @Query('categoryId') categoryId?: number,
    @Query('available') available?: boolean,
    @Query('search') search?: string,
    @Query('menuId') menuId?: number,
  ) {
    return this.dishesService.findAll(user.restaurantId, {
      page, limit, categoryId, available, search, menuId,
    });
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.dishesService.findOne(id);
  }

  @Put(':id')
  @Roles(UserRole.RESTAURANT_ADMIN)
  update(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateDishDto) {
    return this.dishesService.update(id, dto);
  }

  @Patch(':id/availability')
  @Roles(UserRole.RESTAURANT_ADMIN, UserRole.MANAGER)
  toggleAvailability(@Param('id', ParseIntPipe) id: number) {
    return this.dishesService.toggleAvailability(id);
  }

  @Delete(':id')
  @Roles(UserRole.RESTAURANT_ADMIN)
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.dishesService.softDelete(id);
  }

  @Put(':id/images')
  @Roles(UserRole.RESTAURANT_ADMIN)
  @UseInterceptors(FilesInterceptor('files', 3, { storage: memoryStorage() }))
  uploadImages(
    @Param('id', ParseIntPipe) id: number,
    @UploadedFiles() files: Express.Multer.File[],
  ) {
    return this.dishesService.uploadImages(id, files);
  }

  // ── Recipe endpoints ──────────────────────────────
  @Get(':id/recipe')
  getRecipe(@Param('id', ParseIntPipe) id: number) {
    return this.dishesService.getRecipe(id);
  }

  @Put(':id/recipe')
  @Roles(UserRole.RESTAURANT_ADMIN, UserRole.CHEF)
  saveRecipe(@Param('id', ParseIntPipe) id: number, @Body() dto: CreateRecipeDto) {
    return this.dishesService.saveRecipe(id, dto);
  }

  @Post(':id/recipe/ingredients')
  @Roles(UserRole.RESTAURANT_ADMIN, UserRole.CHEF)
  addIngredient(@Param('id', ParseIntPipe) id: number, @Body() dto: CreateIngredientDto) {
    return this.dishesService.addIngredient(id, dto);
  }

  @Put(':id/recipe/ingredients/:iid')
  @Roles(UserRole.RESTAURANT_ADMIN, UserRole.CHEF)
  updateIngredient(
    @Param('iid', ParseIntPipe) iid: number,
    @Body() dto: UpdateIngredientDto,
  ) {
    return this.dishesService.updateIngredient(iid, dto);
  }

  @Delete(':id/recipe/ingredients/:iid')
  @Roles(UserRole.RESTAURANT_ADMIN, UserRole.CHEF)
  removeIngredient(@Param('iid', ParseIntPipe) iid: number) {
    return this.dishesService.removeIngredient(iid);
  }
}
