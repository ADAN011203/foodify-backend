import {
  IsString, IsOptional, IsNumber, IsBoolean,
  IsArray, Min, IsInt,
} from 'class-validator';

export class CreateDishDto {
  @IsString()
  name: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsNumber()
  @Min(0)
  price: number;

  @IsOptional()
  @IsInt()
  categoryId?: number;

  @IsOptional()
  @IsInt()
  prepTimeMin?: number;

  @IsOptional()
  @IsArray()
  allergens?: string[];

  @IsOptional()
  @IsInt()
  sortOrder?: number;
}

export class UpdateDishDto {
  @IsOptional()
  @IsString()
  name?: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsOptional()
  @IsNumber()
  price?: number;

  @IsOptional()
  @IsInt()
  categoryId?: number;

  @IsOptional()
  @IsInt()
  prepTimeMin?: number;

  @IsOptional()
  @IsArray()
  allergens?: string[];

  @IsOptional()
  @IsBoolean()
  isAvailable?: boolean;

  @IsOptional()
  @IsInt()
  sortOrder?: number;
}

export class CreateRecipeDto {
  @IsOptional()
  @IsInt()
  prepTimeMin?: number;

  @IsOptional()
  @IsInt()
  servings?: number;

  @IsOptional()
  @IsArray()
  steps?: { order: number; description: string }[];

  @IsOptional()
  @IsString()
  notes?: string;

  @IsOptional()
  @IsArray()
  ingredients?: CreateIngredientDto[];
}

export class CreateIngredientDto {
  @IsOptional()
  @IsInt()
  itemId?: number;

  @IsString()
  name: string;

  @IsNumber()
  quantity: number;

  @IsString()
  unit: string;

  @IsOptional()
  @IsBoolean()
  isOptional?: boolean;
}

export class UpdateIngredientDto {
  @IsOptional()
  @IsNumber()
  quantity?: number;

  @IsOptional()
  @IsString()
  unit?: string;

  @IsOptional()
  @IsBoolean()
  isOptional?: boolean;
}
