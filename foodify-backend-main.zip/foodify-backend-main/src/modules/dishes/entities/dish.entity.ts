import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  ManyToOne, JoinColumn, OneToOne,
} from 'typeorm';
import { Restaurant } from '../../restaurants/entities/restaurant.entity';
import { MenuCategory } from '../../categories/entities/menu-category.entity';
import { Recipe } from '../../recipes/entities/recipe.entity';

@Entity('dishes')
export class Dish {
  @PrimaryGeneratedColumn({ unsigned: true })
  id: number;

  @Column({ name: 'restaurant_id', unsigned: true })
  restaurantId: number;

  @Column({ name: 'category_id', unsigned: true, nullable: true })
  categoryId: number;

  @Column({ length: 120 })
  name: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  price: number;

  @Column({ name: 'cost_est', type: 'decimal', precision: 10, scale: 2, default: 0 })
  costEst: number;

  @Column({
    name: 'margin_pct',
    type: 'decimal',
    precision: 5,
    scale: 2,
    generatedType: 'STORED',
    asExpression: '((price - cost_est) / price) * 100',
    nullable: true,
  })
  marginPct: number;

  @Column({ name: 'prep_time_min', type: 'tinyint', default: 15 })
  prepTimeMin: number;

  @Column({ name: 'is_available', default: true })
  isAvailable: boolean;

  @Column({ type: 'json', nullable: true })
  images: string[];

  @Column({ type: 'json', nullable: true })
  allergens: string[];

  @Column({ name: 'sort_order', type: 'smallint', default: 0 })
  sortOrder: number;

  @Column({ name: 'deleted_at', nullable: true })
  deletedAt: Date;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => Restaurant, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'restaurant_id' })
  restaurant: Restaurant;

  @ManyToOne(() => MenuCategory, (cat) => cat.dishes, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'category_id' })
  category: MenuCategory;

  @OneToOne(() => Recipe, (recipe) => recipe.dish, { nullable: true })
  recipe: Recipe;
}
