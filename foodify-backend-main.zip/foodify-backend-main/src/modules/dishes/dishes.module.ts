import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DishesService } from './dishes.service';
import { DishesController } from './dishes.controller';
import { Dish } from './entities/dish.entity';
import { Recipe } from '../recipes/entities/recipe.entity';
import { RecipeIngredient } from '../recipes/entities/recipe-ingredient.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Dish, Recipe, RecipeIngredient])],
  controllers: [DishesController],
  providers: [DishesService],
  exports: [DishesService, TypeOrmModule],
})
export class DishesModule {}
