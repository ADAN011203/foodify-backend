import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MenusService } from './menus.service';
import { MenusController } from './menus.controller';
import { Menu } from './entities/menu.entity';
import { CategoriesModule } from '../categories/categories.module';

@Module({
  imports: [TypeOrmModule.forFeature([Menu]), CategoriesModule],
  controllers: [MenusController],
  providers: [MenusService],
  exports: [MenusService, TypeOrmModule],
})
export class MenusModule {}
