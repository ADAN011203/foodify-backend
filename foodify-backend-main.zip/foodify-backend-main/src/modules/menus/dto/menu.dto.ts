import { IsString, IsOptional, IsBoolean, IsNumber } from 'class-validator';

export class ScheduleDto {
  days: number[];
  start: string;
  end: string;
}

export class CreateMenuDto {
  @IsString()
  name: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsOptional()
  schedule?: ScheduleDto;

  @IsOptional()
  @IsBoolean()
  allowOutsideSchedule?: boolean;

  @IsOptional()
  @IsNumber()
  sortOrder?: number;
}

export class UpdateMenuDto {
  @IsOptional()
  @IsString()
  name?: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsOptional()
  schedule?: ScheduleDto;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;

  /**
   * true  = acepta pedidos fuera del horario (default)
   * false = solo en horario definido en schedule
   */
  @IsOptional()
  @IsBoolean()
  allowOutsideSchedule?: boolean;

  @IsOptional()
  @IsNumber()
  sortOrder?: number;
}
