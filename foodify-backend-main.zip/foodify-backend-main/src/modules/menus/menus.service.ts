import {
  Injectable, NotFoundException, ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Menu } from './entities/menu.entity';
import { CreateMenuDto, UpdateMenuDto } from './dto/menu.dto';

@Injectable()
export class MenusService {
  constructor(
    @InjectRepository(Menu) private menuRepo: Repository<Menu>,
  ) {}

  async create(restaurantId: number, dto: CreateMenuDto): Promise<Menu> {
    const menu = this.menuRepo.create({ ...dto, restaurantId });
    return this.menuRepo.save(menu);
  }

  async findAll(restaurantId: number): Promise<Menu[]> {
    return this.menuRepo.find({
      where: { restaurantId },
      relations: ['categories'],
      order: { sortOrder: 'ASC', createdAt: 'DESC' },
    });
  }

  async findOne(id: number): Promise<Menu> {
    const menu = await this.menuRepo.findOne({
      where: { id },
      relations: ['categories', 'categories.dishes'],
    });
    if (!menu) throw new NotFoundException(`Menú #${id} no encontrado`);
    return menu;
  }

  async update(id: number, restaurantId: number, dto: UpdateMenuDto): Promise<Menu> {
    const menu = await this.findOne(id);
    this.checkOwnership(menu, restaurantId);
    Object.assign(menu, dto);
    return this.menuRepo.save(menu);
  }

  async setStatus(id: number, restaurantId: number, isActive: boolean): Promise<Menu> {
    const menu = await this.findOne(id);
    this.checkOwnership(menu, restaurantId);
    menu.isActive = isActive;
    return this.menuRepo.save(menu);
  }

  async remove(id: number, restaurantId: number): Promise<void> {
    const menu = await this.findOne(id);
    this.checkOwnership(menu, restaurantId);
    await this.menuRepo.remove(menu);
  }

  private checkOwnership(menu: Menu, restaurantId: number) {
    if (menu.restaurantId !== restaurantId)
      throw new ForbiddenException('No tienes permisos sobre este menú');
  }
}
