import {
  Controller, Get, Post, Put, Patch, Delete,
  Body, Param, ParseIntPipe, UseGuards,
} from '@nestjs/common';
import { MenusService } from './menus.service';
import { CreateMenuDto, UpdateMenuDto } from './dto/menu.dto';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';
import { RolesGuard } from '../../shared/guards/roles.guard';
import { Roles, UserRole } from '../../shared/decorators/roles.decorator';
import { CurrentUser } from '../../shared/decorators/current-user.decorator';
import { User } from '../users/entities/user.entity';
import { CategoriesService } from '../categories/categories.service';
import { CreateCategoryDto, UpdateCategoryDto } from '../categories/dto/category.dto';

@Controller('api/v1/menus')
@UseGuards(JwtAuthGuard, RolesGuard)
export class MenusController {
  constructor(
    private readonly menusService: MenusService,
    private readonly categoriesService: CategoriesService,
  ) {}

  @Post()
  @Roles(UserRole.RESTAURANT_ADMIN)
  create(@CurrentUser() user: User, @Body() dto: CreateMenuDto) {
    return this.menusService.create(user.restaurantId, dto);
  }

  @Get()
  @Roles(UserRole.RESTAURANT_ADMIN, UserRole.MANAGER, UserRole.WAITER, UserRole.CHEF, UserRole.CASHIER)
  findAll(@CurrentUser() user: User) {
    return this.menusService.findAll(user.restaurantId);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.menusService.findOne(id);
  }

  @Put(':id')
  @Roles(UserRole.RESTAURANT_ADMIN)
  update(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateMenuDto,
    @CurrentUser() user: User,
  ) {
    return this.menusService.update(id, user.restaurantId, dto);
  }

  @Patch(':id/status')
  @Roles(UserRole.RESTAURANT_ADMIN)
  setStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body('isActive') isActive: boolean,
    @CurrentUser() user: User,
  ) {
    return this.menusService.setStatus(id, user.restaurantId, isActive);
  }

  @Delete(':id')
  @Roles(UserRole.RESTAURANT_ADMIN)
  remove(@Param('id', ParseIntPipe) id: number, @CurrentUser() user: User) {
    return this.menusService.remove(id, user.restaurantId);
  }

  // ── Categories nested under menu ──────────────────
  @Get(':id/categories')
  getCategories(@Param('id', ParseIntPipe) menuId: number) {
    return this.categoriesService.findByMenu(menuId);
  }

  @Post(':id/categories')
  @Roles(UserRole.RESTAURANT_ADMIN)
  createCategory(
    @Param('id', ParseIntPipe) menuId: number,
    @Body() dto: CreateCategoryDto,
  ) {
    return this.categoriesService.create(menuId, dto);
  }

  @Put(':id/categories/:catId')
  @Roles(UserRole.RESTAURANT_ADMIN)
  updateCategory(
    @Param('catId', ParseIntPipe) catId: number,
    @Body() dto: UpdateCategoryDto,
  ) {
    return this.categoriesService.update(catId, dto);
  }

  @Patch(':id/categories/:catId/sort')
  @Roles(UserRole.RESTAURANT_ADMIN)
  sortCategory(
    @Param('catId', ParseIntPipe) catId: number,
    @Body('sortOrder') sortOrder: number,
  ) {
    return this.categoriesService.updateSort(catId, sortOrder);
  }

  @Delete(':id/categories/:catId')
  @Roles(UserRole.RESTAURANT_ADMIN)
  removeCategory(@Param('catId', ParseIntPipe) catId: number) {
    return this.categoriesService.remove(catId);
  }
}
