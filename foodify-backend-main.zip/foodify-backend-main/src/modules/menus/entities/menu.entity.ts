import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  ManyToOne, JoinColumn, OneToMany,
} from 'typeorm';
import { Restaurant } from '../../restaurants/entities/restaurant.entity';
import { MenuCategory } from '../../categories/entities/menu-category.entity';

@Entity('menus')
export class Menu {
  @PrimaryGeneratedColumn({ unsigned: true })
  id: number;

  @Column({ name: 'restaurant_id', unsigned: true })
  restaurantId: number;

  @Column({ length: 100 })
  name: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ name: 'is_active', default: true })
  isActive: boolean;

  @Column({ type: 'json', nullable: true })
  schedule: {
    days: number[];   // 0=Dom, 1=Lun ... 6=Sab
    start: string;    // "12:00"
    end: string;      // "16:00"
  };

  /**
   * true  = acepta pedidos fuera del horario (default — mayoría de restaurantes)
   * false = solo se puede pedir en el horario definido en schedule
   */
  @Column({ name: 'allow_outside_schedule', default: true })
  allowOutsideSchedule: boolean;

  @Column({ name: 'sort_order', type: 'smallint', default: 0 })
  sortOrder: number;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => Restaurant, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'restaurant_id' })
  restaurant: Restaurant;

  @OneToMany(() => MenuCategory, (cat) => cat.menu, { cascade: true })
  categories: MenuCategory[];
}
