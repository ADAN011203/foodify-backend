import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CategoriesService } from './categories.service';
import { CategoriesController } from './categories.controller';
import { MenuCategory } from './entities/menu-category.entity';
import { SaasModule } from '../saas/saas.module';
import { PlanGuard } from '../../shared/guards/plan.guard';

@Module({
  imports: [TypeOrmModule.forFeature([MenuCategory]), SaasModule],
  controllers: [CategoriesController],
  providers: [CategoriesService, PlanGuard],
  exports: [CategoriesService, TypeOrmModule],
})
export class CategoriesModule {}
