import { Controller, Get, Post, Put, Patch, Delete, Body, Param, ParseIntPipe, UseGuards } from '@nestjs/common';
import { CategoriesService } from './categories.service';
import { CreateCategoryDto, UpdateCategoryDto } from './dto/category.dto';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';
import { RolesGuard } from '../../shared/guards/roles.guard';
import { PlanGuard } from '../../shared/guards/plan.guard';
import { Roles, UserRole } from '../../shared/decorators/roles.decorator';
import { CurrentUser } from '../../shared/decorators/current-user.decorator';
import { User } from '../users/entities/user.entity';

@Controller('api/v1/menus/:menuId/categories')
@UseGuards(JwtAuthGuard, RolesGuard, PlanGuard)
@Roles(UserRole.RESTAURANT_ADMIN)
export class CategoriesController {
  constructor(private readonly categoriesService: CategoriesService) {}

  @Get()
  findAll(@Param('menuId', ParseIntPipe) menuId: number, @CurrentUser() user: User) {
    // El guard/rol ya restringe el acceso; el service actualmente filtra por menuId.
    return this.categoriesService.findByMenu(menuId);
  }

  @Post()
  create(@Param('menuId', ParseIntPipe) menuId: number, @Body() dto: CreateCategoryDto, @CurrentUser() user: User) {
    return this.categoriesService.create(menuId, dto);
  }

  @Put(':id')
  update(@Param('menuId', ParseIntPipe) menuId: number, @Param('id', ParseIntPipe) id: number, @Body() dto: UpdateCategoryDto) {
    return this.categoriesService.update(id, dto);
  }

  @Patch(':id/sort')
  sort(@Param('menuId', ParseIntPipe) menuId: number, @Param('id', ParseIntPipe) id: number, @Body('sortOrder') sortOrder: number) {
    return this.categoriesService.updateSort(id, sortOrder);
  }

  @Delete(':id')
  remove(@Param('menuId', ParseIntPipe) menuId: number, @Param('id', ParseIntPipe) id: number) {
    return this.categoriesService.remove(id);
  }
}
