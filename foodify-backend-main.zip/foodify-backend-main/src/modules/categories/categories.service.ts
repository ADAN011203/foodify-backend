import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { MenuCategory } from './entities/menu-category.entity';
import { CreateCategoryDto, UpdateCategoryDto } from './dto/category.dto';

@Injectable()
export class CategoriesService {
  constructor(
    @InjectRepository(MenuCategory) private catRepo: Repository<MenuCategory>,
  ) {}

  async create(menuId: number, dto: CreateCategoryDto): Promise<MenuCategory> {
    const cat = this.catRepo.create({ ...dto, menuId });
    return this.catRepo.save(cat);
  }

  async findByMenu(menuId: number): Promise<MenuCategory[]> {
    return this.catRepo.find({
      where: { menuId },
      order: { sortOrder: 'ASC' },
      relations: ['dishes'],
    });
  }

  async findOne(id: number): Promise<MenuCategory> {
    const cat = await this.catRepo.findOne({ where: { id }, relations: ['dishes'] });
    if (!cat) throw new NotFoundException(`Categoría #${id} no encontrada`);
    return cat;
  }

  async update(id: number, dto: UpdateCategoryDto): Promise<MenuCategory> {
    const cat = await this.findOne(id);
    Object.assign(cat, dto);
    return this.catRepo.save(cat);
  }

  async updateSort(id: number, sortOrder: number): Promise<MenuCategory> {
    const cat = await this.findOne(id);
    cat.sortOrder = sortOrder;
    return this.catRepo.save(cat);
  }

  async remove(id: number): Promise<void> {
    const cat = await this.findOne(id);
    await this.catRepo.remove(cat);
  }
}
