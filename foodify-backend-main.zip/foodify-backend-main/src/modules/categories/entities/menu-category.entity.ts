import {
  Entity, PrimaryGeneratedColumn, Column,
  ManyToOne, JoinColumn, OneToMany,
} from 'typeorm';
import { Menu } from '../../menus/entities/menu.entity';
import { Dish } from '../../dishes/entities/dish.entity';

@Entity('menu_categories')
export class MenuCategory {
  @PrimaryGeneratedColumn({ unsigned: true })
  id: number;

  @Column({ name: 'menu_id', unsigned: true })
  menuId: number;

  @Column({ length: 100 })
  name: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ length: 50, nullable: true })
  icon: string;

  @Column({ type: 'json', nullable: true })
  schedule: { days: number[]; start: string; end: string };

  @Column({ name: 'sort_order', type: 'smallint', default: 0 })
  sortOrder: number;

  @Column({ name: 'is_active', default: true })
  isActive: boolean;

  @ManyToOne(() => Menu, (menu) => menu.categories, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'menu_id' })
  menu: Menu;

  @OneToMany(() => Dish, (dish) => dish.category)
  dishes: Dish[];
}
