import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as nodemailer from 'nodemailer';
import { User } from '../users/entities/user.entity';
import { UserRole } from '../../shared/decorators/roles.decorator';
import * as admin from 'firebase-admin';

@Injectable()
export class NotificationsService implements OnModuleInit {
  private readonly logger = new Logger(NotificationsService.name);
  private firebaseApp: admin.app.App;

  constructor(
    @InjectRepository(User) private userRepo: Repository<User>,
  ) {}

  onModuleInit() {
    if (
      process.env.FIREBASE_PROJECT_ID &&
      process.env.FIREBASE_PRIVATE_KEY &&
      process.env.FIREBASE_CLIENT_EMAIL
    ) {
      try {
        this.firebaseApp = admin.initializeApp({
          credential: admin.credential.cert({
            projectId: process.env.FIREBASE_PROJECT_ID,
            privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
          }),
        });
        this.logger.log('Firebase Admin SDK initialized');
      } catch (err) {
        this.logger.warn(`Firebase init failed: ${err.message}`);
      }
    } else {
      this.logger.warn('Firebase not configured — push notifications disabled');
    }
  }

  // ── EVENT LISTENERS ───────────────────────────────
  @OnEvent('order.ready_for_waiter')
  async handleOrderReady(order: any) {
    const waiter = await this.userRepo.findOne({
      where: { id: order.waiterId },
    });
    if (waiter?.fcmToken) {
      await this.sendPush(
        waiter.fcmToken,
        '🟢 Pedido listo',
        `Mesa ${order.table?.number || 'para llevar'} — ${order.items?.length || 0} ítem(s) listos`,
        { orderId: String(order.id), type: 'order_ready' },
      );
    }
  }

  @OnEvent('inventory.alert')
  async handleInventoryAlert(payload: any) {
    // Notify all admins of the restaurant
    const admins = await this.userRepo.find({
      where: {
        restaurantId: payload.restaurantId,
        role: UserRole.RESTAURANT_ADMIN,
        isActive: true,
      },
    });

    for (const admin of admins) {
      if (admin.fcmToken) {
        await this.sendPush(
          admin.fcmToken,
          '⚠️ Alerta de inventario',
          payload.message,
          { type: 'inventory_alert', itemId: String(payload.itemId) },
        );
      }
    }
  }

  // ── SEND PUSH ─────────────────────────────────────
  async sendPush(
    token: string,
    title: string,
    body: string,
    data?: Record<string, string>,
  ): Promise<void> {
    if (!this.firebaseApp) {
      this.logger.log(`[DEV PUSH] ${title}: ${body}`);
      return;
    }
    try {
      await this.firebaseApp.messaging().send({
        token,
        notification: { title, body },
        data: data || {},
        android: {
          priority: 'high',
          notification: { sound: 'default', channelId: 'foodify_default' },
        },
      });
    } catch (err) {
      this.logger.error(`FCM push failed: ${err.message}`);
    }
  }

  // ── EMAIL (simple nodemailer) ─────────────────────
  async sendEmail(to: string, subject: string, html: string): Promise<void> {
    if (!process.env.SMTP_HOST) {
      this.logger.log(`[DEV EMAIL] To: ${to} | Subject: ${subject}`);
      return;
    }
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT || '587'),
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
    });
    await transporter.sendMail({
      from: process.env.SMTP_FROM,
      to, subject, html,
    });
  }

  async sendPaymentReminder(to: string, restaurantName: string, amount: number, dueDate: Date): Promise<void> {
    const html = `
      <h2>Recordatorio de pago - Foodify</h2>
      <p>Estimado cliente de <strong>${restaurantName}</strong>,</p>
      <p>Le recordamos que tiene un pago pendiente de <strong>$${amount} MXN</strong> 
         con vencimiento el <strong>${dueDate.toLocaleDateString('es-MX')}</strong>.</p>
      <p>Para continuar disfrutando de los servicios de Foodify, por favor realice su pago.</p>
      <br><p>Equipo CODEX - Foodify</p>
    `;
    await this.sendEmail(to, '⚠️ Recordatorio de pago - Foodify', html);
  }
}
