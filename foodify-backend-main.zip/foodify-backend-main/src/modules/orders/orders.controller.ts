import {
  Controller, Get, Post, Patch, Delete, Body,
  Param, ParseIntPipe, Query, UseGuards,
} from '@nestjs/common';
import { OrdersService } from './orders.service';
import {
  CreateOrderDto, AddOrderItemsDto, UpdateOrderItemDto, CancelOrderDto,
} from './dto/order.dto';
import { OrderStatus, KitchenStatus } from './entities/order.entity';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';
import { RolesGuard } from '../../shared/guards/roles.guard';
import { Roles, UserRole } from '../../shared/decorators/roles.decorator';
import { CurrentUser } from '../../shared/decorators/current-user.decorator';
import { User } from '../users/entities/user.entity';

@Controller('api/v1/orders')
@UseGuards(JwtAuthGuard, RolesGuard)
export class OrdersController {
  constructor(private readonly ordersService: OrdersService) {}

  @Post()
  @Roles(UserRole.WAITER, UserRole.RESTAURANT_ADMIN, UserRole.CASHIER)
  create(@CurrentUser() user: User, @Body() dto: CreateOrderDto) {
    return this.ordersService.create(user.restaurantId, user.id, dto);
  }

  @Get()
  @Roles(UserRole.RESTAURANT_ADMIN, UserRole.MANAGER, UserRole.WAITER, UserRole.CASHIER)
  findAll(
    @CurrentUser() user: User,
    @Query('page') page?: number,
    @Query('limit') limit?: number,
    @Query('status') status?: string,
    @Query('kitchenStatus') kitchenStatus?: string,
    @Query('tableId') tableId?: number,
    @Query('waiterId') waiterId?: number,
    @Query('dateFrom') dateFrom?: string,
    @Query('dateTo') dateTo?: string,
  ) {
    return this.ordersService.findAll(user.restaurantId, {
      page, limit, status, kitchenStatus, tableId, waiterId, dateFrom, dateTo,
    });
  }

  @Get('active')
  @Roles(UserRole.RESTAURANT_ADMIN, UserRole.MANAGER, UserRole.WAITER, UserRole.CASHIER, UserRole.CHEF)
  findActive(@CurrentUser() user: User) {
    return this.ordersService.findActive(user.restaurantId);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.ordersService.findOne(id);
  }

  @Patch(':id/status')
  @Roles(UserRole.WAITER, UserRole.RESTAURANT_ADMIN, UserRole.CASHIER)
  updateStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body('status') status: OrderStatus,
  ) {
    return this.ordersService.updateStatus(id, status);
  }

  @Patch(':id/kitchen-status')
  @Roles(UserRole.CHEF, UserRole.RESTAURANT_ADMIN)
  updateKitchenStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body('kitchenStatus') kitchenStatus: KitchenStatus,
  ) {
    return this.ordersService.updateKitchenStatus(id, kitchenStatus);
  }

  @Post(':id/items')
  @Roles(UserRole.WAITER, UserRole.RESTAURANT_ADMIN)
  addItems(@Param('id', ParseIntPipe) id: number, @Body() dto: AddOrderItemsDto) {
    return this.ordersService.addItems(id, dto);
  }

  @Patch(':id/items/:iid')
  @Roles(UserRole.WAITER, UserRole.RESTAURANT_ADMIN)
  updateItem(
    @Param('iid', ParseIntPipe) iid: number,
    @Body() dto: UpdateOrderItemDto,
  ) {
    return this.ordersService.updateItem(iid, dto);
  }

  @Delete(':id/items/:iid')
  @Roles(UserRole.WAITER, UserRole.RESTAURANT_ADMIN)
  removeItem(@Param('iid', ParseIntPipe) iid: number) {
    return this.ordersService.removeItem(iid);
  }

  @Patch(':id/cancel')
  @Roles(UserRole.WAITER, UserRole.RESTAURANT_ADMIN, UserRole.MANAGER)
  cancel(@Param('id', ParseIntPipe) id: number, @Body() dto: CancelOrderDto) {
    return this.ordersService.cancel(id, dto);
  }
}
