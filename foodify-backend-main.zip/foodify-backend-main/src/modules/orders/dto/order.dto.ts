import {
  IsEnum, IsOptional, IsNumber, IsString,
  IsArray, ValidateNested, IsInt, Min,
} from 'class-validator';
import { Type } from 'class-transformer';
import { OrderType, OrderStatus } from '../entities/order.entity';

export class CreateOrderItemDto {
  @IsInt()
  dishId: number;

  @IsInt()
  @Min(1)
  quantity: number;

  @IsOptional()
  @IsString()
  specialNotes?: string;
}

export class CreateOrderDto {
  @IsOptional()
  @IsInt()
  tableId?: number;

  @IsOptional()
  @IsEnum(OrderType)
  type?: OrderType;

  @IsOptional()
  @IsString()
  notes?: string;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateOrderItemDto)
  items: CreateOrderItemDto[];
}

export class AddOrderItemsDto {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateOrderItemDto)
  items: CreateOrderItemDto[];
}

export class UpdateOrderItemDto {
  @IsOptional()
  @IsInt()
  @Min(1)
  quantity?: number;

  @IsOptional()
  @IsString()
  specialNotes?: string;
}

export class CancelOrderDto {
  @IsString()
  reason: string;
}
