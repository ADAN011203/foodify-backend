// ─────────────────────────────────────────────────────────────────
// ARCHIVO: src/modules/orders/order-schedule-validation.ts
//
// Este archivo contiene la función de validación de horario
// que se llama dentro de orders.service.ts al crear un pedido.
// Importar en orders.service.ts e invocar en el método create().
// ─────────────────────────────────────────────────────────────────

import { BadRequestException } from '@nestjs/common';
import { Repository } from 'typeorm';
import { Dish } from '../dishes/entities/dish.entity';
import { isMenuActiveNow } from '../../shared/utils/schedule';

/**
 * Valida que cada platillo del pedido puede ordenarse en este momento.
 * Un platillo puede ordenarse si:
 *   1. Su menú está en horario activo ahora, O
 *   2. Su menú tiene allowOutsideSchedule = true (default)
 *
 * Si un platillo NO puede ordenarse, lanza BadRequestException
 * con el mensaje de horario correspondiente.
 */
export async function validateOrderSchedule(
  items: { dishId: number; quantity: number }[],
  dishRepo: Repository<Dish>,
  restaurantTimezone: string,
): Promise<void> {
  for (const item of items) {
    const dish = await dishRepo.findOne({
      where: { id: item.dishId, isAvailable: true, deletedAt: null },
      relations: ['category', 'category.menu'],
    });

    if (!dish) {
      throw new BadRequestException(
        `El platillo #${item.dishId} no está disponible`,
      );
    }

    const menu = dish.category?.menu;

    // Sin menú asignado → siempre se puede ordenar
    if (!menu) continue;

    const isActiveNow = isMenuActiveNow(menu.schedule, restaurantTimezone);
    const canOrder = isActiveNow || menu.allowOutsideSchedule;

    if (!canOrder) {
      throw new BadRequestException(
        `"${dish.name}" solo está disponible de ` +
        `${menu.schedule?.start || '?'} a ${menu.schedule?.end || '?'} ` +
        `(Menú: ${menu.name})`,
      );
    }
  }
}

// ─────────────────────────────────────────────────────────────────
// CÓMO INTEGRAR EN orders.service.ts:
//
// 1. Agregar import al inicio del archivo:
//    import { validateOrderSchedule } from './order-schedule-validation';
//
// 2. Dentro del método create(), ANTES del loop de creación de ítems,
//    agregar esta línea:
//
//    async create(restaurantId: number, waiterId: number, dto: CreateOrderDto) {
//      return this.dataSource.transaction(async (manager) => {
//        const orderNumber = ...;
//
//        // ── NUEVA VALIDACIÓN DE HORARIO ──────────────────────
//        const restaurant = await manager.findOne(Restaurant, { where: { id: restaurantId } });
//        await validateOrderSchedule(dto.items, this.dishRepo, restaurant?.timezone || 'America/Monterrey');
//        // ── FIN VALIDACIÓN ───────────────────────────────────
//
//        const order = manager.create(Order, { ... });
//        ...
//      });
//    }
// ─────────────────────────────────────────────────────────────────
