import {
  Injectable, NotFoundException, BadRequestException, ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { validateOrderSchedule } from './order-schedule-validation';
import { Order, OrderStatus, KitchenStatus } from './entities/order.entity';
import { OrderItem, OrderItemStatus } from './entities/order-item.entity';
import { Dish } from '../dishes/entities/dish.entity';
import {
  CreateOrderDto, AddOrderItemsDto, UpdateOrderItemDto, CancelOrderDto,
} from './dto/order.dto';
import { generateOrderNumber } from '../../shared/utils/order-number';
import { getPaginationParams, buildPaginationMeta } from '../../shared/utils/pagination';
import { EventEmitter2 } from '@nestjs/event-emitter';

@Injectable()
export class OrdersService {
  constructor(
    @InjectRepository(Order) private orderRepo: Repository<Order>,
    @InjectRepository(OrderItem) private itemRepo: Repository<OrderItem>,
    @InjectRepository(Dish) private dishRepo: Repository<Dish>,
    private dataSource: DataSource,
    private eventEmitter: EventEmitter2,
  ) {}

  async create(restaurantId: number, waiterId: number, dto: CreateOrderDto): Promise<Order> {
    return this.dataSource.transaction(async (manager) => {
      const orderNumber = await generateOrderNumber(this.orderRepo, restaurantId);

      // Validate that every dish can be ordered at this time (schedule check)
      const restaurant = await manager.query('SELECT timezone FROM restaurants WHERE id = ?', [restaurantId]);
      const timezone = restaurant[0]?.timezone || 'America/Monterrey';
      await validateOrderSchedule(dto.items, this.dishRepo, timezone);

      const order = manager.create(Order, {
        restaurantId,
        waiterId,
        tableId: dto.tableId,
        type: dto.type,
        notes: dto.notes,
        orderNumber,
      });
      const savedOrder = await manager.save(order);

      let subtotal = 0;
      const orderItems: OrderItem[] = [];

      for (const itemDto of dto.items) {
        const dish = await manager.findOne(Dish, { where: { id: itemDto.dishId, isAvailable: true } });
        if (!dish) throw new BadRequestException(`Platillo #${itemDto.dishId} no disponible`);

        const orderItem = manager.create(OrderItem, {
          orderId: savedOrder.id,
          dishId: itemDto.dishId,
          quantity: itemDto.quantity,
          unitPrice: dish.price,
          specialNotes: itemDto.specialNotes,
        });
        orderItems.push(orderItem);
        subtotal += dish.price * itemDto.quantity;
      }

      await manager.save(OrderItem, orderItems);

      const taxAmount = subtotal * 0.16;
      const total = subtotal + taxAmount;
      await manager.update(Order, savedOrder.id, { subtotal, taxAmount, total });

      const final = await manager.findOne(Order, {
        where: { id: savedOrder.id },
        relations: ['items', 'items.dish', 'table', 'waiter'],
      });

      // Emit WebSocket event to kitchen
      this.eventEmitter.emit('order.new', final);
      return final;
    });
  }

  async findAll(restaurantId: number, query: {
    page?: number; limit?: number; status?: string;
    kitchenStatus?: string; tableId?: number;
    waiterId?: number; dateFrom?: string; dateTo?: string;
  }) {
    const { skip, take, page, limit } = getPaginationParams(query);
    const qb = this.orderRepo
      .createQueryBuilder('o')
      .leftJoinAndSelect('o.items', 'items')
      .leftJoinAndSelect('items.dish', 'dish')
      .leftJoinAndSelect('o.table', 'table')
      .leftJoinAndSelect('o.waiter', 'waiter')
      .where('o.restaurant_id = :restaurantId', { restaurantId });

    if (query.status) qb.andWhere('o.status = :status', { status: query.status });
    if (query.kitchenStatus) qb.andWhere('o.kitchen_status = :ks', { ks: query.kitchenStatus });
    if (query.tableId) qb.andWhere('o.table_id = :tableId', { tableId: query.tableId });
    if (query.waiterId) qb.andWhere('o.waiter_id = :waiterId', { waiterId: query.waiterId });
    if (query.dateFrom) qb.andWhere('o.created_at >= :from', { from: new Date(query.dateFrom) });
    if (query.dateTo) qb.andWhere('o.created_at <= :to', { to: new Date(query.dateTo) });

    qb.orderBy('o.created_at', 'DESC').skip(skip).take(take);
    const [orders, total] = await qb.getManyAndCount();
    return { data: orders, meta: buildPaginationMeta(total, page, limit) };
  }

  async findActive(restaurantId: number): Promise<Order[]> {
    return this.orderRepo.find({
      where: [
        { restaurantId, status: OrderStatus.PENDING },
        { restaurantId, status: OrderStatus.CONFIRMED },
        { restaurantId, status: OrderStatus.PREPARING },
        { restaurantId, status: OrderStatus.READY },
      ],
      relations: ['items', 'items.dish', 'table', 'waiter'],
      order: { createdAt: 'ASC' },
    });
  }

  async findOne(id: number): Promise<Order> {
    const order = await this.orderRepo.findOne({
      where: { id },
      relations: ['items', 'items.dish', 'table', 'waiter'],
    });
    if (!order) throw new NotFoundException(`Pedido #${id} no encontrado`);
    return order;
  }

  async updateStatus(id: number, status: OrderStatus): Promise<Order> {
    const order = await this.findOne(id);
    const allowed = this.getAllowedNextStatuses(order.status);
    if (!allowed.includes(status))
      throw new BadRequestException(`Transición inválida: ${order.status} → ${status}`);

    order.status = status;
    if (status === OrderStatus.DELIVERED) {
      order.deliveredAt = new Date();
      order.kitchenStatus = KitchenStatus.DELIVERED;
      // Emit FIFO deduction event
      this.eventEmitter.emit('order.delivered', order);
    }

    const saved = await this.orderRepo.save(order);
    this.eventEmitter.emit('order.status_changed', saved);
    return saved;
  }

  async updateKitchenStatus(id: number, kitchenStatus: KitchenStatus): Promise<Order> {
    const order = await this.findOne(id);
    order.kitchenStatus = kitchenStatus;
    if (kitchenStatus === KitchenStatus.PREPARING) order.status = OrderStatus.PREPARING;
    if (kitchenStatus === KitchenStatus.READY) order.status = OrderStatus.READY;
    const saved = await this.orderRepo.save(order);
    this.eventEmitter.emit('order.kitchen_status_changed', saved);
    return saved;
  }

  async addItems(orderId: number, dto: AddOrderItemsDto): Promise<Order> {
    const order = await this.findOne(orderId);
    if ([OrderStatus.READY, OrderStatus.DELIVERED, OrderStatus.CANCELLED].includes(order.status))
      throw new BadRequestException('No se pueden agregar ítems a este pedido');

    let addedSubtotal = 0;
    for (const itemDto of dto.items) {
      const dish = await this.dishRepo.findOne({ where: { id: itemDto.dishId, isAvailable: true } });
      if (!dish) throw new BadRequestException(`Platillo #${itemDto.dishId} no disponible`);
      await this.itemRepo.save({
        orderId,
        dishId: itemDto.dishId,
        quantity: itemDto.quantity,
        unitPrice: dish.price,
        specialNotes: itemDto.specialNotes,
      });
      addedSubtotal += dish.price * itemDto.quantity;
    }

    order.subtotal = Number(order.subtotal) + addedSubtotal;
    order.taxAmount = order.subtotal * 0.16;
    order.total = order.subtotal + order.taxAmount;
    return this.orderRepo.save(order);
  }

  async updateItem(itemId: number, dto: UpdateOrderItemDto): Promise<OrderItem> {
    const item = await this.itemRepo.findOne({ where: { id: itemId } });
    if (!item) throw new NotFoundException(`Ítem #${itemId} no encontrado`);
    if (item.status !== OrderItemStatus.PENDING)
      throw new BadRequestException('Solo se pueden modificar ítems pendientes');
    Object.assign(item, dto);
    return this.itemRepo.save(item);
  }

  async removeItem(itemId: number): Promise<void> {
    const item = await this.itemRepo.findOne({ where: { id: itemId } });
    if (!item) throw new NotFoundException(`Ítem #${itemId} no encontrado`);
    await this.itemRepo.remove(item);
  }

  async cancel(id: number, dto: CancelOrderDto): Promise<Order> {
    const order = await this.findOne(id);
    if (order.status === OrderStatus.DELIVERED)
      throw new BadRequestException('No se puede cancelar un pedido ya entregado');
    order.status = OrderStatus.CANCELLED;
    order.cancelledAt = new Date();
    order.cancelReason = dto.reason;
    const saved = await this.orderRepo.save(order);
    this.eventEmitter.emit('order.cancelled', saved);
    return saved;
  }

  private getAllowedNextStatuses(current: OrderStatus): OrderStatus[] {
    const transitions: Record<OrderStatus, OrderStatus[]> = {
      [OrderStatus.PENDING]: [OrderStatus.CONFIRMED, OrderStatus.CANCELLED],
      [OrderStatus.CONFIRMED]: [OrderStatus.PREPARING, OrderStatus.CANCELLED],
      [OrderStatus.PREPARING]: [OrderStatus.READY, OrderStatus.CANCELLED],
      [OrderStatus.READY]: [OrderStatus.DELIVERED],
      [OrderStatus.DELIVERED]: [],
      [OrderStatus.CANCELLED]: [],
    };
    return transitions[current] || [];
  }
}
