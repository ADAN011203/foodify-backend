import {
  WebSocketGateway, WebSocketServer, SubscribeMessage,
  OnGatewayConnection, OnGatewayDisconnect, ConnectedSocket,
  MessageBody,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { OnEvent } from '@nestjs/event-emitter';
import { JwtService } from '@nestjs/jwt';
import { Logger } from '@nestjs/common';
import { Order } from './entities/order.entity';

@WebSocketGateway({
  namespace: '/restaurant',
  cors: { origin: '*', credentials: true },
})
export class OrdersGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  private logger = new Logger('RestaurantGateway');

  constructor(private jwtService: JwtService) {}

  async handleConnection(client: Socket) {
    try {
      const token =
        client.handshake.auth?.token ||
        client.handshake.headers?.authorization?.replace('Bearer ', '');
      if (!token) { client.disconnect(); return; }

      const payload = this.jwtService.verify(token, {
        secret: process.env.JWT_ACCESS_SECRET,
      });
      client.data.user = payload;
      const roomId = `restaurant_${payload.restaurantId}`;
      client.join(roomId);
      this.logger.log(`Client connected to /restaurant: ${client.id} room: ${roomId}`);
    } catch {
      client.disconnect();
    }
  }

  handleDisconnect(client: Socket) {
    this.logger.log(`Client disconnected from /restaurant: ${client.id}`);
  }

  // ── Event listeners (from EventEmitter) ──────────
  @OnEvent('order.status_changed')
  handleOrderStatusChanged(order: Order) {
    const room = `restaurant_${order.restaurantId}`;
    this.server.to(room).emit('order:status', {
      orderId: order.id,
      newStatus: order.status,
      kitchenStatus: order.kitchenStatus,
    });
  }

  @OnEvent('order.kitchen_status_changed')
  handleKitchenStatusChanged(order: Order) {
    const room = `restaurant_${order.restaurantId}`;
    this.server.to(room).emit('order:status_changed', {
      orderId: order.id,
      tableNumber: (order.table as any)?.number,
      kitchenStatus: order.kitchenStatus,
    });

    if (order.kitchenStatus === 'ready') {
      this.server.to(room).emit('order:ready', {
        orderId: order.id,
        tableNumber: (order.table as any)?.number,
        itemsCount: order.items?.length || 0,
      });
    }
  }

  @OnEvent('order.delivered')
  handleOrderDelivered(order: Order) {
    const room = `restaurant_${order.restaurantId}`;
    this.server.to(room).emit('order:delivered', {
      orderId: order.id,
      deliveredAt: order.deliveredAt,
      total: order.total,
    });
  }

  @OnEvent('order.cancelled')
  handleOrderCancelled(order: Order) {
    const room = `restaurant_${order.restaurantId}`;
    this.server.to(room).emit('order:status', {
      orderId: order.id,
      newStatus: 'cancelled',
    });
  }

  @OnEvent('inventory.alert')
  handleInventoryAlert(payload: any) {
    const room = `restaurant_${payload.restaurantId}`;
    this.server.to(room).emit('inventory:alert', payload);
  }

  @OnEvent('dish.unavailable')
  handleDishUnavailable(payload: any) {
    const room = `restaurant_${payload.restaurantId}`;
    this.server.to(room).emit('dish:unavailable', payload);
  }
}
