import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  ManyToOne, JoinColumn, OneToMany,
} from 'typeorm';
import { Restaurant } from '../../restaurants/entities/restaurant.entity';
import { Table } from '../../tables/entities/table.entity';
import { User } from '../../users/entities/user.entity';
import { OrderItem } from './order-item.entity';

export enum OrderType { DINE_IN = 'dine_in', TAKEOUT = 'takeout', DELIVERY = 'delivery' }
export enum OrderStatus { PENDING = 'pending', CONFIRMED = 'confirmed', PREPARING = 'preparing', READY = 'ready', DELIVERED = 'delivered', CANCELLED = 'cancelled' }
export enum KitchenStatus { PENDING = 'pending', PREPARING = 'preparing', READY = 'ready', DELIVERED = 'delivered' }

@Entity('orders')
export class Order {
  @PrimaryGeneratedColumn({ unsigned: true })
  id: number;

  @Column({ name: 'restaurant_id', unsigned: true })
  restaurantId: number;

  @Column({ name: 'table_id', unsigned: true, nullable: true })
  tableId: number;

  @Column({ name: 'waiter_id', unsigned: true })
  waiterId: number;

  @Column({ name: 'order_number', length: 4 })
  orderNumber: string;

  @Column({ type: 'enum', enum: OrderType, default: OrderType.DINE_IN })
  type: OrderType;

  @Column({ type: 'enum', enum: OrderStatus, default: OrderStatus.PENDING })
  status: OrderStatus;

  @Column({ name: 'kitchen_status', type: 'enum', enum: KitchenStatus, default: KitchenStatus.PENDING })
  kitchenStatus: KitchenStatus;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  subtotal: number;

  @Column({ name: 'tax_amount', type: 'decimal', precision: 10, scale: 2, default: 0 })
  taxAmount: number;

  @Column({ name: 'tip_amount', type: 'decimal', precision: 10, scale: 2, default: 0 })
  tipAmount: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  total: number;

  @Column({ type: 'text', nullable: true })
  notes: string;

  @Column({ name: 'delivered_at', nullable: true })
  deliveredAt: Date;

  @Column({ name: 'cancelled_at', nullable: true })
  cancelledAt: Date;

  @Column({ name: 'cancel_reason', length: 255, nullable: true })
  cancelReason: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => Restaurant, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'restaurant_id' })
  restaurant: Restaurant;

  @ManyToOne(() => Table, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'table_id' })
  table: Table;

  @ManyToOne(() => User, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'waiter_id' })
  waiter: User;

  @OneToMany(() => OrderItem, (item) => item.order, { cascade: true })
  items: OrderItem[];
}
