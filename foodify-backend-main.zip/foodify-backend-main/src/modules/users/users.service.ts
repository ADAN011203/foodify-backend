import {
  Injectable, NotFoundException, ConflictException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { User } from './entities/user.entity';
import { CreateUserDto, UpdateUserDto } from './dto/user.dto';
import { getPaginationParams, buildPaginationMeta } from '../../shared/utils/pagination';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User) private userRepo: Repository<User>,
  ) {}

  async create(dto: CreateUserDto): Promise<Partial<User>> {
    const exists = await this.userRepo.findOne({ where: { email: dto.email } });
    if (exists) throw new ConflictException('El email ya está registrado');

    const passwordHash = await bcrypt.hash(dto.password, 12);
    const user = this.userRepo.create({
      fullName: dto.fullName,
      email: dto.email,
      phone: dto.phone,
      passwordHash,
      role: dto.role,
      restaurantId: dto.restaurantId,
    });
    const saved = await this.userRepo.save(user);
    return this.sanitize(saved);
  }

  async findAll(restaurantId: number, query: { page?: number; limit?: number; role?: string }) {
    const { skip, take, page, limit } = getPaginationParams(query);
    const qb = this.userRepo
      .createQueryBuilder('u')
      .where('u.restaurant_id = :restaurantId', { restaurantId });

    if (query.role) qb.andWhere('u.role = :role', { role: query.role });

    qb.orderBy('u.created_at', 'DESC').skip(skip).take(take);
    const [users, total] = await qb.getManyAndCount();
    return {
      data: users.map(this.sanitize),
      meta: buildPaginationMeta(total, page, limit),
    };
  }

  async findOne(id: number): Promise<Partial<User>> {
    const user = await this.userRepo.findOne({ where: { id }, relations: ['restaurant'] });
    if (!user) throw new NotFoundException(`Usuario #${id} no encontrado`);
    return this.sanitize(user);
  }

  async update(id: number, dto: UpdateUserDto): Promise<Partial<User>> {
    const user = await this.userRepo.findOne({ where: { id } });
    if (!user) throw new NotFoundException(`Usuario #${id} no encontrado`);
    Object.assign(user, dto);
    const saved = await this.userRepo.save(user);
    return this.sanitize(saved);
  }

  async remove(id: number): Promise<void> {
    const user = await this.userRepo.findOne({ where: { id } });
    if (!user) throw new NotFoundException(`Usuario #${id} no encontrado`);
    await this.userRepo.update(id, { isActive: false });
  }

  private sanitize(user: User): Partial<User> {
    const { passwordHash, fcmToken, ...safe } = user as any;
    return safe;
  }
}
