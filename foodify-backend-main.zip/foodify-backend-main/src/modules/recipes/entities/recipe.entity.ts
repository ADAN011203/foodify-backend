import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  UpdateDateColumn, OneToOne, JoinColumn, OneToMany,
} from 'typeorm';
import { Dish } from '../../dishes/entities/dish.entity';
import { RecipeIngredient } from './recipe-ingredient.entity';

@Entity('recipes')
export class Recipe {
  @PrimaryGeneratedColumn({ unsigned: true })
  id: number;

  @Column({ name: 'dish_id', unsigned: true, unique: true })
  dishId: number;

  @Column({ name: 'prep_time_min', type: 'tinyint', default: 15 })
  prepTimeMin: number;

  @Column({ type: 'tinyint', default: 1 })
  servings: number;

  @Column({ type: 'json', nullable: true })
  steps: { order: number; description: string }[];

  @Column({ type: 'text', nullable: true })
  notes: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  @OneToOne(() => Dish, (dish) => dish.recipe, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'dish_id' })
  dish: Dish;

  @OneToMany(() => RecipeIngredient, (ri) => ri.recipe, { cascade: true })
  ingredients: RecipeIngredient[];
}
