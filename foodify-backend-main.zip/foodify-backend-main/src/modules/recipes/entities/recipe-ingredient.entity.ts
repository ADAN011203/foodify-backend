import {
  Entity, PrimaryGeneratedColumn, Column,
  ManyToOne, JoinColumn,
} from 'typeorm';
import { Recipe } from './recipe.entity';
import { InventoryItem } from '../../inventory/entities/inventory-item.entity';

@Entity('recipe_ingredients')
export class RecipeIngredient {
  @PrimaryGeneratedColumn({ unsigned: true })
  id: number;

  @Column({ name: 'recipe_id', unsigned: true })
  recipeId: number;

  @Column({ name: 'item_id', unsigned: true, nullable: true })
  itemId: number;

  @Column({ length: 100 })
  name: string;

  @Column({ type: 'decimal', precision: 10, scale: 4 })
  quantity: number;

  @Column({ length: 20 })
  unit: string;

  @Column({ name: 'is_optional', default: false })
  isOptional: boolean;

  @ManyToOne(() => Recipe, (r) => r.ingredients, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'recipe_id' })
  recipe: Recipe;

  @ManyToOne(() => InventoryItem, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'item_id' })
  inventoryItem: InventoryItem;
}
