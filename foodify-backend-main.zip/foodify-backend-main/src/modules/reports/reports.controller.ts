import {
  Controller, Get, Query, Res, UseGuards, ParseIntPipe,
} from '@nestjs/common';
import { Response } from 'express';
import { ReportsService } from './reports.service';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';
import { RolesGuard } from '../../shared/guards/roles.guard';
import { Roles, UserRole } from '../../shared/decorators/roles.decorator';
import { CurrentUser } from '../../shared/decorators/current-user.decorator';
import { User } from '../users/entities/user.entity';
import { Period } from '../../shared/utils/date-range';

@Controller('api/v1/reports')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(UserRole.RESTAURANT_ADMIN, UserRole.MANAGER)
export class ReportsController {
  constructor(private readonly reportsService: ReportsService) {}

  @Get('sales')
  getSales(
    @CurrentUser() user: User,
    @Query('period') period: Period = 'month',
    @Query('start') start?: string,
    @Query('end') end?: string,
  ) {
    return this.reportsService.getSales(user.restaurantId, period, start, end);
  }

  @Get('dishes/top')
  getTopDishes(
    @CurrentUser() user: User,
    @Query('period') period: Period = 'month',
    @Query('limit') limit = 10,
    @Query('start') start?: string,
    @Query('end') end?: string,
  ) {
    return this.reportsService.getTopDishes(user.restaurantId, period, Number(limit), start, end);
  }

  @Get('dishes/sold')
  getDishesSold(
    @CurrentUser() user: User,
    @Query('period') period: Period = 'month',
    @Query('menuId') menuId?: number,
    @Query('start') start?: string,
    @Query('end') end?: string,
  ) {
    return this.reportsService.getDishesSold(user.restaurantId, period, menuId, start, end);
  }

  @Get('peak-hours')
  getPeakHours(
    @CurrentUser() user: User,
    @Query('period') period: Period = 'week',
    @Query('start') start?: string,
    @Query('end') end?: string,
  ) {
    return this.reportsService.getPeakHours(user.restaurantId, period, start, end);
  }

  @Get('category-income')
  getCategoryIncome(
    @CurrentUser() user: User,
    @Query('period') period: Period = 'month',
    @Query('start') start?: string,
    @Query('end') end?: string,
  ) {
    return this.reportsService.getCategoryIncome(user.restaurantId, period, start, end);
  }

  @Get('inventory/cost')
  getInventoryCost(
    @CurrentUser() user: User,
    @Query('period') period: Period = 'month',
    @Query('start') start?: string,
    @Query('end') end?: string,
  ) {
    return this.reportsService.getInventoryCost(user.restaurantId, period, start, end);
  }

  @Get('inventory/waste')
  getInventoryWaste(
    @CurrentUser() user: User,
    @Query('period') period: Period = 'month',
    @Query('start') start?: string,
    @Query('end') end?: string,
  ) {
    return this.reportsService.getInventoryWaste(user.restaurantId, period, start, end);
  }

  @Get('staff')
  getStaffPerformance(
    @CurrentUser() user: User,
    @Query('period') period: Period = 'month',
    @Query('userId') userId?: number,
    @Query('start') start?: string,
    @Query('end') end?: string,
  ) {
    return this.reportsService.getStaffPerformance(user.restaurantId, period, userId, start, end);
  }

  @Get('kitchen/performance')
  getKitchenPerformance(
    @CurrentUser() user: User,
    @Query('period') period: Period = 'week',
    @Query('start') start?: string,
    @Query('end') end?: string,
  ) {
    return this.reportsService.getKitchenPerformance(user.restaurantId, period, start, end);
  }

  @Get('export')
  async exportReport(
    @CurrentUser() user: User,
    @Query('type') type: 'sales' | 'dishes' | 'inventory' = 'sales',
    @Query('period') period: Period = 'month',
    @Query('format') format: 'csv' | 'xlsx' = 'xlsx',
    @Query('start') start: string | undefined,
    @Query('end') end: string | undefined,
    @Res() res: Response,
  ) {
    const { buffer, filename, mimeType } = await this.reportsService.exportReport(
      user.restaurantId, type, period, format, start, end,
    );
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', mimeType);
    res.send(buffer);
  }
}
