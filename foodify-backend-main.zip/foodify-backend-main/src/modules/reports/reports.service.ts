import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Order, OrderStatus } from '../orders/entities/order.entity';
import { OrderItem } from '../orders/entities/order-item.entity';
import { InventoryMovement, MovementType } from '../inventory/entities/inventory-movement.entity';
import { User } from '../users/entities/user.entity';
import { getDateRange, Period } from '../../shared/utils/date-range';
import * as XLSX from 'xlsx';

@Injectable()
export class ReportsService {
  constructor(
    @InjectRepository(Order) private orderRepo: Repository<Order>,
    @InjectRepository(OrderItem) private itemRepo: Repository<OrderItem>,
    @InjectRepository(InventoryMovement) private movRepo: Repository<InventoryMovement>,
    @InjectRepository(User) private userRepo: Repository<User>,
  ) {}

  // ── VENTAS ────────────────────────────────────────
  async getSales(restaurantId: number, period: Period, start?: string, end?: string) {
    const range = getDateRange(period, start, end);

    const result = await this.orderRepo
      .createQueryBuilder('o')
      .select([
        'SUM(o.total) AS totalRevenue',
        'SUM(o.subtotal) AS subtotal',
        'SUM(o.tax_amount) AS taxes',
        'SUM(o.tip_amount) AS tips',
        'COUNT(o.id) AS totalOrders',
        'AVG(o.total) AS avgTicket',
      ])
      .where('o.restaurant_id = :restaurantId AND o.status = :status AND o.delivered_at BETWEEN :from AND :to', {
        restaurantId, status: OrderStatus.DELIVERED, ...range,
      })
      .getRawOne();

    // Sales grouped by day for chart
    const byDay = await this.orderRepo
      .createQueryBuilder('o')
      .select(['DATE(o.delivered_at) AS day', 'SUM(o.total) AS revenue', 'COUNT(o.id) AS orders'])
      .where('o.restaurant_id = :restaurantId AND o.status = :status AND o.delivered_at BETWEEN :from AND :to', {
        restaurantId, status: OrderStatus.DELIVERED, ...range,
      })
      .groupBy('DATE(o.delivered_at)')
      .orderBy('day', 'ASC')
      .getRawMany();

    return { summary: result, byDay, period, from: range.from, to: range.to };
  }

  // ── TOP PLATILLOS ─────────────────────────────────
  async getTopDishes(restaurantId: number, period: Period, limit = 10, start?: string, end?: string) {
    const range = getDateRange(period, start, end);

    return this.itemRepo
      .createQueryBuilder('oi')
      .innerJoin('oi.dish', 'd')
      .innerJoin('oi.order', 'o')
      .select([
        'd.id AS dishId',
        'd.name AS dishName',
        'SUM(oi.quantity) AS totalSold',
        'SUM(oi.quantity * oi.unit_price) AS revenue',
      ])
      .where('o.restaurant_id = :restaurantId AND o.status = :status AND o.delivered_at BETWEEN :from AND :to', {
        restaurantId, status: OrderStatus.DELIVERED, ...range,
      })
      .groupBy('d.id')
      .orderBy('totalSold', 'DESC')
      .limit(limit)
      .getRawMany();
  }

  // ── PLATILLOS POR MENÚ ────────────────────────────
  async getDishesSold(restaurantId: number, period: Period, menuId?: number, start?: string, end?: string) {
    const range = getDateRange(period, start, end);

    const qb = this.itemRepo
      .createQueryBuilder('oi')
      .innerJoin('oi.dish', 'd')
      .innerJoin('d.category', 'cat')
      .innerJoin('cat.menu', 'menu')
      .innerJoin('oi.order', 'o')
      .select([
        'menu.id AS menuId',
        'menu.name AS menuName',
        'cat.name AS categoryName',
        'd.id AS dishId',
        'd.name AS dishName',
        'SUM(oi.quantity) AS totalSold',
        'SUM(oi.quantity * oi.unit_price) AS revenue',
      ])
      .where('o.restaurant_id = :restaurantId AND o.status = :status AND o.delivered_at BETWEEN :from AND :to', {
        restaurantId, status: OrderStatus.DELIVERED, ...range,
      })
      .groupBy('menu.id, cat.id, d.id')
      .orderBy('totalSold', 'DESC');

    if (menuId) qb.andWhere('menu.id = :menuId', { menuId });

    const rows = await qb.getRawMany();
    const totalSold = rows.reduce((s, r) => s + Number(r.totalSold), 0);
    return rows.map((r) => ({
      ...r,
      pctOfTotal: totalSold > 0 ? ((Number(r.totalSold) / totalSold) * 100).toFixed(1) : '0',
    }));
  }

  // ── HORAS PICO ────────────────────────────────────
  async getPeakHours(restaurantId: number, period: Period, start?: string, end?: string) {
    const range = getDateRange(period, start, end);

    return this.orderRepo
      .createQueryBuilder('o')
      .select(['HOUR(o.created_at) AS hour', 'COUNT(o.id) AS totalOrders'])
      .where('o.restaurant_id = :restaurantId AND o.created_at BETWEEN :from AND :to', {
        restaurantId, ...range,
      })
      .groupBy('HOUR(o.created_at)')
      .orderBy('hour', 'ASC')
      .getRawMany();
  }

  // ── INGRESOS POR CATEGORÍA ────────────────────────
  async getCategoryIncome(restaurantId: number, period: Period, start?: string, end?: string) {
    const range = getDateRange(period, start, end);

    return this.itemRepo
      .createQueryBuilder('oi')
      .innerJoin('oi.dish', 'd')
      .innerJoin('d.category', 'cat')
      .innerJoin('oi.order', 'o')
      .select([
        'cat.id AS categoryId',
        'cat.name AS categoryName',
        'SUM(oi.quantity * oi.unit_price) AS revenue',
        'SUM(oi.quantity) AS totalSold',
      ])
      .where('o.restaurant_id = :restaurantId AND o.status = :status AND o.delivered_at BETWEEN :from AND :to', {
        restaurantId, status: OrderStatus.DELIVERED, ...range,
      })
      .groupBy('cat.id')
      .orderBy('revenue', 'DESC')
      .getRawMany();
  }

  // ── INVENTARIO ────────────────────────────────────
  async getInventoryCost(restaurantId: number, period: Period, start?: string, end?: string) {
    const range = getDateRange(period, start, end);

    return this.movRepo
      .createQueryBuilder('m')
      .innerJoin('m.lot', 'lot')
      .innerJoin('lot.item', 'item')
      .select([
        'item.id AS itemId',
        'item.name AS itemName',
        'item.unit AS unit',
        'SUM(m.quantity * lot.unit_cost) AS totalCost',
        'SUM(m.quantity) AS totalQty',
      ])
      .where("item.restaurant_id = :restaurantId AND m.type = 'sale' AND m.created_at BETWEEN :from AND :to", {
        restaurantId, ...range,
      })
      .groupBy('item.id')
      .orderBy('totalCost', 'DESC')
      .getRawMany();
  }

  async getInventoryWaste(restaurantId: number, period: Period, start?: string, end?: string) {
    const range = getDateRange(period, start, end);

    return this.movRepo
      .createQueryBuilder('m')
      .innerJoin('m.lot', 'lot')
      .innerJoin('lot.item', 'item')
      .select([
        'item.name AS itemName',
        'm.type AS type',
        'SUM(m.quantity) AS totalQty',
        'SUM(m.quantity * lot.unit_cost) AS totalCost',
      ])
      .where("item.restaurant_id = :restaurantId AND m.type IN ('waste','adjustment') AND m.created_at BETWEEN :from AND :to", {
        restaurantId, ...range,
      })
      .groupBy('item.id, m.type')
      .orderBy('totalCost', 'DESC')
      .getRawMany();
  }

  // ── STAFF ─────────────────────────────────────────
  async getStaffPerformance(restaurantId: number, period: Period, userId?: number, start?: string, end?: string) {
    const range = getDateRange(period, start, end);

    const qb = this.orderRepo
      .createQueryBuilder('o')
      .innerJoin('o.waiter', 'w')
      .select([
        'w.id AS userId',
        'w.full_name AS waiterName',
        'COUNT(o.id) AS totalOrders',
        'SUM(o.total) AS totalRevenue',
        'AVG(o.total) AS avgTicket',
        'SUM(o.tip_amount) AS totalTips',
      ])
      .where('o.restaurant_id = :restaurantId AND o.status = :status AND o.delivered_at BETWEEN :from AND :to', {
        restaurantId, status: OrderStatus.DELIVERED, ...range,
      })
      .groupBy('w.id')
      .orderBy('totalOrders', 'DESC');

    if (userId) qb.andWhere('w.id = :userId', { userId });
    return qb.getRawMany();
  }

  // ── KITCHEN PERFORMANCE ───────────────────────────
  async getKitchenPerformance(restaurantId: number, period: Period, start?: string, end?: string) {
    const range = getDateRange(period, start, end);

    return this.itemRepo
      .createQueryBuilder('oi')
      .innerJoin('oi.dish', 'd')
      .innerJoin('oi.order', 'o')
      .select([
        'd.id AS dishId',
        'd.name AS dishName',
        'AVG(TIMESTAMPDIFF(MINUTE, oi.started_at, oi.ready_at)) AS avgPrepMinutes',
        'COUNT(oi.id) AS totalPrepared',
      ])
      .where('o.restaurant_id = :restaurantId AND oi.started_at IS NOT NULL AND oi.ready_at IS NOT NULL AND oi.created_at BETWEEN :from AND :to', {
        restaurantId, ...range,
      })
      .groupBy('d.id')
      .orderBy('avgPrepMinutes', 'DESC')
      .getRawMany();
  }

  // ── EXPORT ────────────────────────────────────────
  async exportReport(
    restaurantId: number,
    type: 'sales' | 'dishes' | 'inventory',
    period: Period,
    format: 'csv' | 'xlsx',
    start?: string,
    end?: string,
  ): Promise<{ buffer: Buffer; filename: string; mimeType: string }> {
    let data: any[] = [];
    let sheetName = 'Reporte';

    if (type === 'sales') {
      const result = await this.getSales(restaurantId, period, start, end);
      data = result.byDay;
      sheetName = 'Ventas';
    } else if (type === 'dishes') {
      data = await this.getTopDishes(restaurantId, period, 100, start, end);
      sheetName = 'Platillos';
    } else if (type === 'inventory') {
      data = await this.getInventoryCost(restaurantId, period, start, end);
      sheetName = 'Inventario';
    }

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(data);
    XLSX.utils.book_append_sheet(wb, ws, sheetName);

    const buffer = XLSX.write(wb, { type: 'buffer', bookType: format === 'csv' ? 'csv' : 'xlsx' });
    const ext = format === 'csv' ? 'csv' : 'xlsx';
    const mimeType = format === 'csv'
      ? 'text/csv'
      : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

    return {
      buffer,
      filename: `foodify_${type}_${new Date().toISOString().split('T')[0]}.${ext}`,
      mimeType,
    };
  }
}
