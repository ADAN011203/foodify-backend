import { IsEnum, IsNumber, IsOptional, Min, Max } from 'class-validator';
import { TableStatus } from '../entities/table.entity';

export class CreateTableDto {
  @IsNumber()
  @Min(1)
  number: number;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(50)
  capacity?: number;
}

export class UpdateTableDto {
  @IsOptional()
  @IsNumber()
  capacity?: number;

  @IsOptional()
  @IsEnum(TableStatus)
  status?: TableStatus;
}
