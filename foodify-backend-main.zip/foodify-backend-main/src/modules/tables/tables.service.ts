import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as QRCode from 'qrcode';
import { Table } from './entities/table.entity';
import { CreateTableDto, UpdateTableDto } from './dto/table.dto';

@Injectable()
export class TablesService {
  constructor(
    @InjectRepository(Table) private tableRepo: Repository<Table>,
  ) {}

  async create(restaurantId: number, dto: CreateTableDto): Promise<Table> {
    const exists = await this.tableRepo.findOne({
      where: { restaurantId, number: dto.number },
    });
    if (exists) throw new ConflictException(`La mesa #${dto.number} ya existe`);

    const table = this.tableRepo.create({ ...dto, restaurantId });
    const saved = await this.tableRepo.save(table);

    // Generate QR URL (points to public menu PWA)
    const menuUrl = `${process.env.CORS_ORIGINS?.split(',')[0] || 'http://localhost:3001'}/menu?table=${saved.id}`;
    const qrDataUrl = await QRCode.toDataURL(menuUrl);
    await this.tableRepo.update(saved.id, { qrCodeUrl: qrDataUrl });
    saved.qrCodeUrl = qrDataUrl;

    return saved;
  }

  async findAll(restaurantId: number): Promise<Table[]> {
    return this.tableRepo.find({
      where: { restaurantId },
      order: { number: 'ASC' },
    });
  }

  async findOne(id: number): Promise<Table> {
    const t = await this.tableRepo.findOne({ where: { id } });
    if (!t) throw new NotFoundException(`Mesa #${id} no encontrada`);
    return t;
  }

  async update(id: number, dto: UpdateTableDto): Promise<Table> {
    const t = await this.findOne(id);
    Object.assign(t, dto);
    return this.tableRepo.save(t);
  }

  async remove(id: number): Promise<void> {
    const t = await this.findOne(id);
    await this.tableRepo.remove(t);
  }
}
