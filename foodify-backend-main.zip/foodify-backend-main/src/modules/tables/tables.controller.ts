import {
  Controller, Get, Post, Put, Patch, Delete,
  Body, Param, ParseIntPipe, UseGuards,
} from '@nestjs/common';
import { TablesService } from './tables.service';
import { CreateTableDto, UpdateTableDto } from './dto/table.dto';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';
import { RolesGuard } from '../../shared/guards/roles.guard';
import { Roles, UserRole } from '../../shared/decorators/roles.decorator';
import { CurrentUser } from '../../shared/decorators/current-user.decorator';
import { User } from '../users/entities/user.entity';

@Controller('api/v1/tables')
@UseGuards(JwtAuthGuard, RolesGuard)
export class TablesController {
  constructor(private readonly tablesService: TablesService) {}

  @Post()
  @Roles(UserRole.RESTAURANT_ADMIN)
  create(@CurrentUser() user: User, @Body() dto: CreateTableDto) {
    return this.tablesService.create(user.restaurantId, dto);
  }

  @Get()
  @Roles(UserRole.RESTAURANT_ADMIN, UserRole.MANAGER, UserRole.WAITER, UserRole.CASHIER)
  findAll(@CurrentUser() user: User) {
    return this.tablesService.findAll(user.restaurantId);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.tablesService.findOne(id);
  }

  @Put(':id')
  @Roles(UserRole.RESTAURANT_ADMIN)
  update(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateTableDto) {
    return this.tablesService.update(id, dto);
  }

  @Patch(':id/status')
  @Roles(UserRole.RESTAURANT_ADMIN, UserRole.WAITER)
  updateStatus(@Param('id', ParseIntPipe) id: number, @Body('status') status: any) {
    return this.tablesService.update(id, { status });
  }

  @Delete(':id')
  @Roles(UserRole.RESTAURANT_ADMIN)
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.tablesService.remove(id);
  }
}
