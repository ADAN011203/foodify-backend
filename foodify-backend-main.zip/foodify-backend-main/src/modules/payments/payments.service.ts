import { Injectable, Logger, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { SaasSubscription, SubscriptionStatus } from '../saas/entities/saas-subscription.entity';
import { PaymentTransaction, TransactionStatus } from './entities/payment-transaction.entity';
import * as crypto from 'crypto';

@Injectable()
export class PaymentsService {
  private readonly logger = new Logger(PaymentsService.name);

  constructor(
    @InjectRepository(SaasSubscription) private subRepo: Repository<SaasSubscription>,
    @InjectRepository(PaymentTransaction) private txRepo: Repository<PaymentTransaction>,
  ) {}

  // ── STRIPE WEBHOOK ────────────────────────────────
  async handleStripeWebhook(rawBody: Buffer, signature: string): Promise<void> {
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

    // Verify signature
    const hmac = crypto
      .createHmac('sha256', webhookSecret)
      .update(rawBody)
      .digest('hex');

    // In production, use stripe.webhooks.constructEvent()
    // Here we parse directly for simplicity
    let event: any;
    try {
      event = JSON.parse(rawBody.toString());
    } catch {
      throw new BadRequestException('Webhook payload inválido');
    }

    this.logger.log(`Stripe webhook received: ${event.type}`);

    switch (event.type) {
      case 'invoice.payment_succeeded':
        await this.handlePaymentSucceeded(event.data.object, 'stripe');
        break;
      case 'invoice.payment_failed':
        await this.handlePaymentFailed(event.data.object, 'stripe');
        break;
      case 'customer.subscription.deleted':
        await this.handleSubscriptionCancelled(event.data.object);
        break;
      case 'customer.subscription.updated':
        await this.handleSubscriptionUpdated(event.data.object);
        break;
      default:
        this.logger.log(`Unhandled Stripe event: ${event.type}`);
    }
  }

  // ── CONEKTA WEBHOOK ───────────────────────────────
  async handleConektaWebhook(body: any): Promise<void> {
    this.logger.log(`Conekta webhook received: ${body.type}`);

    switch (body.type) {
      case 'charge.paid':
        await this.handlePaymentSucceeded(body.data.object, 'conekta');
        break;
      case 'charge.payment_failed':
        await this.handlePaymentFailed(body.data.object, 'conekta');
        break;
      default:
        this.logger.log(`Unhandled Conekta event: ${body.type}`);
    }
  }

  // ── TRANSACTION HISTORY ───────────────────────────
  async getTransactions(query: { subscriptionId?: number; page?: number; limit?: number }) {
    const take = query.limit || 20;
    const skip = ((query.page || 1) - 1) * take;

    const qb = this.txRepo
      .createQueryBuilder('t')
      .leftJoinAndSelect('t.subscription', 'sub')
      .leftJoinAndSelect('sub.restaurant', 'r')
      .orderBy('t.created_at', 'DESC')
      .skip(skip)
      .take(take);

    if (query.subscriptionId)
      qb.where('t.subscription_id = :subId', { subId: query.subscriptionId });

    const [transactions, total] = await qb.getManyAndCount();
    return { data: transactions, total, page: query.page || 1, limit: take };
  }

  // ── PRIVATE HANDLERS ──────────────────────────────
  private async handlePaymentSucceeded(data: any, gateway: string): Promise<void> {
    const gatewayRef = data.id || data.charge_id;
    const subscriptionId = await this.findSubscriptionByGatewayId(data);

    if (!subscriptionId) {
      this.logger.warn(`No subscription found for gateway ref: ${gatewayRef}`);
      return;
    }

    await this.txRepo.save({
      subscriptionId,
      amount: (data.amount_paid || data.amount || 0) / 100,
      currency: (data.currency || 'MXN').toUpperCase(),
      status: TransactionStatus.SUCCESS,
      paymentMethod: data.payment_method_details?.card
        ? `card_${data.payment_method_details.card.last4}`
        : 'unknown',
      gatewayRef,
      paidAt: new Date(),
    });

    // Update subscription status to active
    await this.subRepo.update(subscriptionId, {
      status: SubscriptionStatus.ACTIVE,
      nextBillingAt: this.nextMonthDate(),
    });

    this.logger.log(`Payment succeeded for subscription #${subscriptionId}`);
  }

  private async handlePaymentFailed(data: any, gateway: string): Promise<void> {
    const gatewayRef = data.id || data.charge_id;
    const subscriptionId = await this.findSubscriptionByGatewayId(data);
    if (!subscriptionId) return;

    await this.txRepo.save({
      subscriptionId,
      amount: (data.amount || 0) / 100,
      currency: 'MXN',
      status: TransactionStatus.FAILED,
      gatewayRef,
    });

    await this.subRepo.update(subscriptionId, { status: SubscriptionStatus.PAST_DUE });
    this.logger.log(`Payment failed for subscription #${subscriptionId}`);
  }

  private async handleSubscriptionCancelled(data: any): Promise<void> {
    const sub = await this.subRepo.findOne({
      where: { restaurantId: parseInt(data.metadata?.restaurant_id) },
    });
    if (!sub) return;
    sub.status = SubscriptionStatus.CANCELLED;
    sub.cancelledAt = new Date();
    await this.subRepo.save(sub);
  }

  private async handleSubscriptionUpdated(data: any): Promise<void> {
    const sub = await this.subRepo.findOne({
      where: { restaurantId: parseInt(data.metadata?.restaurant_id) },
    });
    if (!sub) return;
    // Map Stripe status to our status
    const statusMap: Record<string, SubscriptionStatus> = {
      active: SubscriptionStatus.ACTIVE,
      past_due: SubscriptionStatus.PAST_DUE,
      canceled: SubscriptionStatus.CANCELLED,
      trialing: SubscriptionStatus.TRIAL,
    };
    if (statusMap[data.status]) sub.status = statusMap[data.status];
    await this.subRepo.save(sub);
  }

  private async findSubscriptionByGatewayId(data: any): Promise<number | null> {
    const restaurantId = parseInt(data.metadata?.restaurant_id);
    if (!restaurantId) return null;
    const sub = await this.subRepo.findOne({ where: { restaurantId } });
    return sub?.id || null;
  }

  private nextMonthDate(): Date {
    const d = new Date();
    d.setMonth(d.getMonth() + 1);
    return d;
  }
}
