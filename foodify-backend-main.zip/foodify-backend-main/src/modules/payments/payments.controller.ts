import {
  Controller, Post, Get, Req, Res, Body, Headers,
  Query, UseGuards, HttpCode, RawBodyRequest,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { PaymentsService } from './payments.service';
import { Public } from '../../shared/decorators/public.decorator';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';
import { RolesGuard } from '../../shared/guards/roles.guard';
import { Roles, UserRole } from '../../shared/decorators/roles.decorator';

@Controller('api/v1/payments')
export class PaymentsController {
  constructor(private readonly paymentsService: PaymentsService) {}

  // Stripe webhook — public, verified by signature
  @Public()
  @Post('webhook/stripe')
  @HttpCode(200)
  async stripeWebhook(
    @Req() req: RawBodyRequest<Request>,
    @Headers('stripe-signature') signature: string,
    @Res() res: Response,
  ) {
    try {
      await this.paymentsService.handleStripeWebhook(req.rawBody, signature);
      res.json({ received: true });
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  }

  // Conekta webhook — public
  @Public()
  @Post('webhook/conekta')
  @HttpCode(200)
  async conektaWebhook(@Body() body: any) {
    await this.paymentsService.handleConektaWebhook(body);
    return { received: true };
  }

  // Transaction history — saas_admin only
  @Get('transactions')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.SAAS_ADMIN)
  getTransactions(
    @Query('subscriptionId') subscriptionId?: number,
    @Query('page') page?: number,
    @Query('limit') limit?: number,
  ) {
    return this.paymentsService.getTransactions({ subscriptionId, page, limit });
  }
}
