import {
  WebSocketGateway, WebSocketServer,
  OnGatewayConnection, OnGatewayDisconnect,
  SubscribeMessage, ConnectedSocket, MessageBody,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { OnEvent } from '@nestjs/event-emitter';
import { JwtService } from '@nestjs/jwt';
import { Logger } from '@nestjs/common';
import { KitchenService } from './kitchen.service';
import { OrderItemStatus } from '../orders/entities/order-item.entity';
import { KitchenStatus } from '../orders/entities/order.entity';

@WebSocketGateway({
  namespace: '/kitchen',
  cors: { origin: '*', credentials: true },
})
export class KitchenGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  private logger = new Logger('KitchenGateway');

  constructor(
    private jwtService: JwtService,
    private kitchenService: KitchenService,
  ) {}

  async handleConnection(client: Socket) {
    try {
      const token =
        client.handshake.auth?.token ||
        client.handshake.headers?.authorization?.replace('Bearer ', '');
      if (!token) { client.disconnect(); return; }

      const payload = this.jwtService.verify(token, {
        secret: process.env.JWT_ACCESS_SECRET,
      });

      const allowedRoles = ['chef', 'restaurant_admin'];
      if (!allowedRoles.includes(payload.role)) { client.disconnect(); return; }

      client.data.user = payload;
      const roomId = `kitchen_${payload.restaurantId}`;
      client.join(roomId);
      this.logger.log(`Chef connected to /kitchen: ${client.id} room: ${roomId}`);
    } catch {
      client.disconnect();
    }
  }

  handleDisconnect(client: Socket) {
    this.logger.log(`Client disconnected from /kitchen: ${client.id}`);
  }

  // ── Client → Server events ────────────────────────
  @SubscribeMessage('order:item:start')
  async handleItemStart(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { orderItemId: number },
  ) {
    const user = client.data.user;
    try {
      const item = await this.kitchenService.updateItemStatus(
        data.orderItemId,
        OrderItemStatus.PREPARING,
        user.sub,
      );
      const room = `kitchen_${user.restaurantId}`;
      this.server.to(room).emit('order:item:started', {
        orderItemId: data.orderItemId,
        chefId: user.sub,
        startedAt: item.startedAt,
      });
    } catch (err) {
      client.emit('error', { message: err.message });
    }
  }

  @SubscribeMessage('order:item:ready')
  async handleItemReady(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { orderItemId: number },
  ) {
    const user = client.data.user;
    try {
      const item = await this.kitchenService.updateItemStatus(
        data.orderItemId,
        OrderItemStatus.READY,
        user.sub,
      );
      const room = `kitchen_${user.restaurantId}`;
      this.server.to(room).emit('order:item:marked_ready', {
        orderItemId: data.orderItemId,
        orderId: item.orderId,
        chefId: user.sub,
        readyAt: item.readyAt,
      });
    } catch (err) {
      client.emit('error', { message: err.message });
    }
  }

  // ── Server → Client events (from EventEmitter) ────
  @OnEvent('order.new')
  handleNewOrder(order: any) {
    const room = `kitchen_${order.restaurantId}`;
    this.server.to(room).emit('order:new', {
      orderId: order.id,
      orderNumber: order.orderNumber,
      tableNumber: order.table?.number || null,
      waiterName: order.waiter?.fullName || '',
      items: order.items?.map((i: any) => ({
        id: i.id,
        dishName: i.dish?.name,
        quantity: i.quantity,
        specialNotes: i.specialNotes,
      })),
      createdAt: order.createdAt,
    });
  }

  @OnEvent('order.cancelled')
  handleOrderCancelled(order: any) {
    const room = `kitchen_${order.restaurantId}`;
    this.server.to(room).emit('order:cancelled', {
      orderId: order.id,
      reason: order.cancelReason,
    });
  }

  @OnEvent('order.kitchen_status_changed')
  handleKitchenStatusChanged(order: any) {
    const room = `kitchen_${order.restaurantId}`;
    this.server.to(room).emit('order:status_updated', {
      orderId: order.id,
      kitchenStatus: order.kitchenStatus,
      tableNumber: order.table?.number || null,
    });

    if (order.kitchenStatus === KitchenStatus.READY) {
      this.server.to(room).emit('order:ready', {
        orderId: order.id,
        tableNumber: order.table?.number || null,
      });
    }
  }
}
