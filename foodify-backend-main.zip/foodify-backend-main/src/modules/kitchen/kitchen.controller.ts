import {
  Controller, Get, Patch, Post,
  Body, Param, ParseIntPipe, UseGuards,
} from '@nestjs/common';
import { KitchenService } from './kitchen.service';
import { OrderItemStatus } from '../orders/entities/order-item.entity';
import { KitchenStatus } from '../orders/entities/order.entity';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';
import { RolesGuard } from '../../shared/guards/roles.guard';
import { Roles, UserRole } from '../../shared/decorators/roles.decorator';
import { CurrentUser } from '../../shared/decorators/current-user.decorator';
import { User } from '../users/entities/user.entity';

@Controller('api/v1/kitchen')
@UseGuards(JwtAuthGuard, RolesGuard)
export class KitchenController {
  constructor(private readonly kitchenService: KitchenService) {}

  // ── COMANDAS ──────────────────────────────────────
  @Get('orders')
  @Roles(UserRole.CHEF, UserRole.RESTAURANT_ADMIN)
  getActiveOrders(@CurrentUser() user: User) {
    return this.kitchenService.getActiveOrders(user.restaurantId);
  }

  @Get('orders/:id')
  @Roles(UserRole.CHEF, UserRole.RESTAURANT_ADMIN)
  getOrderDetail(@Param('id', ParseIntPipe) id: number) {
    return this.kitchenService.getOrderDetail(id);
  }

  @Patch('orders/:id/status')
  @Roles(UserRole.CHEF)
  updateOrderStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body('status') status: KitchenStatus,
    @CurrentUser() user: User,
  ) {
    return this.kitchenService.updateOrderStatus(id, status, user.id);
  }

  @Patch('order-items/:id/status')
  @Roles(UserRole.CHEF)
  updateItemStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body('status') status: OrderItemStatus,
    @CurrentUser() user: User,
  ) {
    return this.kitchenService.updateItemStatus(id, status, user.id);
  }

  // ── PLATILLOS & RECETAS ───────────────────────────
  @Get('dishes')
  @Roles(UserRole.CHEF, UserRole.RESTAURANT_ADMIN)
  getDishes(@CurrentUser() user: User) {
    return this.kitchenService.getDishes(user.restaurantId);
  }

  @Get('dishes/:id/recipe')
  @Roles(UserRole.CHEF, UserRole.RESTAURANT_ADMIN)
  getDishRecipe(@Param('id', ParseIntPipe) id: number) {
    return this.kitchenService.getDishRecipe(id);
  }

  // ── STATS ─────────────────────────────────────────
  @Get('stats')
  @Roles(UserRole.CHEF, UserRole.RESTAURANT_ADMIN)
  getStats(@CurrentUser() user: User) {
    return this.kitchenService.getTurnStats(user.restaurantId, user.id);
  }

  // ── SESIONES DE TURNO ─────────────────────────────
  @Post('sessions/start')
  @Roles(UserRole.CHEF)
  startSession(@CurrentUser() user: User) {
    return this.kitchenService.startSession(user.id, user.restaurantId);
  }

  @Patch('sessions/:id/end')
  @Roles(UserRole.CHEF)
  endSession(
    @Param('id', ParseIntPipe) id: number,
    @CurrentUser() user: User,
  ) {
    return this.kitchenService.endSession(id, user.id);
  }
}
