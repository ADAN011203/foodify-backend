import {
  Injectable, NotFoundException, BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Order, KitchenStatus } from '../orders/entities/order.entity';
import { OrderItem, OrderItemStatus } from '../orders/entities/order-item.entity';
import { KitchenSession } from './entities/kitchen-session.entity';
import { Dish } from '../dishes/entities/dish.entity';
import { Recipe } from '../recipes/entities/recipe.entity';
import { EventEmitter2 } from '@nestjs/event-emitter';

@Injectable()
export class KitchenService {
  constructor(
    @InjectRepository(Order) private orderRepo: Repository<Order>,
    @InjectRepository(OrderItem) private itemRepo: Repository<OrderItem>,
    @InjectRepository(KitchenSession) private sessionRepo: Repository<KitchenSession>,
    @InjectRepository(Dish) private dishRepo: Repository<Dish>,
    @InjectRepository(Recipe) private recipeRepo: Repository<Recipe>,
    private eventEmitter: EventEmitter2,
  ) {}

  // ── COMANDAS ─────────────────────────────────────
  async getActiveOrders(restaurantId: number): Promise<Order[]> {
    return this.orderRepo
      .createQueryBuilder('o')
      .leftJoinAndSelect('o.items', 'items')
      .leftJoinAndSelect('items.dish', 'dish')
      .leftJoinAndSelect('o.table', 'table')
      .leftJoinAndSelect('o.waiter', 'waiter')
      .where('o.restaurant_id = :restaurantId', { restaurantId })
      .andWhere("o.kitchen_status != 'delivered'")
      .andWhere("o.status != 'cancelled'")
      .orderBy('o.created_at', 'ASC')
      .getMany();
  }

  async getOrderDetail(id: number): Promise<Order> {
    const order = await this.orderRepo.findOne({
      where: { id },
      relations: ['items', 'items.dish', 'table', 'waiter'],
    });
    if (!order) throw new NotFoundException(`Comanda #${id} no encontrada`);
    return order;
  }

  async updateOrderStatus(id: number, status: KitchenStatus, chefId: number): Promise<Order> {
    const order = await this.getOrderDetail(id);
    const allowedTransitions: Record<KitchenStatus, KitchenStatus[]> = {
      [KitchenStatus.PENDING]: [KitchenStatus.PREPARING],
      [KitchenStatus.PREPARING]: [KitchenStatus.READY],
      [KitchenStatus.READY]: [KitchenStatus.DELIVERED],
      [KitchenStatus.DELIVERED]: [],
    };

    if (!allowedTransitions[order.kitchenStatus]?.includes(status))
      throw new BadRequestException(`Transición inválida: ${order.kitchenStatus} → ${status}`);

    order.kitchenStatus = status;
    const saved = await this.orderRepo.save(order);
    this.eventEmitter.emit('order.kitchen_status_changed', saved);
    return saved;
  }

  async updateItemStatus(itemId: number, status: OrderItemStatus, chefId: number): Promise<OrderItem> {
    const item = await this.itemRepo.findOne({
      where: { id: itemId },
      relations: ['order'],
    });
    if (!item) throw new NotFoundException(`Ítem #${itemId} no encontrado`);

    const allowedTransitions: Record<OrderItemStatus, OrderItemStatus[]> = {
      [OrderItemStatus.PENDING]: [OrderItemStatus.PREPARING],
      [OrderItemStatus.PREPARING]: [OrderItemStatus.READY],
      [OrderItemStatus.READY]: [OrderItemStatus.SERVED],
      [OrderItemStatus.SERVED]: [],
    };

    if (!allowedTransitions[item.status]?.includes(status))
      throw new BadRequestException(`Transición inválida para ítem: ${item.status} → ${status}`);

    if (status === OrderItemStatus.PREPARING) item.startedAt = new Date();
    if (status === OrderItemStatus.READY) item.readyAt = new Date();

    item.status = status;
    const savedItem = await this.itemRepo.save(item);

    // If all items are ready → auto-update order kitchen_status
    if (status === OrderItemStatus.READY) {
      await this.checkAllItemsReady(item.orderId);
    }

    this.eventEmitter.emit('orderItem.status_changed', { item: savedItem, chefId });
    return savedItem;
  }

  private async checkAllItemsReady(orderId: number): Promise<void> {
    const items = await this.itemRepo.find({ where: { orderId } });
    const allReady = items.every((i) =>
      [OrderItemStatus.READY, OrderItemStatus.SERVED].includes(i.status),
    );

    if (allReady) {
      const order = await this.orderRepo.findOne({
        where: { id: orderId },
        relations: ['table'],
      });
      if (order && order.kitchenStatus !== KitchenStatus.READY) {
        order.kitchenStatus = KitchenStatus.READY;
        const saved = await this.orderRepo.save(order);
        this.eventEmitter.emit('order.kitchen_status_changed', saved);
        // Also trigger push notification to waiter
        this.eventEmitter.emit('order.ready_for_waiter', saved);
      }
    }
  }

  // ── DISHES & RECIPES ─────────────────────────────
  async getDishes(restaurantId: number): Promise<Dish[]> {
    return this.dishRepo.find({
      where: { restaurantId, isAvailable: true, deletedAt: null },
      relations: ['category', 'recipe'],
      order: { name: 'ASC' },
    });
  }

  async getDishRecipe(dishId: number): Promise<Recipe> {
    const recipe = await this.recipeRepo.findOne({
      where: { dishId },
      relations: ['ingredients', 'ingredients.inventoryItem'],
    });
    if (!recipe) throw new NotFoundException(`Receta no encontrada para platillo #${dishId}`);
    return recipe;
  }

  // ── STATS ─────────────────────────────────────────
  async getTurnStats(restaurantId: number, chefId: number) {
    const session = await this.sessionRepo.findOne({
      where: { chefId, restaurantId, endedAt: null },
    });

    const since = session?.startedAt || new Date(new Date().setHours(0, 0, 0, 0));

    const completed = await this.orderRepo
      .createQueryBuilder('o')
      .where('o.restaurant_id = :restaurantId AND o.kitchen_status = :status AND o.created_at >= :since', {
        restaurantId, status: KitchenStatus.DELIVERED, since,
      })
      .getCount();

    const avgPrep = await this.itemRepo
      .createQueryBuilder('i')
      .innerJoin('i.order', 'o')
      .select('AVG(TIMESTAMPDIFF(MINUTE, i.started_at, i.ready_at))', 'avg')
      .where('o.restaurant_id = :restaurantId AND i.started_at IS NOT NULL AND i.ready_at IS NOT NULL AND i.created_at >= :since', {
        restaurantId, since,
      })
      .getRawOne();

    return {
      completedOrders: completed,
      avgPrepTimeMinutes: Math.round(parseFloat(avgPrep?.avg || '0')),
      sessionStartedAt: session?.startedAt || null,
      sessionId: session?.id || null,
    };
  }

  // ── SESSIONS ─────────────────────────────────────
  async startSession(chefId: number, restaurantId: number): Promise<KitchenSession> {
    const existing = await this.sessionRepo.findOne({
      where: { chefId, restaurantId, endedAt: null },
    });
    if (existing) return existing;

    const session = this.sessionRepo.create({ chefId, restaurantId });
    return this.sessionRepo.save(session);
  }

  async endSession(sessionId: number, chefId: number): Promise<KitchenSession> {
    const session = await this.sessionRepo.findOne({ where: { id: sessionId, chefId } });
    if (!session) throw new NotFoundException(`Sesión #${sessionId} no encontrada`);
    session.endedAt = new Date();
    return this.sessionRepo.save(session);
  }
}
