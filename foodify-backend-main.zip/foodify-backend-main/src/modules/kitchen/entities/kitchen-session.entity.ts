import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  ManyToOne, JoinColumn,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Restaurant } from '../../restaurants/entities/restaurant.entity';

@Entity('kitchen_sessions')
export class KitchenSession {
  @PrimaryGeneratedColumn({ unsigned: true })
  id: number;

  @Column({ name: 'chef_id', unsigned: true })
  chefId: number;

  @Column({ name: 'restaurant_id', unsigned: true })
  restaurantId: number;

  @CreateDateColumn({ name: 'started_at' })
  startedAt: Date;

  @Column({ name: 'ended_at', nullable: true })
  endedAt: Date;

  @ManyToOne(() => User, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'chef_id' })
  chef: User;

  @ManyToOne(() => Restaurant, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'restaurant_id' })
  restaurant: Restaurant;
}
