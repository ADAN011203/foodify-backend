import { Injectable, NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export interface Response<T> {
  data: T;
  meta?: any;
  status: number;
  timestamp: string;
}

@Injectable()
export class TransformResponseInterceptor<T> implements NestInterceptor<T, Response<T>> {
  intercept(context: ExecutionContext, next: CallHandler): Observable<Response<T>> {
    const statusCode = context.switchToHttp().getResponse().statusCode;
    return next.handle().pipe(
      map((data) => {
        if (data && data.data !== undefined && data.meta !== undefined) {
          return { data: data.data, meta: data.meta, status: statusCode, timestamp: new Date().toISOString() };
        }
        return { data, status: statusCode, timestamp: new Date().toISOString() };
      }),
    );
  }
}
