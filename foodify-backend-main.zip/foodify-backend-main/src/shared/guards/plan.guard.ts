import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { SaasSubscription } from '../../modules/saas/entities/saas-subscription.entity';
import { FEATURE_KEY } from '../decorators/require-feature.decorator';
import { READONLY_KEY } from '../decorators/read-only.decorator';
import { UserRole } from '../decorators/roles.decorator';

@Injectable()
export class PlanGuard implements CanActivate {
  constructor(
    private reflector: Reflector,
    @InjectRepository(SaasSubscription) private subRepo: Repository<SaasSubscription>,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    // saas_admin bypasses all plan checks
    if (!user || user.role === UserRole.SAAS_ADMIN) return true;
    if (!user.restaurantId) return true;

    const requiredFeature = this.reflector.getAllAndOverride<string>(FEATURE_KEY, [
      context.getHandler(), context.getClass(),
    ]);
    const allowReadOnly = this.reflector.getAllAndOverride<boolean>(READONLY_KEY, [
      context.getHandler(), context.getClass(),
    ]);

    const sub = await this.subRepo.findOne({
      where: { restaurantId: user.restaurantId },
      relations: ['plan'],
      order: { createdAt: 'DESC' },
    });

    if (!sub) throw new ForbiddenException({ code: 'NO_SUBSCRIPTION', message: 'Sin suscripción activa. Contacta a soporte.' });

    // Check subscription status
    switch (sub.status) {
      case 'cancelled':
        throw new ForbiddenException({ code: 'ACCOUNT_CANCELLED', message: 'Tu cuenta ha sido cancelada.' });
      case 'suspended':
        throw new ForbiddenException({ code: 'ACCOUNT_SUSPENDED', message: 'Cuenta suspendida por falta de pago. Contacta a soporte.' });
      case 'past_due':
        if (!allowReadOnly) throw new ForbiddenException({ code: 'PAYMENT_OVERDUE', message: 'Pago vencido. Solo puedes consultar información.' });
        break;
    }

    // Check plan feature
    if (requiredFeature) {
      const hasFeature = sub.plan?.features?.[requiredFeature] === true;
      if (!hasFeature) throw new ForbiddenException({
        code: 'FEATURE_NOT_IN_PLAN',
        planName: sub.plan?.name,
        feature: requiredFeature,
        message: `Tu plan "${sub.plan?.name}" no incluye esta funcionalidad. Actualiza a Plan Premium.`,
      });
    }

    request.subscription = sub;
    return true;
  }
}
