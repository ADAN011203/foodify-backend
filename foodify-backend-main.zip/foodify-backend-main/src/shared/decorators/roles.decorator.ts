import { SetMetadata } from '@nestjs/common';

export enum UserRole {
  SAAS_ADMIN = 'saas_admin',
  RESTAURANT_ADMIN = 'restaurant_admin',
  MANAGER = 'manager',
  WAITER = 'waiter',
  CHEF = 'chef',
  CASHIER = 'cashier',
}

export const ROLES_KEY = 'roles';
export const Roles = (...roles: UserRole[]) => SetMetadata(ROLES_KEY, roles);
