import { SetMetadata } from '@nestjs/common';
export const READONLY_KEY = 'allow_readonly';
/** Marks an endpoint as accessible in past_due status (read-only mode). Apply to GET endpoints. */
export const AllowReadOnly = () => SetMetadata(READONLY_KEY, true);
