import { SetMetadata } from '@nestjs/common';
export const FEATURE_KEY = 'require_feature';
export const RequireFeature = (feature: string) => SetMetadata(FEATURE_KEY, feature);
