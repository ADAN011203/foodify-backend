// src/shared/constants/plan-features.ts
// ─────────────────────────────────────────────────────────────────
// Definición central de todas las features disponibles en Foodify.
// Estas keys se usan en @RequireFeature() y en el JSON de saas_plans.
// ─────────────────────────────────────────────────────────────────

export const PlanFeature = {
  // ── Disponibles en AMBOS planes ──────────────────────────────
  PWA_ADMIN:           'pwa_admin',          // Panel administrativo web
  PWA_PUBLIC_MENU:     'pwa_public_menu',    // Menú público QR para clientes
  DISH_MANAGEMENT:     'dish_management',    // CRUD platillos, menús, categorías
  DASHBOARD_ANALYTICS: 'dashboard_analytics',// 5 gráficas del dashboard
  TABLES:              'tables',             // Gestión de mesas y QR

  // ── Exclusivos Plan PREMIUM ───────────────────────────────────
  ANDROID_APP:         'android_app',        // Login desde app Android
  KITCHEN_MODULE:      'kitchen_module',     // Módulo cocina (comandas)
  INVENTORY_FIFO:      'inventory_fifo',     // Inventario con lotes FIFO
  PUSH_NOTIFICATIONS:  'push_notifications', // FCM push Android
  WEBSOCKETS:          'websockets',         // Tiempo real Socket.io
  WAITER_ROLE:         'waiter_role',        // Rol mesero activo
  CHEF_ROLE:           'chef_role',          // Rol chef activo
  STAFF_REPORTS:       'staff_reports',      // Reportes de rendimiento staff
  KITCHEN_REPORTS:     'kitchen_reports',    // Reportes de cocina
} as const;

export type PlanFeatureKey = typeof PlanFeature[keyof typeof PlanFeature];

// ── Features JSON para seeds ──────────────────────────────────────
export const BASIC_PLAN_FEATURES: Record<PlanFeatureKey, boolean> = {
  pwa_admin:           true,
  pwa_public_menu:     true,
  dish_management:     true,
  dashboard_analytics: true,
  tables:              true,
  android_app:         false,
  kitchen_module:      false,
  inventory_fifo:      false,
  push_notifications:  false,
  websockets:          false,
  waiter_role:         false,
  chef_role:           false,
  staff_reports:       false,
  kitchen_reports:     false,
};

export const PREMIUM_PLAN_FEATURES: Record<PlanFeatureKey, boolean> = {
  pwa_admin:           true,
  pwa_public_menu:     true,
  dish_management:     true,
  dashboard_analytics: true,
  tables:              true,
  android_app:         true,
  kitchen_module:      true,
  inventory_fifo:      true,
  push_notifications:  true,
  websockets:          true,
  waiter_role:         true,
  chef_role:           true,
  staff_reports:       true,
  kitchen_reports:     true,
};
