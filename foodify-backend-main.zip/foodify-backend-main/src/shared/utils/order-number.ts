import { Repository } from 'typeorm';

export async function generateOrderNumber(
  repo: Repository<any>,
  restaurantId: number,
): Promise<string> {
  const last = await repo
    .createQueryBuilder('o')
    .where('o.restaurant_id = :restaurantId', { restaurantId })
    .orderBy('o.id', 'DESC')
    .getOne();

  if (!last) return '0001';
  const next = (parseInt(last.order_number, 10) % 9999) + 1;
  return next.toString().padStart(4, '0');
}
