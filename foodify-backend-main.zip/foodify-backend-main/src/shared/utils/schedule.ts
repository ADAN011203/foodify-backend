import { toZonedTime, format } from 'date-fns-tz';

/**
 * Determina si un menú está activo en este momento
 * basándose en su schedule JSON y el timezone del restaurante.
 *
 * schedule: { days: number[], start: "HH:MM", end: "HH:MM" }
 * days: 0=Domingo, 1=Lunes, 2=Martes, 3=Miércoles,
 *       4=Jueves, 5=Viernes, 6=Sábado
 */
export function isMenuActiveNow(
  schedule: { days: number[]; start: string; end: string } | null,
  timezone: string = 'America/Monterrey',
): boolean {
  // Si no tiene horario definido → siempre activo
  if (!schedule || !schedule.days || !schedule.start || !schedule.end) {
    return true;
  }

  try {
    const now = new Date();
    const zonedNow = toZonedTime(now, timezone);

    const currentDay = zonedNow.getDay();    // 0-6
    const currentTime = format(zonedNow, 'HH:mm', { timeZone: timezone });

    // Verificar día
    if (!schedule.days.includes(currentDay)) return false;

    // Verificar rango de horas
    return currentTime >= schedule.start && currentTime <= schedule.end;
  } catch {
    // Si falla el parse de timezone → asumir activo para no bloquear al cliente
    return true;
  }
}

/**
 * Formatea el horario de un menú en texto legible.
 * Ej: { days:[1,2,3,4,5], start:"12:00", end:"16:00" }
 * → "Lun-Vie de 12:00 a 16:00"
 */
export function formatScheduleText(
  schedule: { days: number[]; start: string; end: string } | null,
): string | null {
  if (!schedule) return null;

  const dayNames = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
  const days = schedule.days.map((d) => dayNames[d]).join(', ');
  return `${days} de ${schedule.start} a ${schedule.end}`;
}

/**
 * Genera el availabilityNote para un platillo fuera de horario.
 * Retorna null si el menú está activo ahora.
 */
export function getAvailabilityNote(
  schedule: { days: number[]; start: string; end: string } | null,
  isActiveNow: boolean,
): string | null {
  if (isActiveNow || !schedule) return null;
  return `Disponible de ${schedule.start} a ${schedule.end}`;
}
