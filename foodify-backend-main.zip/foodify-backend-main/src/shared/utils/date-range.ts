import { startOfDay, endOfDay, startOfWeek, endOfWeek,
         startOfMonth, endOfMonth, startOfQuarter, endOfQuarter,
         startOfYear, endOfYear, parseISO } from 'date-fns';

export type Period = 'today' | 'week' | 'month' | 'quarter' | 'year' | 'custom';

export function getDateRange(period: Period, start?: string, end?: string): { from: Date; to: Date } {
  const now = new Date();
  switch (period) {
    case 'today':   return { from: startOfDay(now),     to: endOfDay(now) };
    case 'week':    return { from: startOfWeek(now),    to: endOfWeek(now) };
    case 'month':   return { from: startOfMonth(now),   to: endOfMonth(now) };
    case 'quarter': return { from: startOfQuarter(now), to: endOfQuarter(now) };
    case 'year':    return { from: startOfYear(now),    to: endOfYear(now) };
    case 'custom':
      if (!start || !end) throw new Error('Se requieren fechas start y end para período custom');
      return { from: startOfDay(parseISO(start)), to: endOfDay(parseISO(end)) };
    default:        return { from: startOfMonth(now), to: endOfMonth(now) };
  }
}
